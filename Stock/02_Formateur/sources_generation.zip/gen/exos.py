# -*- coding: utf-8 -*-
"""Source unique des exercices, TP et étude de cas (énoncés + corrigés)."""
import math
from uimm import fr
import calc
from calc import R, E, JOURS

def pc(x, nd=1): return fr(100 * x, nd) + ' %'
T = lambda h, rows, w=None, **o: ('t', h, rows, w, o)

# Titres de sections du cours servant de sources (clé -> libellé cherché dans le PDF de P1)
SRC = {'2.2': '2.2 Ce que coûte un euro qui dort', '2.5': '2.5 Trois indicateurs pour suivre un stock',
       '3.1': '3.1 La méthode', '3.2': '3.2 Exemple : dix articles de VÉRILOIRE',
       '4.1': '4.1 Deux coûts qui tirent en sens opposé', '4.2': '4.2 La formule de Wilson',
       '4.3': '4.3 L’optimum est plat : la zone économique', '4.4': '4.4 Quand le fournisseur propose une remise',
       '4.5': '4.5 Les limites de la formule', '5.1': '5.1 Quatre combinaisons', '5.2': '5.2 Le point de commande',
       '5.3': '5.3 Le recomplètement périodique', '5.4': '5.4 Quand le délai est long',
       '5.5': '5.5 Quelle méthode pour quel article ?', '6.1': '6.1 Deux aléas, une approche simple',
       '6.2': '6.2 Taux de service et loi normale', '6.3': '6.3 Le prix du dernier pour cent',
       '6.4': '6.4 Recomplètement périodique : un horizon plus long', '6.5': '6.5 Pièces à faible rotation : la loi de Poisson',
       'B': 'Annexe B. Fonctions Excel utiles'}
SRC_NOTE = {'4.5': 'encadré Bachelor', '6.4': 'encadré Bachelor'}

EX = []
def ex(**k): EX.append(k)

# ====================================================================== SÉANCE 1
e = E[1]
ex(n=1, titre='Le vrai coût d’un magasin', seance=1, src='2.2', duree='20 min',
   ctx=['Le magasin de pièces de MÉCA-CENTRE (entreprise fictive) détient en moyenne ' + fr(e['stock']) + ' € de stock. La comptabilité relève les frais annuels suivants.',
        T(['Poste', 'Montant annuel (€)'], [[l, fr(v)] for l, v in e['frais']], [7, 2.6], align=['left', 'right'])],
   qs=[('Calculer le taux de possession $T$ de ce magasin.',
        [f'Total des frais : 40 000 + 72 000 + 28 000 + 6 000 + 14 000 + 24 000 = **{fr(e["total"])} €**.',
         f'$T$ = frais annuels / valeur du stock moyen = {fr(e["total"])} / {fr(e["stock"])} = **{pc(e["T"], 0)}** par an.']),
       ('Combien ce stock coûte-t-il par jour calendaire ?', [f'{fr(e["total"])} / 365 = **{fr(e["jour"])} € par jour**, week-ends compris.']),
       ('Une palette de moteurs valant 15 000 € reste 8 mois en rayon avant d’être utilisée. Combien a-t-elle coûté en possession ?',
        [f'15 000 × {fr(e["T"], 2)} × 8/12 = **{fr(e["palette"])} €**. C’est 15 % du prix de la palette.']),
       ('La direction veut réduire le stock de 20 %. Le contrôleur annonce une économie de 20 % des frais, soit 36 800 €. Critiquer ce calcul.',
        [f'Le calcul suppose que tous les frais baissent avec le stock. C’est faux à court terme. Les salaires du magasin (72 000 €) et la surface (28 000 €) ne bougent pas si l’on retire un cinquième des pièces.',
         f'Les frais qui suivent réellement la valeur du stock sont le capital, l’assurance, la casse et l’obsolescence : 40 000 + 6 000 + 14 000 + 24 000 = {fr(e["var"])} €. L’économie réaliste est de 20 % × {fr(e["var"])} = **{fr(e["eco_reelle"])} €**, soit moins de la moitié de l’annonce.',
         'Les frais de structure ne baissent que si la réduction libère une surface ou un poste. Il faut le dire dans la note à la direction.'])],
   comp='Le taux de possession est un rapport entre des frais réels et un stock moyen. Il se calcule, il ne se devine pas. Tous les frais qu’il contient ne sont pas variables.',
   err=['Confondre $T$ avec le seul taux d’intérêt (ici 5 % sur 23 %).', 'Diviser par le stock de fin d’année au lieu du stock moyen.', 'En question 3, oublier de proratiser sur 8 mois.'])

e = E[2]
ex(n=2, titre='Rotation et couverture', seance=1, src='2.5', duree='15 min',
   ctx=['VÉRILOIRE travaille 250 jours par an. On relève pour quatre articles la valeur consommée dans l’année et la valeur du stock moyen.',
        T(['Article', 'Consommation annuelle (€)', 'Stock moyen (€)'], [[a['ref'], fr(a['conso']), fr(a['stock'])] for a in e[:4]], [3, 3.3, 3.3], align=['left', 'right', 'right'])],
   qs=[('Calculer le taux de rotation de chaque article, puis celui de l’ensemble.',
        [T(['Article', 'Calcul', 'Rotation'], [[a['ref'], f'{fr(a["conso"])} / {fr(a["stock"])}', fr(a['rot'], 1 if a['rot'] > 1 else 2)] for a in e], [3, 4, 2.6], align=['left', 'left', 'right'], total_last=True),
         'La rotation de l’ensemble se calcule sur les totaux. Ce n’est pas la moyenne des quatre rotations.']),
       ('Calculer la couverture de chaque article en jours ouvrés.',
        [T(['Article', 'Calcul', 'Couverture (jours ouvrés)'], [[a['ref'], f'{fr(a["stock"])} / {fr(a["conso"])} × 250', fr(a['couv'], 1)] for a in e], [3, 4, 2.6], align=['left', 'left', 'right'], total_last=True),
         'Vérification : couverture = 250 / rotation.']),
       ('Quel article pose question ? Que faut-il vérifier avant de conclure ?',
        [f'Le capteur CP-01 tourne {fr(e[3]["rot"], 2)} fois par an : il y a {fr(e[3]["couv"])} jours ouvrés de stock, soit un an et demi.',
         'Avant de parler de surstock, on vérifie trois points : la pièce est-elle critique pour une ligne ? Le fournisseur impose-t-il un minimum de commande ? L’article est-il en fin de vie ? Sans raison de ce type, on réduit.',
         f'La rotation d’ensemble ({fr(e[4]["rot"], 1)}) a l’air correcte. Elle cache un article à 23 et un article à 0,67.'])],
   comp='Rotation et couverture disent la même chose sous deux angles. Un indicateur global masque les extrêmes : on regarde toujours article par article, au moins pour les A.',
   err=['Faire la moyenne des rotations au lieu de diviser les totaux.', 'Exprimer la couverture en jours calendaires alors que la consommation est donnée sur 250 jours ouvrés.'])

e = E[3]; D3 = {r: (des, q, p, s) for r, des, q, p, s in e['data']}
rowsQ1 = [[r, D3[r][0], f'{fr(D3[r][1])} × {fr(D3[r][2], 2)}', fr(v), pc(pct / 100), pc(cum / 100), cl] for r, v, pct, cum, cl in e['conso']['rows']]
rowsQ3 = [[r, D3[r][0], f'{fr(D3[r][3])} × {fr(D3[r][2], 2)}', fr(D3[r][3] * D3[r][2]), fr(e['couv'][r], 1)] for r, *_ in e['conso']['rows']]
ex(n=3, titre='Analyse ABC d’un magasin de maintenance', seance=1, src='3.1', duree='40 min',
   ctx=['Le service maintenance suit dix pièces de rechange. Pour chacune, on connaît le nombre de sorties par an, le prix unitaire et le stock moyen.',
        T(['Réf.', 'Désignation', 'Sorties par an', 'Prix unitaire (€)', 'Stock moyen (pièces)'], [[r, des, fr(q), fr(p, 2), fr(s)] for r, des, q, p, s in e['data']],
          [1, 3.6, 1.6, 1.8, 1.8], align=['left', 'left', 'right', 'right', 'right'], size=19)],
   qs=[('Calculer la valeur consommée par an de chaque pièce. Classer par valeur décroissante et calculer les pourcentages cumulés.',
        [T(['Réf.', 'Désignation', 'Calcul', 'Valeur (€)', '%', 'Cumul', 'Classe'], rowsQ1, [0.9, 3, 1.8, 1.2, 1, 1, 0.9], align=['left', 'left', 'left', 'right', 'right', 'right', 'center'], size=18, hl=(0, 1)),
         f'Total : {fr(e["conso"]["total"])} €. La colonne « Classe » anticipe la question 2.']),
       ('Tracer la courbe ABC dans un carré de 10 cm de côté. Lire le ratio de discrimination et répartir les pièces en classes A, B, C.',
        [('f', 'c06_e3', 'Exercice 3 : courbe ABC sur la valeur consommée', 9),
         f'La diagonale coupe la courbe entre la 2e et la 3e pièce. Par le calcul : la courbe passe de 63,4 % à 70,8 % entre 20 % et 30 % des articles. L’intersection avec y = 100 − x donne x = {fr(e["conso"]["xc"], 1)} % et y = {fr(100 - e["conso"]["xc"], 1)} %. Donc **RD = {fr(e["conso"]["rd"], 2)}**.',
         'RD est compris entre 0,65 et 0,75 : répartition 20 / 30 / 50. **Classe A** : R05 et R03 (63,4 % de la valeur). **Classe B** : R06, R07, R02. **Classe C** : les cinq autres.'], '3.2'),
       ('Calculer pour chaque pièce la valeur immobilisée (stock moyen × prix) et la couverture en mois (stock moyen / sorties par an × 12).',
        [T(['Réf.', 'Désignation', 'Stock × prix', 'Valeur immobilisée (€)', 'Couverture (mois)'], rowsQ3, [0.9, 3.2, 1.8, 2, 1.8], align=['left', 'left', 'left', 'right', 'right'], size=18, hl=(2,)),
         f'Total immobilisé : {fr(e["stock"]["total"])} €.'], '2.5'),
       ('Les pièces de classe A sont-elles celles qui immobilisent le plus d’argent ? Commenter.',
        [f'Non. Le variateur R06 (classe B) immobilise 2 850 €, soit {pc(2850 / e["stock"]["total"], 0)} du stock, avec 18 mois de couverture. Le moteur R09 et le distributeur R04 (classe C) suivent, avec 16 et 15 mois.',
         'Les deux pièces A (R05 et R03) tournent vite : 1,5 et 1,8 mois de couverture. L’argent qui dort n’est pas chez les A.',
         f'Remarque : classée sur la valeur immobilisée, la population donne RD = {fr(e["stock"]["rd"], 2)}, en dessous de 0,65. Ce critère seul n’est pas interprétable. On croise donc les deux lectures.']),
       ('Proposer deux actions.',
        ['- Fusibles R08 : 400 en stock pour 300 sorties par an. Rien ne justifie 16 mois de couverture sur un article courant. On réduit.',
         '- Variateur, moteur, distributeur : des pièces chères qui sortent rarement. On ne les supprime pas à l’aveugle. On vérifie leur criticité, puis on calcule leur seuil avec la loi de Poisson (TP 5).'], '6.5')],
   comp='Le classement dépend du critère. Une pièce de rechange peut être peu consommée et pourtant peser lourd en argent immobilisé. L’ABC désigne où regarder, il ne décide pas à la place du technicien.',
   err=['Trier par quantité au lieu de trier par valeur.', 'Tracer la courbe dans un rectangle : le ratio de discrimination se lit dans un carré.', 'Confondre les points A, B, C du tracé avec les classes A, B, C.'])

# ====================================================================== SÉANCE 2
e = E[4]
ex(n=4, titre='Quantité économique d’un filtre', seance=2, src='4.2', duree='20 min',
   ctx=[f'L’atelier consomme {fr(e["C"])} filtres hydrauliques par an, de façon régulière, sur 50 semaines. Prix unitaire : {fr(e["P"])} €. Coût de passation d’une commande : {fr(e["L"])} €. Taux de possession : 25 %. Les filtres sont livrés par cartons de 50.'],
   qs=[('Calculer la quantité économique.', [f'$Q_e$ = √(2 × 2 400 × 60 / (12 × 0,25)) = √96 000 = **{fr(e["Qe"], 1)} filtres**.']),
       ('Arrondir au carton. En déduire le nombre de commandes par an et la période entre deux commandes.',
        [f'Le multiple de 50 le plus proche est **300 filtres** (6 cartons). $N$ = 2 400 / 300 = **{fr(e["N"])} commandes par an**. Période : 50 / 8 = **{fr(e["Pe"], 2)} semaines**.'], '4.3'),
       ('Calculer CL, CS et le coût de gestion annuel pour cette quantité.',
        [f'CL = 8 × 60 = **{fr(e["CL"])} €**. CS = 300 / 2 × 12 × 0,25 = **{fr(e["CS"])} €**. CA = 2 400 × 12 = {fr(e["CA"])} €.', f'CGA = {fr(e["CA"])} + {fr(e["CL"])} + {fr(e["CS"])} = **{fr(e["CGA"])} €**.'], '4.1'),
       ('Vérifier la cohérence du résultat.',
        [f'À l’optimum, CS = CL. Ici 450 € et 480 € : les deux valeurs sont proches, ce qui est attendu puisque 300 est proche de 309,8.',
         f'Minimum théorique de CS + CL : √(2 × 2 400 × 60 × 12 × 0,25) = {fr(e["opt"], 2)} €. Avec 300 filtres on paie 930 €. L’arrondi au carton coûte {fr(930 - e["opt"], 2)} € par an.'])],
   comp='La formule donne un repère, le conditionnement fixe la quantité réelle. L’égalité CS = CL sert de contrôle.',
   err=['Écrire le taux 25 au lieu de 0,25.', 'Oublier le facteur 2 sous la racine.', 'Prendre $Q$ au lieu de $Q/2$ pour le stock moyen dans CS.'])

e = E[5]
ex(n=5, titre='Le lot de l’acheteur', seance=2, src='4.2', duree='20 min',
   ctx=[f'Un acheteur commande un raccord par lots de {fr(e["Q"])}. « C’est la quantité économique », dit-il. Consommation : {fr(e["C"])} par an. Prix : {fr(e["P"])} €. Taux de possession : 24 %.'],
   qs=[('Quel coût de passation $L$ faudrait-il pour que 900 soit bien la quantité économique ?',
        [('eqs', [r'Q_e^{2} = \dfrac{2\,C\,L}{P\,T}', r'\text{donc}', r'L = \dfrac{Q_e^{2}\,P\,T}{2\,C}']),
         f'$L$ = 900² × 5 × 0,24 / (2 × 3 600) = 972 000 / 7 200 = **{fr(e["Limp"])} €** par commande.']),
       ('Le service achats estime son coût réel à 50 € par commande. Calculer la quantité économique.',
        [f'$Q_e$ = √(2 × 3 600 × 50 / (5 × 0,24)) = √300 000 = **{fr(e["Qe"], 1)}**, soit environ 550 raccords.']),
       ('Calculer le surcoût annuel de la pratique actuelle.',
        [f'Avec 900 : CL = 3 600 / 900 × 50 = 200 € ; CS = 450 × 5 × 0,24 = 540 € ; total {fr(e["cout900"])} €.',
         f'À l’optimum : √(2 × 3 600 × 50 × 5 × 0,24) = {fr(e["coutQe"], 2)} €. Surcoût : **{fr(e["surcout"], 2)} € par an**, soit {pc(e["surcout"] / e["coutQe"])}.'], '4.3'),
       ('Ce surcoût justifie-t-il de changer la pratique ?',
        ['Sur cet article seul, 83 € par an ne valent pas une réunion. Mais le stock moyen passe de 274 à 450 pièces, soit 64 % de plus. Appliquée à quelques centaines de références, la même habitude gonfle le magasin sans que personne l’ait décidé. On corrige la règle, pas l’article.'])],
   comp='La formule de Wilson se lit dans les deux sens. Un lot « habituel » révèle le coût de commande que l’on suppose sans le dire.',
   err=['Isoler $L$ en oubliant d’élever $Q_e$ au carré.', 'Comparer les CGA en oubliant que CA est le même dans les deux cas.'])

e = E[6]; e4 = E[4]
ex(n=6, titre='Jusqu’où peut-on s’écarter de l’optimum ?', seance=2, src='4.3', duree='25 min',
   ctx=['On reprend le filtre de l’exercice 4 : $Q_e$ = 309,8 et le minimum de CS + CL vaut 929,52 €.'],
   qs=[('Compléter le tableau pour les quantités 150, 250, 300, 350, 600 et 1 000 : rapport $x = Q/Q_e$, coût CS + CL, surcoût en pourcentage.',
        [T(['$Q$', '$x = Q/Q_e$', 'CL (€)', 'CS (€)', 'CS + CL (€)', 'Surcoût'],
           [[fr(q), fr(e[q]['x'], 3), fr(e4['C'] / q * e4['L'], 2), fr(q / 2 * 3, 2), fr(e[q]['cout'], 2), '+ ' + pc(e[q]['r'] - 1)] for q in (150, 250, 300, 350, 600, 1000)],
           [1.2, 1.6, 1.6, 1.6, 1.8, 1.8], align=['right'] * 6),
         'Contrôle par la formule du cours : pour $Q$ = 600, ½ × (1,936 + 1 / 1,936) = 1,226. On retrouve + 22,6 %.']),
       ('Entre quelles quantités le surcoût reste-t-il inférieur à 5 % ?',
        [('eqs', [r'\dfrac{1}{2}\left(x + \dfrac{1}{x}\right) = \text{1,05}', r'\text{soit}', r'x^{2} - \text{2,1}\,x + 1 = 0']),
         f'Δ = 2,1² − 4 = 0,41. Les racines sont $x$ = 0,730 et $x$ = 1,370. La zone va de {fr(e["borne"][0])} à {fr(e["borne"][1])} filtres. En cartons de 50 : **de 250 à 400 filtres**.']),
       ('L’ancien magasinier commandait les 1 000 filtres « pour être tranquille ». Chiffrer.',
        [f'$x$ = 3,227. Surcoût : + {pc(e[1000]["r"] - 1)}, soit 1 644 − 929,52 = **{fr(e[1000]["cout"] - e4["opt"], 2)} € par an**. Le stock moyen passe de 150 à 500 filtres.'])],
   comp='La courbe est plate près du minimum et raide loin de lui. On a de la liberté pour arrondir, pas pour tripler.',
   err=['Calculer le surcoût sur le CGA complet : CA noie l’écart et le pourcentage paraît négligeable.', 'Croire la zone symétrique : elle s’étend plus loin à droite qu’à gauche.'])

e = E[7]; r7 = e['res']
ex(n=7, titre='Faut-il accepter la remise ?', seance=2, src='4.4', duree='30 min',
   ctx=[f'Consommation annuelle : {fr(e["C"])} pièces. Coût de commande : {fr(e["L"])} €. Taux de possession : 20 %. Le fournisseur propose le tarif suivant.',
        T(['Quantité commandée', 'Prix unitaire'], [['Moins de 1 000', '10,00 €'], ['De 1 000 à 2 999', '9,70 €'], ['3 000 et plus', '9,50 €']], [4, 3])],
   qs=[('Calculer la quantité économique pour chaque prix. Est-elle dans la tranche du prix ?',
        [T(['Prix', 'Calcul', '$Q_e$', 'Dans la tranche ?', 'Quantité retenue'],
           [[fr(r['p'], 2) + ' €', f'√(2 × 6 000 × 80 / ({fr(r["p"], 2)} × 0,20))', fr(r['qe'], 1), 'Oui' if r['ok'] else 'Non', fr(r['q'], 1 if r['ok'] else 0)] for r in r7],
           [1.2, 4, 1.2, 1.6, 1.6], align=['left', 'left', 'right', 'center', 'right'], size=19),
         'Pour 9,70 € et 9,50 €, la quantité économique est inférieure au seuil de la tranche. On retient le seuil : c’est le point le moins cher de la tranche.']),
       ('Calculer le coût de gestion annuel de chaque candidat.',
        [T(['Prix', '$Q$', 'CA (€)', 'CL (€)', 'CS (€)', 'CGA (€)'], [[fr(r['p'], 2) + ' €', fr(r['q'], 1 if r['ok'] else 0), fr(r['CA']), fr(r['CL'], 2), fr(r['CS'], 2), fr(r['cga'], 2)] for r in r7],
           [1.2, 1.4, 1.6, 1.6, 1.6, 1.8], align=['left'] + ['right'] * 5, hl=(1,))]),
       ('Conclure.', [f'Le minimum est à **1 000 pièces à 9,70 €**. Gain : {fr(r7[0]["cga"], 2)} − {fr(r7[1]["cga"], 2)} = **{fr(e["gain"], 2)} € par an**. La tranche à 9,50 € coûte 360 € de plus que celle à 9,70 € : le stock moyen de 1 500 pièces annule la remise.']),
       ('À partir de quel prix la tranche « 3 000 et plus » deviendrait-elle la meilleure ?',
        [f'On cherche $p$ tel que CGA(3 000 ; $p$) = {fr(r7[1]["cga"], 2)} : 6 000 $p$ + 160 + 1 500 × 0,20 × $p$ = {fr(r7[1]["cga"], 2)}, donc 6 300 $p$ = {fr(r7[1]["cga"] - 160, 2)}.',
         f'$p$ = **{fr(e["p_seuil"], 2)} €**, soit une remise d’au moins {pc(e["rem_seuil"])} sur le prix de base. En dessous, on refuse.'])],
   comp='Une remise déplace le prix, donc CA. On compare toujours des CGA complets, jamais des prix unitaires.',
   err=['Comparer seulement CS + CL en oubliant CA : la remise disparaît du calcul.', 'Retenir une quantité économique qui n’est pas dans la tranche de son prix.', 'Calculer CS de la tranche remisée avec l’ancien prix.'])

e = E[8]
ex(n=8, titre='Lot de fabrication à cadence finie', seance=2, src='4.5', duree='25 min', bach=True,
   ctx=[f'Une presse fabrique un boîtier à la cadence de {e["pmj"]} pièces par jour. Le montage en consomme {e["cmj"]} par jour, 250 jours par an. Coût de revient : {fr(e["P"])} €. Coût d’un lancement (réglage compris) : {fr(e["L"])} €. Taux de possession : 25 %.'],
   qs=[('Calculer la quantité économique par la formule de Wilson simple.', [f'$C$ = 40 × 250 = 10 000. $Q_e$ = √(2 × 10 000 × 180 / (30 × 0,25)) = √480 000 = **{fr(e["Q0"], 1)} pièces**.'], '4.2'),
       ('Calculer la quantité économique en tenant compte de la cadence de production.',
        [('eq', r'Q_e = \sqrt{\dfrac{2\,C\,L}{P\,T\,\left(1 - \dfrac{c}{p}\right)}}'),
         f'1 − 40 / 200 = 0,8. $Q_e$ = √(3 600 000 / (7,5 × 0,8)) = √600 000 = **{fr(e["Q"], 1)} pièces**.']),
       ('En déduire le stock maximal, la durée de fabrication d’un lot, la durée d’un cycle et le nombre de lancements par an.',
        [f'Stock maximal : 774,6 × 0,8 = **{fr(e["smax"])} pièces**. Fabrication d’un lot : 774,6 / 200 = **{fr(e["duree_prod"], 1)} jours**. Cycle : 774,6 / 40 = **{fr(e["cycle"], 1)} jours**. Lancements : 10 000 / 774,6 = **{fr(e["N"], 1)} par an**.']),
       ('Pourquoi la quantité est-elle plus grande qu’avec la formule simple ?',
        ['Pendant que la presse produit, le montage consomme. Le stock monte à 80 % du lot seulement. Chaque pièce du lot coûte donc moins cher à stocker, et l’équilibre se déplace vers des lots plus gros.'])],
   comp='La formule simple suppose une livraison instantanée. En fabrication, le stock se remplit pendant qu’il se vide.',
   err=['Inverser $c$ et $p$ dans le rapport.', 'Prendre le stock maximal égal à $Q$.'])

e = E[9]
ex(n=9, titre='SMED : ce que rapporte un réglage plus court', seance=2, src='4.5', duree='20 min',
   ctx=[f'Une pièce fabriquée : $C$ = {fr(e["C"])} par an, coût de revient {fr(e["P"])} €, taux de possession 25 %. Le changement de série dure 4 h et coûte {fr(e["L1"])} €. Un chantier SMED le ramène à 1 h, soit {fr(e["L2"])} €. On applique la formule de Wilson simple.'],
   qs=[('Calculer la quantité économique avant et après le chantier.',
        [f'Avant : √(2 × 10 000 × 180 / 7,5) = **{fr(e["Q1"], 1)}**. Après : √(2 × 10 000 × 45 / 7,5) = **{fr(e["Q2"], 1)}**. Le coût de lancement est divisé par 4, le lot par 2.']),
       ('Calculer CS + CL et la valeur du stock moyen dans les deux cas.',
        [T(['', 'Avant', 'Après'], [['CS + CL (€ par an)', fr(e['cout1'], 2), fr(e['cout2'], 2)], ['Stock moyen (pièces)', fr(e['Q1'] / 2, 1), fr(e['Q2'] / 2, 1)],
                                       ['Valeur du stock moyen (€)', fr(e['val1']), fr(e['val2'])], ['Lancements par an', fr(e['N1'], 1), fr(e['N2'], 1)]], [4, 2.8, 2.8], align=['left', 'right', 'right'])]),
       ('Calculer le temps annuel passé en réglage avant et après.',
        [f'Avant : 14,4 × 4 h = **{fr(e["h1"], 1)} h**. Après : 28,9 × 1 h = **{fr(e["h2"], 1)} h**. On règle deux fois plus souvent et on y passe deux fois moins de temps.']),
       ('Conclure.',
        [f'Le chantier rapporte {fr(e["cout1"] - e["cout2"])} € par an sur cette seule référence, libère {fr(e["val1"] - e["val2"])} € de trésorerie et rend 29 heures de machine. La quantité économique varie comme la racine de $L$ : c’est le lien entre le SMED et la taille des lots.'])],
   comp='Wilson ne dit pas « faites de gros lots ». Il dit : la taille du lot dépend du coût de lancement. Si on réduit ce coût, les petits lots deviennent rentables.',
   err=['Croire que diviser $L$ par 4 divise $Q_e$ par 4 : c’est la racine qui compte.'])

# ====================================================================== SÉANCE 3
e = E[10]
ex(n=10, titre='Premier point de commande', seance=3, src='5.2', duree='15 min',
   ctx=['Un article a une consommation régulière : 780 pièces en 26 semaines. La semaine compte 5 jours ouvrés. Le délai de livraison est de 3 semaines.'],
   qs=[('Calculer la consommation hebdomadaire, puis le point de commande sans stock de sécurité.', [f'780 / 26 = **{fr(e["cs"])} pièces par semaine**. PC = 30 × 3 = **{fr(e["PC"])} pièces**.']),
       ('Il s’écoule 2 jours entre le constat du stock et l’envoi de la commande. Que devient le point de commande ? Quel stock supplémentaire ce délai administratif immobilise-t-il ?',
        [f'Consommation par jour : 30 / 5 = {fr(e["cj"])} pièces. Le délai réel est de 3 semaines et 2 jours : PC = 90 + 2 × 6 = **{fr(e["PC2"])} pièces**.', f'Le délai administratif immobilise **{fr(e["immo"])} pièces** en permanence. Raccourcir un circuit de signature fait baisser le stock.']),
       ('On veut se couvrir contre un retard de livraison de 4 jours. Calculer le stock de sécurité et le nouveau point de commande.', [f'SS = 4 × 6 = **{fr(e["SS"])} pièces**. PC = 102 + 24 = **{fr(e["PC3"])} pièces**.'], '6.1')],
   comp='Le point de commande couvre tout le temps qui sépare le constat de la réception : délai administratif, délai fournisseur, marge.',
   err=['Mélanger jours et semaines.', 'Ajouter le stock de sécurité à la quantité commandée au lieu de l’ajouter au seuil.'])

e = E[11]
ex(n=11, titre='Étude de cas FONSABLE (ECI n° 17)', seance=3, src='5.2', duree='1 h 15, suivie du TP 3',
   ctx=['FONSABLE moule des pièces en fonte au sable. Le sable de fonderie arrive par voie ferrée. Données :',
        ('b', ['commande par wagons entiers de 55 tonnes ;', 'stockage dans 8 silos de 110 tonnes ;', 'délai d’approvisionnement : 30 jours ;',
               'consommation moyenne : 13,75 tonnes par jour, 330 jours par an (usine en 3 × 8, un mois de fermeture) ;',
               'stock de sécurité voulu : 20 jours de fabrication ;', 'prix du sable : 120 € la tonne ;',
               'après chaque livraison, le gestionnaire veut retrouver 880 tonnes en stock.'])],
   qs=[('Évaluer en tonnes le stock maximal et le stock de sécurité.', [f'Stock maximal : 8 × 110 = **{fr(e["smax"])} t** (capacité des silos, égale à l’objectif du gestionnaire). Stock de sécurité : 20 × 13,75 = **{fr(e["SS"])} t**.'], '6.1'),
       ('Calculer le stock d’alerte (point de commande).', [f'PC = 13,75 × 30 + 275 = 412,5 + 275 = **{fr(e["PC"], 1)} t**.']),
       ('Déterminer la quantité à commander, le délai entre deux commandes et le nombre de commandes par an.',
        [f'La livraison arrive quand le stock vaut 275 t et doit le ramener à 880 t : $Q$ = 880 − 275 = **{fr(e["Q"])} t**, soit {fr(e["wag"])} wagons entiers.', f'Délai entre deux commandes : 605 / 13,75 = **{fr(e["per"])} jours**. Cadence : 330 / 44 = **{fr(e["n"], 1)} commandes par an**.']),
       ('Exprimer le stock en fonction du nombre de jours $j$ écoulés depuis J0, jour où le stock est maximal.', [('eqs', [r'S(j) = 880 - \text{13,75}\,j', r'\text{pour}', r'0 \le j \le 44']), f'Le stock d’alerte est atteint quand 880 − 13,75 $j$ = 687,5, soit $j$ = **{fr(e["t1"])}**.']),
       ('Représenter le stock de J0 à J100 sur la grille. La deuxième commande est livrée avec 10 jours de retard.',
        [('f', 'c01_fonsable', 'Exercice 11 : évolution du stock de sable avec un retard sur la 2e livraison', 15),
         T(['Événement', 'Jour', 'Stock (t)'], [['Commande 1', 'J14', '687,5'], ['Livraison 1', 'J44', '275 puis 880'], ['Commande 2', 'J58', '687,5'], ['Livraison 2 prévue', 'J88', '275'],
                                              ['Livraison 2 réelle (10 jours de retard)', 'J98', f'{fr(e["smin_retard"], 1)} puis 742,5']], [5, 1.6, 3], hl=(4,)),
         f'Pendant le retard, l’usine consomme 137,5 t dans le stock de sécurité. Il en reste {fr(e["smin_retard"], 1)} t : la sécurité de 20 jours absorbe un retard de 10 jours. Le stock remonte à 742,5 t. La commande 3 part normalement à J102.']),
       ('Le coût de passation est de 1 210 € par commande et le taux de possession de 16 %. Donner CPA, CPO et CT en fonction du nombre annuel de commandes $n$. Quel $n$ minimise le coût ? Est-il compatible avec les silos ?',
        [f'Consommation annuelle : 13,75 × 330 = {fr(e["Can"], 1)} t. Quantité par commande : 4 537,5 / $n$. Stock moyen : 4 537,5 / (2 $n$) + 275.',
         ('eq', r'\text{CPA} = \text{1 210}\,n'),
         ('eq', r'\text{CPO} = 120 \times \text{0,16} \times \left(\dfrac{\text{4 537,5}}{2\,n} + 275\right) = \dfrac{\text{43 560}}{n} + \text{5 280}'),
         ('eq', r'\text{CT} = \text{1 210}\,n + \dfrac{\text{43 560}}{n} + \text{5 280}'),
         f'Minimum : 1 210 $n$ = 43 560 / $n$, soit $n$² = 36 et **$n$ = 6**. Alors CT = 7 260 + 7 260 + 5 280 = **{fr(e["CT"](6))} €**.',
         f'Avec $n$ = 6, chaque commande vaut 756,25 t, soit 13,75 wagons : il faudrait 14 wagons (770 t). Le stock monterait à 275 + 770 = 1 045 t. Les silos n’en contiennent que 880. **L’optimum n’est pas réalisable.**',
         f'Avec 11 wagons ($n$ = 7,5) : CT = 9 075 + 5 808 + 5 280 = **{fr(e["CT"](7.5))} €**. La contrainte des silos coûte {fr(e["CT"](7.5) - e["CT"](6))} € par an. C’est très loin du prix d’un silo : on garde 11 wagons.',
         ('f', 'c02_fonsable_couts', 'Exercice 11 : coûts annuels en fonction du nombre de commandes', 13.5)], '4.1')],
   comp='Un cas réel empile les contraintes : wagons entiers, capacité des silos, sécurité imposée. On calcule l’optimum, puis on mesure ce que coûte chaque contrainte. Ici, presque rien.',
   err=['Oublier le stock de sécurité dans le stock d’alerte.', 'Prendre 880 t comme quantité commandée.', 'Oublier le terme constant 5 280 € (possession du stock de sécurité) dans CPO.', 'Sur le graphique, faire remonter le stock à 880 t après la livraison en retard.'])

e = E[12]
ex(n=12, titre='Recomplètement périodique', seance=3, src='5.3', duree='20 min',
   ctx=[f'De la visserie est gérée par recomplètement. Consommation moyenne : {e["cs"]} pièces par semaine. Délai : {e["D"]} semaines. Revue du stock toutes les {e["d"]} semaines. Stock de sécurité : {e["SS"]} pièces.'],
   qs=[('Calculer le niveau de recomplètement.', [f'NR = 400 × (2 + 4) + 300 = **{fr(e["NR"])} pièces**.']),
       ('À la première revue, le stock est de 1 150 pièces et rien n’est en commande. Quelle quantité commander ?', [f'$Q$ = 2 700 − 1 150 = **{fr(e["Q1"])} pièces**.']),
       ('À la revue suivante, le stock est de 900 pièces, rien en commande. Quantité ?', [f'$Q$ = 2 700 − 900 = **{fr(e["Q2"])} pièces**. La consommation a été plus forte : la commande grossit d’elle-même.']),
       ('À la troisième revue, le stock est de 1 400 pièces et une commande de 600 n’est pas encore arrivée. Quantité ?', [f'On raisonne sur le stock disponible : 1 400 + 600 = 2 000. $Q$ = 2 700 − 2 000 = **{fr(e["Q3"])} pièces**.'], '5.4'),
       ('Quel est l’intérêt de cette méthode pour de la visserie ? Son défaut ?', ['Intérêt : une seule commande groupée pour toutes les références du fournisseur, à date connue. Défaut : entre deux revues on ne voit rien. Il faut un stock de sécurité qui couvre 6 semaines au lieu de 2.'])],
   comp='En recomplètement, la date est fixe et la quantité s’adapte. Le niveau NR couvre le délai plus l’intervalle de revue.',
   err=['Écrire NR = 400 × 2 + 300 en oubliant l’intervalle de revue.', 'Oublier la commande en cours en question 4 : on commanderait 600 de trop.'])

e = E[13]
ex(n=13, titre='Quand le délai dépasse la couverture d’une commande', seance=3, src='5.4', duree='20 min',
   ctx=[f'Un composant importé : consommation de {e["cj"]} pièces par jour, délai de {e["D"]} jours, commandes de {fr(e["Q"])} pièces. On néglige le stock de sécurité.'],
   qs=[('Combien de jours une commande couvre-t-elle ?', [f'1 000 / 50 = **{fr(e["couv"])} jours**.'], '2.5'),
       ('Calculer le point de commande. Quel problème pose-t-il ?', [f'PC = 50 × 30 = **{fr(e["PC"])} pièces**. Or le stock en rayon ne dépasse jamais 1 000 pièces. Comparé au stock physique, ce seuil serait franchi en permanence.']),
       ('Combien de commandes sont en route en même temps ?', ['Le délai (30 jours) vaut 1,5 fois la couverture (20 jours). Il y a donc toujours une commande en route, et deux pendant la moitié du temps.']),
       ('Comment appliquer la méthode ? Donner le seuil à surveiller sur le stock physique.',
        ['On compare au point de commande le **stock disponible** : stock physique + commandes en route. On commande quand il descend à 1 500.',
         f'Traduction sur le stock physique : au moment de commander, une commande de 1 000 est déjà en route. Le seuil physique est 1 500 − 1 000 = **{fr(e["PCphys"])} pièces**, soit 10 jours de consommation (30 − 20).'])],
   comp='Le point de commande se compare à ce que l’on a et à ce que l’on attend. Oublier les commandes en route fait commander deux fois.',
   err=['Comparer 1 500 au seul stock en rayon.', 'Augmenter la quantité commandée pour « passer au-dessus » du seuil : on gonfle le stock au lieu de corriger la règle.'])

# ====================================================================== SÉANCE 4
e = E[14]
ex(n=14, titre='Stock de sécurité sans probabilités', seance=4, src='6.1', duree='15 min',
   ctx=['Un article est consommé à raison de 50 pièces par jour. Le délai de livraison est de 5 jours.'],
   qs=[('Quel stock de sécurité couvre un retard de livraison de 2 jours ?', [f'SS = 50 × 2 = **{fr(e["ss_ret"])} pièces**.']),
       ('Quel stock de sécurité couvre une consommation supérieure de 20 % pendant le délai ?', [f'La consommation passe à 60 par jour. SS = (60 − 50) × 5 = **{fr(e["ss_conso"])} pièces**.']),
       ('Et si les deux aléas se produisent ensemble ?', [f'Besoin : 60 × 7 = 420 pièces. Couverture normale : 250. SS = **{fr(e["ss_les2"])} pièces**. C’est plus que la somme 100 + 50, car la surconsommation joue aussi pendant les jours de retard.']),
       ('Quel stock de sécurité retenir ? En déduire le point de commande.', [f'On retient l’aléa le plus pénalisant, sans les cumuler : **SS = 100 pièces**, PC = 250 + 100 = **{fr(e["PC"])} pièces**. Cumuler les deux aléas revient à payer en permanence pour une situation rare.'])],
   comp='L’approche déterministe répond à « combien pour tenir tel aléa ». Elle ne dit pas avec quelle probabilité cet aléa arrive.',
   err=['Additionner les deux stocks de sécurité par réflexe.'])

e = E[15]
ex(n=15, titre='Stock de sécurité et loi normale', seance=4, src='6.2', duree='20 min',
   ctx=['La consommation hebdomadaire d’un article suit une loi normale de moyenne 250 et d’écart-type 40 pièces. Les semaines sont indépendantes. Le délai est de 2 semaines. On vise un taux de service de 97,5 %.'],
   qs=[('Quelle loi suit la demande pendant le délai ?', [f'Somme de deux lois normales indépendantes : moyenne 2 × 250 = 500, variance 2 × 40² = 3 200, écart-type 40 × √2 = **{fr(e["sD"], 2)}**. La demande suit $\\mathcal{{N}}(500\\ ;\\ \\text{{56,57}})$.']),
       ('Calculer le stock de sécurité et le point de commande.', [f'Pour 97,5 %, $z$ = 1,96. SS = 1,96 × 56,57 = {fr(e["SS"], 1)}, arrondi à **{e["SSa"]} pièces** (on arrondit au-dessus). PC = 500 + 111 = **{e["PC"]} pièces**.']),
       ('Un collègue trouve 157 pièces. Quelle erreur a-t-il commise ?', [f'Il a écrit $z\\,\\sigma\\,D$ = 1,96 × 40 × 2 = {fr(e["faux"], 1)}. Il a multiplié l’écart-type par $D$ au lieu de $\\sqrt{{D}}$. Ce sont les variances qui s’ajoutent, pas les écarts-types.'])],
   comp='Sur plusieurs périodes indépendantes, l’incertitude grandit comme la racine de la durée.',
   err=['Multiplier par $D$ au lieu de $\\sqrt{D}$.', 'Arrondir le stock de sécurité à l’entier inférieur : le taux visé n’est plus atteint.', 'Prendre $z$ = 1,645 (95 %) au lieu de 1,96 (97,5 %).'])

e = E[16]
ex(n=16, titre='Quel service pour un seuil donné ?', seance=4, src='6.2', duree='20 min',
   ctx=['On reprend l’article de l’exercice 15 : demande pendant le délai de moyenne 500 et d’écart-type 56,57. Le magasinier a fixé le point de commande à 560 pièces. L’article est commandé 12,5 fois par an.'],
   qs=[('Calculer le taux de service obtenu.', [f'$z$ = (560 − 500) / 56,57 = {fr(e["z"], 2)}. La table donne $\\Phi(\\text{{1,06}})$ = **{pc(e["ts"])}**. Dans Excel : LOI.NORMALE.N(560 ; 500 ; 56,57 ; VRAI).'], 'B'),
       ('Combien de ruptures par an peut-on attendre ?', [f'Risque par cycle : 1 − 0,856 = 14,4 %. Sur 12,5 cycles : 12,5 × 0,144 = **{fr(e["rupt_an"], 1)} rupture par an** en moyenne.']),
       ('Et sans stock de sécurité ?', [f'PC = 500 : $z$ = 0, service de 50 %. Une commande sur deux arrive après la rupture, soit **{fr(e["rupt0"], 2)} ruptures par an**. Sans stock de sécurité, la rupture est la situation normale.'])],
   comp='Un taux de service se lit par cycle. Pour parler à un chef d’atelier, on le traduit en ruptures par an.',
   err=['Lire la table à l’envers (donner 14,4 % comme taux de service).', 'Oublier de multiplier par le nombre de cycles.'])

e = E[17]
ex(n=17, titre='Quand le délai varie aussi', seance=4, src='6.4', duree='20 min', bach=True,
   ctx=['Consommation journalière : moyenne 50, écart-type 12 pièces. Délai : moyenne 5 jours, écart-type 1 jour. Consommation et délai sont indépendants. Taux de service visé : 95 %.'],
   qs=[('Calculer l’écart-type de la demande pendant le délai.', [('eq', r'\sigma = \sqrt{D\,\sigma_x^{2} + C_{\text{moy}}^{2}\,\sigma_D^{2}}'), f'σ = √(5 × 144 + 2 500 × 1) = √3 220 = **{fr(e["sig"], 1)} pièces**.']),
       ('Calculer le stock de sécurité. Comparer au cas d’un délai fixe.', [f'SS = 1,645 × 56,7 = {fr(e["SS"], 1)}, soit **94 pièces**. À délai fixe : 1,645 × 12 × √5 = {fr(e["SSfix"], 1)}, soit 45 pièces. Le stock de sécurité double.']),
       ('Quelle part de la variance vient du délai ?', [f'2 500 / 3 220 = **{pc(e["part"])}**. Les trois quarts du stock de sécurité servent à couvrir l’irrégularité du fournisseur.']),
       ('Le fournisseur s’engage à diviser par deux l’écart-type de son délai. Nouveau stock de sécurité ?', [f'σ = √(720 + 2 500 × 0,25) = √1 345 = {fr(e["sig_half"], 1)}. SS = 1,645 × 36,7 = {fr(e["SS_half"], 1)}, soit **61 pièces**. On gagne 33 pièces sans toucher à la consommation.'])],
   comp='Les variances s’ajoutent, et celle du délai est multipliée par le carré de la consommation. Un fournisseur irrégulier coûte plus cher qu’une demande irrégulière.',
   err=['Additionner les écarts-types au lieu des variances.', 'Oublier de multiplier $\\sigma_D$ par la consommation moyenne pour le convertir en pièces.'])

e = E[18]
ex(n=18, titre='Pièce de rechange et loi de Poisson', seance=4, src='6.5', duree='30 min',
   ctx=[f'Un servomoteur de rechange sort du magasin {e["an"]} fois par an en moyenne. Délai de réapprovisionnement : 1 mois. Prix : {fr(e["prix"])} €. Taux de possession : 25 %. Le magasin commande par 2 pièces, soit 3 commandes par an.'],
   qs=[('Calculer le paramètre λ de la loi de Poisson qui décrit la demande pendant le délai.', [f'λ = 6 × 1 / 12 = **{fr(e["lam"], 1)}** pièce en moyenne pendant le délai.']),
       ('Dresser le tableau de $P(X = k)$ et $P(X \\le k)$ pour $k$ de 0 à 4.',
        [T(['$k$', '0', '1', '2', '3', '4'], [['$P(X = k)$'] + [fr(p, 4) for p in e['pmf']], ['$P(X \\le k)$'] + [fr(p, 4) for p in e['cdf']]], [2, 1.5, 1.5, 1.5, 1.5, 1.5], align=['left'] + ['center'] * 5),
         'Rappel : $P(X = k) = e^{-\\lambda}\\,\\lambda^{k} / k!$. Dans Excel : LOI.POISSON.N(k ; 0,5 ; FAUX) et LOI.POISSON.N(k ; 0,5 ; VRAI).'], 'B'),
       ('Quel point de commande pour un taux de service de 95 % ? de 99 % ?', [f'95 % : $P(X \\le 1)$ = 91,0 % ne suffit pas, $P(X \\le 2)$ = 98,6 % convient. **$s$ = {e["s95"]}**. 99 % : $P(X \\le 3)$ = 99,8 %. **$s$ = {e["s99"]}**.']),
       ('Que coûte par an la détention d’une pièce supplémentaire ?', [f'1 800 × 0,25 = **{fr(e["cout_unite"])} € par an**.'], '2.2'),
       ('Une rupture arrête la ligne 16 heures, à 2 500 € l’heure. Calculer le coût annuel espéré des ruptures pour $s$ = 1, 2, 3 et 4. Quel seuil retenir ?',
        [T(['Seuil $s$', 'Risque par cycle', 'Ruptures par an (3 cycles)', 'Coût espéré (€ par an)', 'Gain de la pièce ajoutée (€)'],
           [[str(k), fr(100 * (1 - e['cdf'][k]), 2) + ' %', fr(e['rupt'][k], 4), fr(e['cout_rupt'][k]), '' if k == 1 else fr(e['marg'][k - 1])] for k in (1, 2, 3, 4)],
           [1.2, 1.8, 2.4, 2.2, 2.4], align=['center', 'right', 'right', 'right', 'right'], hl=(2,)),
         f'Passer de 2 à 3 pièces coûte 450 € et évite {fr(e["marg"][2])} € de ruptures : on le fait. Passer de 3 à 4 coûte 450 € et n’évite que {fr(e["marg"][3])} € : on s’arrête. **Seuil retenu : $s$ = 3**, au-dessus de la règle des 95 %.'])],
   comp='Pour une pièce de rechange, le taux de service se déduit du coût de l’arrêt. Plus la rupture coûte cher, plus le seuil monte.',
   err=['Prendre λ = 6 (consommation annuelle) au lieu de la consommation pendant le délai.', 'Lire $P(X = k)$ au lieu de $P(X \\le k)$.', 'Appliquer la loi normale à des sorties aussi rares.'])

e = E[19]
ex(n=19, titre='Stock de sécurité en recomplètement périodique', seance=4, src='6.4', duree='15 min',
   ctx=['L’article de l’exercice 15 (moyenne 250 et écart-type 40 par semaine, délai de 2 semaines) passe en recomplètement périodique, avec une revue toutes les 4 semaines. Taux de service : 95 %.'],
   qs=[('Calculer le stock de sécurité.', [f'SS = 1,645 × 40 × √(2 + 4) = 1,645 × 97,98 = {fr(e["SSrec"], 1)}, soit **162 pièces**.']),
       ('Calculer le niveau de recomplètement.', [f'NR = 250 × 6 + 162 = **{fr(e["NR"])} pièces**.'], '5.3'),
       ('Comparer au stock de sécurité du point de commande, au même taux de service.', [f'Au point de commande : 1,645 × 40 × √2 = {fr(e["SSpc"], 1)}, soit 94 pièces. Le recomplètement en demande **{e["ecart"]} de plus**. C’est le prix de la simplicité : on ne regarde le stock qu’une fois par mois.'], '6.2')],
   comp='Moins on regarde le stock, plus il faut de marge.',
   err=['Écrire √2 + √4 au lieu de √6.'])

ex(n=20, titre='Quelle méthode pour quel article ?', seance=4, src='5.5', duree='15 min',
   ctx=['Pour chaque article, proposer une méthode de gestion et la justifier en une phrase.',
        T(['', 'Article', 'Caractéristiques'], [['a', 'Tube aluminium TA-63', '84 000 € consommés par an, fournisseur régulier'], ['b', 'Rondelles M6', '2 000 € par an, 50 000 pièces'],
                                              ['c', 'Variateur 4 kW de rechange', '2 sorties par an, arrêt de ligne s’il manque'], ['d', 'Dix références de visserie', 'Même fournisseur, faible valeur'],
                                              ['e', 'Laiton en barres', 'Cours très variable d’un mois à l’autre']], [0.6, 3.6, 5.4])],
   qs=[('Compléter le tableau.',
        [T(['', 'Méthode', 'Justification'], [
            ['a', 'Point de commande, quantité proche de $Q_e$, stock de sécurité calculé', 'Classe A : l’argent en jeu justifie un suivi permanent.'],
            ['b', 'Double bac ou recomplètement périodique', 'Classe C : la gestion ne doit pas coûter plus que l’article.'],
            ['c', 'Point de commande à l’unité, loi de Poisson, service de 99 %', 'Sorties rares, rupture coûteuse.'],
            ['d', 'Recomplètement périodique groupé', 'Une seule commande pour dix lignes : on divise le coût de passation.'],
            ['e', 'Dates et quantités variables', 'L’acheteur suit le cours et achète quand le prix est bas.']], [0.6, 4.6, 4.4], size=19)])],
   comp='Il n’y a pas de meilleure méthode en général. Le choix dépend de la valeur de l’article, de sa régularité et du coût d’une rupture.',
   err=['Vouloir un point de commande calculé sur tous les articles : la charge de suivi explose.'])

# ====================================================================== TP
TP = []
def tp(**k): TP.append(k)
t1 = R['tp1']
tp(n=1, titre='Analyse ABC de 40 références', seance=1, src='3.1', duree='1 h 15', feuille='TP1_ABC',
   but='Construire une analyse ABC complète sous Excel : tri, cumuls, courbe dans un carré, ratio de discrimination, classes.',
   donnees='La feuille contient 40 lignes : référence (A), désignation (B), consommation annuelle (C), prix unitaire (D). Les données commencent en ligne 2.',
   etapes=['En E1, saisir « Valeur consommée ». En E2 : **=C2*D2**. Recopier jusqu’en E41.',
           'Sélectionner A1:E41 et trier sur la colonne E, du plus grand au plus petit (Données > Trier).',
           'En F2, la part de l’article : **=E2/SOMME($E$2:$E$41)**. Recopier. Format pourcentage.',
           'En G2, le cumul : **=F2**. En G3 : **=G2+F3**. Recopier. La dernière ligne doit afficher 100 %.',
           'En H2, le rang en pourcentage : **=(LIGNE()-1)/40**. Recopier.',
           'En I2, la diagonale : **=1-H2**. Recopier.',
           'Insérer un nuage de points avec courbes : série 1 (H ; G), série 2 (H ; I). Fixer les deux axes de 0 à 100 % et donner à la zone de traçage une forme carrée.',
           'En J2, repérer le croisement : **=SI(G2>=I2;"oui";"")**. Recopier. La première ligne marquée « oui » encadre le point C.',
           'Calculer le ratio de discrimination par interpolation entre cette ligne et la précédente (voir l’aide ci-dessous).',
           'En K2, la classe, selon la répartition trouvée : **=SI(H2<=0,2;"A";SI(H2<=0,4;"B";"C"))**. Adapter les seuils au ratio obtenu.',
           'Colorer les classes par une mise en forme conditionnelle. Compter les articles et la valeur de chaque classe avec NB.SI et SOMME.SI.'],
   aide=['Interpolation. Entre la ligne i − 1 et la ligne i, la courbe monte de G(i − 1) à G(i) quand H avance de 2,5 %. On cherche $x$ tel que la courbe vaille 1 − $x$ :',
         ('eqs', [r'a = \dfrac{G_i - G_{i-1}}{H_i - H_{i-1}}', r'x = \dfrac{1 - G_{i-1} + a\,H_{i-1}}{1 + a}', r'\text{RD} = 1 - x'])],
   qs=[('Quelle est la valeur consommée totale ?', [f'**{fr(t1["total"], 2)} €**.']),
       ('Quel ratio de discrimination obtenez-vous ? Quelle répartition en découle ?', [f'Le croisement a lieu à $x$ = {pc(t1["xc"] / 100)} des articles. **RD = {fr(t1["rd"], 3)}**, compris entre 0,75 et 0,85 : répartition 20 / 20 / 60.', ('f', 'c03_tp1_abc', 'TP 1 : courbe ABC des 40 références', 9)], '3.2'),
       ('Combien d’articles et quelle part de la valeur dans chaque classe ?',
        [T(['Classe', 'Articles', 'Part de la valeur'], [['A', str(t1['nA']), pc(t1['pA'])], ['B', str(t1['nB']), pc(t1['pB'])], ['C', str(40 - t1['nA'] - t1['nB']), pc(1 - t1['pA'] - t1['pB'])]], [2, 2, 3], align=['center', 'center', 'right']),
         f'Les 8 articles A sont, dans l’ordre : {", ".join(t1["top"])}.']),
       ('Que proposez-vous pour les 24 articles de classe C ?', ['Ils pèsent moins de 10 % de la valeur. On les passe en recomplètement périodique ou en double bac, avec un inventaire annuel. Le temps gagné va au suivi des 8 articles A.'], '5.5')],
   formules=[('E2', '=C2*D2'), ('F2', '=E2/SOMME($E$2:$E$41)'), ('G3', '=G2+F3'), ('H2', '=(LIGNE()-1)/40'), ('K2', '=SI(H2<=0,2;"A";SI(H2<=0,4;"B";"C"))')],
   err=['Trier une seule colonne : les références ne suivent plus leurs valeurs.', 'Laisser Excel étirer le graphique en rectangle.', 'Oublier les \\$ dans le total de F2.'])

tp(n=2, titre='Courbes de coûts et quantité économique', seance=2, src='4.2', duree='1 h', feuille='TP2_Wilson',
   but='Faire apparaître le minimum du coût de gestion sur un graphique, le retrouver par la formule, puis tester une remise et un chantier SMED.',
   donnees='La feuille donne les paramètres de l’embout ET-16 en B2:B5 (C, L, P, T) et le tarif à trois paliers en A9:B11.',
   etapes=['Nommer les cellules B2 à B5 : C_, L_, P_, T_ (zone Nom, à gauche de la barre de formule). Les formules seront lisibles.',
           'En D2:D31, saisir les quantités de 100 à 3 000, de 100 en 100.',
           'En E2 : **=C_/D2*L_** (CL). En F2 : **=D2/2*P_*T_** (CS). En G2 : **=E2+F2**. Recopier.',
           'Tracer E, F et G en fonction de D (nuage de points avec courbes lissées). Limiter l’axe vertical à 3 000 €.',
           'Lire sur le graphique la quantité qui minimise G. La retrouver dans le tableau avec **=INDEX(D2:D31;EQUIV(MIN(G2:G31);G2:G31;0))**.',
           'En B6, la formule de Wilson : **=RACINE(2*C_*L_/(P_*T_))**. Comparer.',
           'Tarif : pour chaque palier, calculer la quantité économique au prix du palier, la quantité retenue (**=MAX(seuil;Qe)** si Qe est sous le seuil), puis CA, CL, CS et CGA.',
           'Repérer le CGA minimal avec MIN, et afficher le palier gagnant.',
           'Simulation SMED : remplacer L par 10 €. Observer le graphique et la quantité économique. Remettre 40 € ensuite.'],
   qs=[('Quelle quantité minimise CS + CL ? Que valent alors CS et CL ?', [f'**1 000 pièces**. CS = CL = 500 €, total 1 000 €. Le tableau et la formule donnent le même résultat.']),
       ('Quel palier de prix retenir ?',
        [T(['Prix', '$Q_e$', 'Quantité retenue', 'CGA (€)'], [[fr(r['p'], 2) + ' €', fr(r['qe'], 1), fr(r['q']), fr(r['cga'], 2)] for r in R['remise']], [2, 2, 2.6, 2.6], align=['left', 'right', 'right', 'right'], hl=(1,)),
         'On commande par 3 000 à 3,90 €.'], '4.4'),
       ('Que devient la quantité économique avec L = 10 € ? Commenter.', ['$Q_e$ = √(2 × 12 500 × 10 / 1) = **500 pièces**, et CS + CL tombe à 500 €. Diviser le coût de commande par 4 divise le lot et le coût par 2. La courbe de CL s’écrase, le minimum glisse vers la gauche.'], '4.5')],
   formules=[('E2', '=C_/D2*L_'), ('F2', '=D2/2*P_*T_'), ('B6', '=RACINE(2*C_*L_/(P_*T_))'), ('minimum', '=INDEX(D2:D31;EQUIV(MIN(G2:G31);G2:G31;0))')],
   err=['Écrire T_ = 25 au lieu de 25 %.', 'Tracer un graphique en courbes (axe des catégories) au lieu d’un nuage de points : l’échelle horizontale est faussée dès que le pas change.'])

F = E[11]
tp(n=3, titre='Simuler le stock de FONSABLE', seance=3, src='5.2', duree='1 h 30', feuille='TP3_FONSABLE',
   but='Construire un simulateur jour par jour du stock de sable, y introduire un retard de livraison, puis tracer les coûts en fonction du nombre de commandes.',
   donnees='La feuille donne les paramètres en B2:B11 : stock initial (880), consommation par jour (13,75), stock d’alerte (687,5), quantité commandée (605), délai (30), prix (120), coût de passation (1 210), taux de possession (16 %), jours travaillés par an (330), stock de sécurité (275). Le tableau des retards est en D2:E6 (numéro de commande, retard en jours).',
   etapes=['Partie A. En ligne 12, saisir les titres : Jour, Stock début, Consommation, Réception, Stock fin, Commande passée, N° de commande, Jour d’arrivée, En cours.',
           'Ligne 13 (jour 0) : Jour = 0, Stock fin = **=$B$2**, les autres colonnes à 0 ou vides.',
           'Ligne 14 (jour 1) : Jour **=A13+1** ; Stock début **=E13** ; Consommation **=$B$3**.',
           'Réception en D14 : **=SOMME.SI($H$13:H13;A14;$F$13:F13)**. Elle additionne les commandes dont le jour d’arrivée est aujourd’hui.',
           'Stock fin en E14 : **=B14-C14+D14**.',
           'Commande passée en F14 : **=SI(E14+I13-D14<=$B$4;$B$5;0)**. On compare le stock disponible (physique + en cours) au stock d’alerte.',
           'N° de commande en G14 : **=SI(F14>0;MAX($G$13:G13)+1;"")**. Jour d’arrivée en H14 : **=SI(F14>0;A14+$B$6+RECHERCHEV(G14;$D$2:$E$6;2;FAUX);"")**.',
           'En cours en I14 : **=I13-D14+F14**. Recopier la ligne 14 jusqu’au jour 100.',
           'Tracer le stock fin en fonction du jour. Ajouter deux séries horizontales : stock d’alerte et stock de sécurité (275).',
           'Saisir un retard de 10 jours pour la commande n° 2 dans le tableau des retards. Observer.',
           'Partie B. Dans un second tableau (à partir de L12), faire varier n de 2 à 14. Calculer CPA, CPO et CT à partir des paramètres. Vous devez retrouver CPA = 1 210 n et CPO = 43 560 / n + 5 280. Tracer les trois courbes et repérer le minimum.'],
   qs=[('À quels jours les commandes partent-elles et arrivent-elles, sans retard puis avec le retard ?', ['Sans retard : commandes à J14 et J58, livraisons à J44 et J88. Avec le retard : la livraison 2 arrive à J98. La commande 3 part à J102, hors du tableau.', ('f', 'c01_fonsable', 'TP 3 : stock simulé avec 10 jours de retard sur la 2e livraison', 14.5)]),
       ('Quel est le stock le plus bas atteint ? Le stock de sécurité a-t-il suffi ?', [f'Dans le simulateur, le stock fin le plus bas est de 151,25 t, le soir de J97. Le matin de J98, avant la livraison, il reste 151,25 − 13,75 = **{fr(F["smin_retard"], 1)} t**. Le stock de sécurité (275 t) est à moitié consommé : il a suffi.'], '6.1'),
       ('Quel retard maximal le système supporte-t-il sans rupture ? Vérifier avec le simulateur.', ['275 / 13,75 = **20 jours**. Au-delà, le simulateur affiche un stock négatif : c’est la rupture. Il faut prolonger le tableau après J100 pour le voir.'], '6.1'),
       ('Quel nombre de commandes minimise le coût total ? Pourquoi FONSABLE ne l’applique-t-elle pas ?', [f'**n = 6**, avec CT = {fr(F["CT"](6))} €. Mais il faudrait des livraisons de 14 wagons et 1 045 t de capacité. Avec 11 wagons (n = 7,5), CT = {fr(F["CT"](7.5))} €, soit {fr(F["CT"](7.5) - F["CT"](6))} € de plus par an.', ('f', 'c02_fonsable_couts', 'TP 3 : coûts en fonction du nombre de commandes', 13)], '4.1')],
   formules=[('D14', '=SOMME.SI($H$13:H13;A14;$F$13:F13)'), ('E14', '=B14-C14+D14'), ('F14', '=SI(E14+I13-D14<=$B$4;$B$5;0)'), ('H14', '=SI(F14>0;A14+$B$6+RECHERCHEV(G14;$D$2:$E$6;2;FAUX);"")'), ('I14', '=I13-D14+F14')],
   err=['Comparer le seul stock physique au stock d’alerte : avec un retard, le simulateur repasse commande chaque jour.', 'Mal placer les \\$ : la plage de SOMME.SI doit s’allonger d’une ligne à chaque recopie.', 'Inclure la ligne courante dans la plage de SOMME.SI : référence circulaire.'])

t4 = R['tp4']
tp(n=4, titre='Du relevé de consommation au stock de sécurité', seance=4, src='6.2', duree='1 h', feuille='TP4_Historique',
   but='Partir de 52 semaines de consommation réelle, vérifier que la loi normale convient, puis calculer le stock de sécurité pour plusieurs taux de service.',
   donnees='La feuille contient la consommation hebdomadaire de la tige chromée TC-20 : semaine (A2:A53), quantité (B2:B53). Le délai de livraison est de 3 semaines.',
   etapes=['Calculer la moyenne, l’écart-type, le minimum et le maximum : MOYENNE, ECARTYPE.STANDARD, MIN, MAX sur B2:B53.',
           'Construire un histogramme par classes de 5 pièces, de 15 à 65. Avec les bornes basses en D2:D11 : **=NB.SI.ENS($B$2:$B$53;">="&D2;$B$2:$B$53;"<"&D2+5)**. Tracer en barres.',
           'L’histogramme a-t-il une forme de cloche ? Pour ceux qui veulent aller plus loin : tracer la droite de Henry.',
           'Dresser un tableau pour les taux de service 80 %, 90 %, 95 %, 97,5 %, 99 % et 99,9 % : $z$ avec LOI.NORMALE.STANDARD.INVERSE.N, puis SS = z × s × RACINE(3), arrondi au-dessus avec ARRONDI.SUP.',
           'Calculer le point de commande pour 95 %.',
           'Tracer le stock de sécurité en fonction du taux de service.',
           'Vérification sur l’historique. En C4 : **=SOMME(B2:B4)**, recopié jusqu’en C53 : c’est la consommation de 3 semaines glissantes. Compter avec NB.SI combien de ces fenêtres dépassent le point de commande.'],
   qs=[('Que valent la moyenne et l’écart-type ?', [f'Moyenne : **{fr(t4["m"], 2)} pièces par semaine**. Écart-type : **{fr(t4["s"], 2)}**. Minimum {t4["mn"]}, maximum {t4["mx"]}. Total de l’année : {fr(t4["total"])} pièces.']),
       ('La loi normale est-elle acceptable ?', ['L’histogramme est à peu près symétrique autour de 40, sans valeur aberrante. Avec 52 points, la cloche est irrégulière, c’est normal. On accepte le modèle.', ('f', 'c04_tp4', 'TP 4 : histogramme des 52 semaines et stock de sécurité selon le taux de service', 15.5)]),
       ('Donner le stock de sécurité pour chaque taux de service, et le point de commande à 95 %.',
        [T(['Taux de service'] + [fr(k * 100, 1).replace(',0', '') + ' %' for k in t4['SS']], [['$z$'] + [fr(calc.z(k), 3) for k in t4['SS']], ['SS calculé'] + [fr(v, 1) for v in t4['SS'].values()], ['SS retenu'] + [str(math.ceil(v)) for v in t4['SS'].values()]],
           [2.2] + [1.2] * 6, align=['left'] + ['center'] * 6, size=19, hl=(2,)),
         f'Écart-type sur 3 semaines : {fr(t4["s"], 2)} × √3 = {fr(t4["s"] * 3 ** 0.5, 2)}. Point de commande à 95 % : {fr(t4["m"], 2)} × 3 + 27 = {fr(t4["m"] * 3 + 27, 1)}, soit **{t4["PC95e"]} pièces**.']),
       ('Sur l’historique, combien de fenêtres de 3 semaines dépassent ce point de commande ? Commenter.',
        [f'**{t4["depass"]} fenêtres sur {t4["roll_n"]}**, soit un service observé de {pc(t4["obs"], 0)}, un peu sous les 95 % visés. La plus forte consommation sur 3 semaines atteint {t4["roll_max"]} pièces.',
         'Les quatre dépassements tombent tous dans les six dernières semaines : la consommation monte en fin d’année (60, 63 et 68 pièces en semaines 47, 49 et 50). L’hypothèse d’une moyenne stable ne tient plus. Il faut recalculer les paramètres quand la tendance change. Autre limite : les fenêtres glissantes se chevauchent, une même semaine forte compte trois fois.'])],
   formules=[('moyenne', '=MOYENNE(B2:B53)'), ('écart-type', '=ECARTYPE.STANDARD(B2:B53)'), ('z', '=LOI.NORMALE.STANDARD.INVERSE.N(0,95)'), ('SS', '=ARRONDI.SUP(z*s*RACINE(3);0)'), ('C4', '=SOMME(B2:B4)')],
   err=['Utiliser ECARTYPE.PEARSON (population entière) : l’écart est faible ici, mais la bonne fonction pour un échantillon est ECARTYPE.STANDARD.', 'Multiplier par 3 au lieu de RACINE(3).', 'Arrondir le stock de sécurité à l’entier le plus proche.'])

t5 = R['tp5']
tp(n=5, titre='Seuils de pièces de rechange par la loi de Poisson', seance=4, src='6.5', duree='45 min', feuille='TP5_Rechange',
   but='Calculer le point de commande de huit pièces de rechange à partir de la loi de Poisson, et chiffrer le stock immobilisé.',
   donnees='La feuille liste huit pièces : désignation (A), sorties par an (B), délai en mois (C), prix (D), pièce critique oui/non (E). Taux de service visé : 99 % pour une pièce critique, 95 % sinon.',
   etapes=['En F2, le paramètre : **=B2*C2/12**. En G2, le taux visé : **=SI(E2="oui";0,99;0,95)**. Recopier.',
           'En I1:O1, saisir les valeurs de k : 0, 1, 2, 3, 4, 5, 6.',
           'En I2 : **=LOI.POISSON.N(I$1;$F2;VRAI)**. Recopier vers la droite et vers le bas. Chaque ligne donne les probabilités cumulées de la pièce.',
           'En H2, le point de commande : **=NB.SI(I2:O2;"<"&G2)**. La formule compte les valeurs de k dont le cumul reste sous la cible : c’est exactement le plus petit seuil qui convient.',
           'En P2, le taux atteint : **=LOI.POISSON.N(H2;F2;VRAI)**. En Q2, la valeur immobilisée au seuil : **=H2*D2**.',
           'Totaliser la colonne Q.',
           'Essai : le fournisseur de la carte automate ramène son délai de 4 mois à 1 mois. Modifier C6 et observer.'],
   qs=[('Donner le paramètre λ, le seuil et le taux atteint pour chaque pièce.',
        [T(['Pièce', 'Par an', 'Délai (mois)', 'λ', 'Cible', 'Seuil $s$', 'Atteint', 'Valeur (€)'],
           [[r['nom'], str(r['an']), fr(r['dm'], 1).replace(',0', ''), fr(r['lam'], 3), pc(r['ts'], 0), str(r['s']), pc(r['atteint']), fr(r['val'])] for r in t5['rows']] + [['Total', '', '', '', '', '', '', fr(t5['total'])]],
           [3, 1, 1.3, 1, 1, 1.1, 1.2, 1.4], align=['left'] + ['right'] * 7, size=18, total_last=True)]),
       ('Pourquoi le taux atteint dépasse-t-il toujours la cible ?', ['Le seuil est un nombre entier. On prend le premier entier qui atteint la cible, et il la dépasse le plus souvent. Avec des pièces rares, une unité de plus fait un grand saut de probabilité.']),
       ('Que se passe-t-il si le délai de la carte automate passe de 4 mois à 1 mois ?', ['λ passe de 0,333 à 0,083. $P(X \\le 1)$ = 99,7 % : le seuil tombe de 2 à 1. On économise une carte à 1 300 €. Un délai plus court réduit directement le stock, sans risque supplémentaire.']),
       ('Le responsable trouve que 11 465 € de pièces « qui ne bougent pas », c’est trop. Que répondre ?', ['Ces pièces ne sont pas là pour tourner. Elles sont une assurance. On compare leur coût de possession (25 % de 11 465 €, soit environ 2 900 € par an) au coût des arrêts qu’elles évitent. Pour les pièces non critiques, on peut discuter le taux de 95 %.'], '2.2')],
   formules=[('F2', '=B2*C2/12'), ('I2', '=LOI.POISSON.N(I$1;$F2;VRAI)'), ('H2', '=NB.SI(I2:O2;"<"&G2)'), ('Q2', '=H2*D2')],
   err=['Oublier de convertir le délai en fraction d’année.', 'Bloquer la mauvaise référence dans I2 : il faut I\\$1 et \\$F2.', 'Utiliser FAUX au lieu de VRAI : on obtient P(X = k) au lieu du cumul.'])

# ====================================================================== ÉTUDE DE CAS
K = R['cas']; MOIS = ['Janv.', 'Févr.', 'Mars', 'Avril', 'Mai', 'Juin', 'Juil.', 'Août', 'Sept.', 'Oct.', 'Nov.', 'Déc.']
def polrow(lab, k): d = K[k]; return [lab, fr(d['CL'], 2), fr(d['CS'], 2), fr(d['gest'], 2), fr(d['CA']), fr(d['tot'], 2), fr(d['smoy']), fr(d['val']), fr(d['rot'], 1), fr(d['couv'], 1)]
CAS = dict(titre='Étude de cas de synthèse : le tube TA-63 de VÉRILOIRE', duree='1 h 30', src='4.2',
   ctx=['Le tube aluminium profilé TA-63 est le premier article de classe A de VÉRILOIRE. Le responsable logistique vous demande de revoir sa gestion. Le magasinier commande aujourd’hui 1 000 m une fois par trimestre et garde 400 m « de sécurité ».',
        T(['Donnée', 'Valeur'], [['Prix d’achat', '21,00 € le mètre, en barres de 6 m'], ['Coût de passation d’une commande (réception et contrôle compris)', '90 €'], ['Taux de possession', '25 %'],
                                 ['Année de travail', '50 semaines'], ['Consommation hebdomadaire', 'moyenne 80 m, écart-type 18 m'], ['Délai de livraison', 'moyenne 3 semaines, écart-type 0,5 semaine'],
                                 ['Taux de service visé', '98 % ($z$ = 2,054)'], ['Offre du fournisseur', '20,40 € le mètre à partir de 1 200 m par commande']], [5.6, 4]),
        'Consommation mensuelle de l’an dernier, en mètres :',
        T(MOIS, [[str(v) for v in K['mois']]], [1] * 12, align=['center'] * 12, size=17)],
   qs=[('**Partie A, diagnostic.** Calculer la consommation annuelle et la moyenne mensuelle. Que remarquez-vous ?',
        [f'Total : **{fr(K["C"])} m**, soit {fr(K["m_mois"], 1)} m par mois et 80 m par semaine sur 50 semaines.', ('f', 'c07_cas_mois', 'Étude de cas : consommation mensuelle du tube TA-63', 12),
         f'Août tombe à 150 m : c’est la fermeture annuelle. Ce mois gonfle artificiellement la dispersion (écart-type mensuel de {fr(K["s_mois"], 1)} m). On ne calcule pas un stock de sécurité sur des données qui contiennent une fermeture. L’énoncé donne d’ailleurs l’écart-type hebdomadaire hors fermeture.'], '2.5'),
       ('Pour la pratique actuelle, calculer le stock moyen, sa valeur, la rotation, la couverture en semaines, puis CL, CS et CGA.',
        [f'Stock moyen : 1 000 / 2 + 400 = **{fr(K["act"]["smoy"])} m**, soit {fr(K["act"]["val"])} €. Rotation : 4 000 / 900 = **{fr(K["act"]["rot"], 1)}**. Couverture : 900 / 80 = **{fr(K["act"]["couv"], 2)} semaines**.',
         f'CL = 4 × 90 = {fr(K["act"]["CL"])} €. CS = 900 × 21 × 0,25 = {fr(K["act"]["CS"])} €. CA = 4 000 × 21 = {fr(K["act"]["CA"])} €. **CGA = {fr(K["act"]["tot"])} €**.'], '4.1'),
       ('**Partie B, combien commander.** Calculer la quantité économique. L’arrondir à un nombre entier de barres. En déduire le nombre de commandes et la période.',
        [f'$Q_e$ = √(2 × 4 000 × 90 / (21 × 0,25)) = √137 143 = **{fr(K["Qe"], 1)} m**. En barres : 370,3 / 6 = 61,7, soit **62 barres = 372 m**.', f'$N$ = 4 000 / 372 = **{fr(K["N"], 2)} commandes par an**, une toutes les {fr(K["per"], 2)} semaines.']),
       ('**Partie C, quand commander.** Calculer l’écart-type de la demande pendant le délai, puis le stock de sécurité à 98 % (arrondi à la barre supérieure) et le point de commande.',
        [f'σ = √(3 × 18² + 80² × 0,5²) = √(972 + 1 600) = √2 572 = **{fr(K["sig"], 1)} m**.', f'SS = 2,054 × 50,7 = {fr(K["SS"], 1)} m, soit 17,4 barres : on retient **18 barres = 108 m**.', f'PC = 80 × 3 + 108 = **{K["PC"]} m**, soit 58 barres.'], '6.4'),
       ('Pour cette nouvelle politique, refaire les calculs de la question 2 et chiffrer le gain annuel.',
        [T(['Politique', 'CL', 'CS', 'CS + CL', 'CA', 'CGA', 'Stock moyen (m)', 'Valeur (€)', 'Rotation', 'Couv. (sem.)'], [polrow('Actuelle', 'act'), polrow('Proposée', 'prop')],
           [1.3, 0.95, 1.05, 1.05, 0.95, 1.15, 1.1, 0.95, 1.2, 1], align=['left'] + ['right'] * 9, size=17, hl=(1,)),
         f'Gain : {fr(K["act"]["tot"])} − {fr(K["prop"]["tot"], 2)} = **{fr(K["gain_prop"])} € par an**. La valeur immobilisée passe de {fr(K["act"]["val"])} à {fr(K["prop"]["val"])} €. La rotation triple.'], '4.1'),
       ('**Partie D, la remise.** Calculer le CGA avec des commandes de 1 200 m à 20,40 €, en gardant 108 m de sécurité. Faut-il accepter ?',
        [T(['Politique', 'CL', 'CS', 'CS + CL', 'CA', 'CGA', 'Stock moyen (m)', 'Valeur (€)', 'Rotation', 'Couv. (sem.)'], [polrow('Proposée', 'prop'), polrow('Avec remise', 'rem')],
           [1.3, 0.95, 1.05, 1.05, 0.95, 1.15, 1.1, 0.95, 1.2, 1], align=['left'] + ['right'] * 9, size=17, hl=(1,)),
         ('f', 'c05_cas', 'Étude de cas : comparaison des trois politiques', 15.5),
         f'Sur le papier, la remise gagne encore {fr(K["prop"]["tot"] - K["rem"]["tot"])} € par an : la baisse de CA (2 400 €) dépasse la hausse de CS + CL ({fr(K["rem"]["gest"] - K["prop"]["gest"])} €).',
         f'Mais elle demande de loger 200 barres par livraison et d’immobiliser {fr(K["rem"]["val"])} € au lieu de {fr(K["prop"]["val"])} €. Réponse argumentée : oui si le magasin a la place et si le taux de 25 % reflète bien le coût réel de l’argent pour l’entreprise ; non si la trésorerie est tendue ou si la surface manque.'], '4.4'),
       ('**Partie E, synthèse.** Rédiger une note de dix lignes au responsable logistique : constat, proposition, gain, point de vigilance.',
        ['Éléments attendus dans la note :',
         '- Constat : 900 m de stock moyen, 11 semaines de couverture, 5 085 € de frais de gestion par an.',
         '- Proposition : commandes de 62 barres (372 m) quand le stock disponible atteint 58 barres (348 m), dont 18 barres de sécurité.',
         f'- Gain : {fr(K["gain_prop"])} € par an et {fr(K["act"]["val"] - K["prop"]["val"])} € de trésorerie libérée, pour un taux de service de 98 %.',
         '- Option : la remise à 1 200 m ajoute 1 000 € de gain mais mobilise de la place et de la trésorerie. Décision à prendre avec la direction financière.',
         '- Vigilance : 62 % de la variance vient du délai fournisseur (1 600 / 2 572). Un délai plus régulier ferait baisser le stock de sécurité. Revoir les paramètres chaque année, hors mois de fermeture.',
         'On évalue la clarté de la note autant que les chiffres : phrases courtes, un chiffre par idée, une recommandation nette.'], '6.4')],
   comp='Le cas enchaîne toute la démarche : mesurer la situation, calculer combien et quand, tester l’offre du fournisseur, puis traduire le résultat pour un décideur.',
   err=['Calculer l’écart-type sur les données mensuelles sans retirer août.', 'Arrondir la quantité à la barre mais oublier d’arrondir le stock de sécurité.', 'Comparer les politiques sur CS + CL quand le prix change : il faut le CGA complet.', 'Présenter la remise comme une évidence sans parler de la place ni de la trésorerie.'])
