# -*- coding: utf-8 -*-
"""Gabarit BTS ATI (convention du cours TRS du 19/09/2026) pour python-docx."""
import copy, re, os, subprocess, hashlib, json, zipfile, tempfile
import docx
from docx.shared import Cm, Emu
from docx.oxml.ns import qn
from docx.oxml import OxmlElement
from lxml import etree

HERE = os.path.dirname(os.path.abspath(__file__))
TEMPLATE = os.path.join(HERE, '..', 'tpl', 'trs2.docx')
CACHE = os.path.join(HERE, 'omml_cache.json')
W = 'http://schemas.openxmlformats.org/wordprocessingml/2006/main'
M = 'http://schemas.openxmlformats.org/officeDocument/2006/math'
DARK, ORANGE, PEACH, GREY, BORDER = '1B2A38', 'E8871E', 'FCE6CC', 'F4F6F7', 'D8DEE2'
BLUE, LBLUE, RED = '085B79', '169BD6', 'E9302B'
FULLW = 9638

# ---------- nombres et typographie ----------
def fr(x, nd=0, sign=False):
    """Nombre au format français : espace insécable fine en milliers, virgule décimale."""
    s = f"{abs(x):,.{nd}f}".replace(',', '\u202f').replace('.', ',')
    if x < 0: s = '−' + s
    elif sign: s = '+' + s
    return s

def typo(t):
    t = t.replace("'", '’')
    t = re.sub(r' ([:;?!%»€])', '\u00a0\\1', t)
    t = t.replace('« ', '«\u00a0')
    t = re.sub(r'(\d) (\d{3})(?!\d)', '\\1\u202f\\2', t)
    return t

# ---------- équations : LaTeX -> OMML via pandoc ----------
_cache = json.load(open(CACHE, encoding='utf8')) if os.path.exists(CACHE) else {}
def omml(latex):
    key = hashlib.md5(latex.encode()).hexdigest()
    if key not in _cache:
        with tempfile.TemporaryDirectory() as td:
            src, out = os.path.join(td, 'a.md'), os.path.join(td, 'a.docx')
            lx = re.sub(r'(?<!\\left)(?<!\\right)\(', r'\\left(', latex); lx = re.sub(r'(?<!\\left)(?<!\\right)\)', r'\\right)', lx)
            open(src, 'w', encoding='utf8').write('$' + lx + '$\n')
            subprocess.run(['pandoc', src, '-o', out], check=True)
            xml = zipfile.ZipFile(out).read('word/document.xml')
        root = etree.fromstring(xml)
        el = root.find('.//{%s}oMath' % M)
        if el is None:
            raise ValueError('Formule non convertie : ' + latex)
        # remise en ordre du XML de pandoc pour respecter le schéma OOXML
        for rp in el.iter('{%s}rPr' % M):
            kids = {k.tag.split('}')[1]: k for k in rp}
            if 'nor' in kids:
                for t in ('sty', 'scr'):
                    if t in kids: rp.remove(kids[t])
            else:
                for t in ('lit', 'scr', 'sty', 'brk', 'aln'):
                    if t in kids: rp.remove(kids[t]); rp.append(kids[t])
        for dp in el.iter('{%s}dPr' % M):
            kids = {k.tag.split('}')[1]: k for k in dp}
            for t in ('begChr', 'sepChr', 'endChr', 'grow', 'shp', 'ctrlPr'):
                if t in kids: dp.remove(kids[t]); dp.append(kids[t])
        _cache[key] = etree.tostring(el, encoding='unicode')
        json.dump(_cache, open(CACHE, 'w', encoding='utf8'))
    return etree.fromstring(_cache[key])

# ---------- briques XML ----------
def _rpr(run, bold=False, italic=False, color=None, size=None, sub=False, sup=False):
    rpr = run.get_or_add_rPr()
    if bold:
        rpr.append(OxmlElement('w:b')); rpr.append(OxmlElement('w:bCs'))
    if italic:
        rpr.append(OxmlElement('w:i')); rpr.append(OxmlElement('w:iCs'))
    if color:
        c = OxmlElement('w:color'); c.set(qn('w:val'), color); rpr.append(c)
    if size:
        for tag in ('w:sz', 'w:szCs'):
            s = OxmlElement(tag); s.set(qn('w:val'), str(size)); rpr.append(s)
    if sub or sup:
        v = OxmlElement('w:vertAlign'); v.set(qn('w:val'), 'subscript' if sub else 'superscript'); rpr.append(v)

def _run(p, text, **kw):
    r = OxmlElement('w:r')
    p.append(r)
    _rpr_needed = any(kw.values())
    if _rpr_needed:
        rpr = OxmlElement('w:rPr'); r.append(rpr)
        class _R:  # petit adaptateur
            def get_or_add_rPr(self_): return rpr
        _rpr(_R(), **kw)
    t = OxmlElement('w:t'); t.set('{http://www.w3.org/XML/1998/namespace}space', 'preserve')
    t.text = text; r.append(t)
    return r

TOKEN = re.compile(r'(\$[^$]+\$|\*\*.+?\*\*|\*[^*]+?\*|\[\[.+?\]\])')
def inline(p, text, color=None, size=None, bold=False):
    """Texte avec **gras**, *italique*, $latex$ et [[couleur orange]]."""
    for part in TOKEN.split(text.replace('\\$', '\uE000')):
        if not part: continue
        part = part.replace('\uE000', '$') if not (part.startswith('$') and part.endswith('$') and len(part) > 1 and '\uE000' not in part) else part
        if part.startswith('$') and part.endswith('$'):
            p.append(omml(part[1:-1]))
        elif part.startswith('**'):
            inner = part[2:-2]
            if '$' in inner and not inner.startswith('='): inline(p, inner, color=color, size=size, bold=True)
            else: _run(p, typo(inner) if not inner.startswith('=') else inner, bold=True, color=color, size=size)
        elif part.startswith('[['):
            _run(p, typo(part[2:-2]), bold=True, color=ORANGE, size=size)
        elif part.startswith('*'):
            _run(p, typo(part[1:-1]), italic=True, color=color, size=size, bold=bold)
        else:
            _run(p, typo(part), color=color, size=size, bold=bold)

def _p(after=120, line=276, before=None, jc=None, keep=False, ind=None, hanging=None, style=None):
    p = OxmlElement('w:p'); ppr = OxmlElement('w:pPr'); p.append(ppr)
    if style:
        s = OxmlElement('w:pStyle'); s.set(qn('w:val'), style); ppr.append(s)
    if keep: ppr.append(OxmlElement('w:keepNext'))
    sp = OxmlElement('w:spacing'); sp.set(qn('w:after'), str(after))
    if before is not None: sp.set(qn('w:before'), str(before))
    if line: sp.set(qn('w:line'), str(line)); sp.set(qn('w:lineRule'), 'auto')
    ppr.append(sp)
    if ind is not None or hanging is not None:
        i = OxmlElement('w:ind')
        if ind is not None: i.set(qn('w:left'), str(ind))
        if hanging is not None: i.set(qn('w:hanging'), str(hanging))
        ppr.append(i)
    if jc:
        j = OxmlElement('w:jc'); j.set(qn('w:val'), jc); ppr.append(j)
    return p

def _tc(width, fill=None, border=BORDER, mar=(60, 100, 60, 100), valign='center'):
    tc = OxmlElement('w:tc'); pr = OxmlElement('w:tcPr'); tc.append(pr)
    w = OxmlElement('w:tcW'); w.set(qn('w:type'), 'dxa'); w.set(qn('w:w'), str(width)); pr.append(w)
    b = OxmlElement('w:tcBorders')
    for side in ('top', 'left', 'bottom', 'right'):
        e = OxmlElement('w:' + side)
        if border:
            e.set(qn('w:val'), 'single'); e.set(qn('w:color'), border); e.set(qn('w:sz'), '4')
        else:
            e.set(qn('w:val'), 'none'); e.set(qn('w:color'), 'FFFFFF'); e.set(qn('w:sz'), '0')
        b.append(e)
    pr.append(b)
    if fill:
        s = OxmlElement('w:shd'); s.set(qn('w:fill'), fill); s.set(qn('w:color'), 'auto'); s.set(qn('w:val'), 'clear'); pr.append(s)
    m = OxmlElement('w:tcMar')
    for side, v in zip(('top', 'left', 'bottom', 'right'), mar):
        e = OxmlElement('w:' + side); e.set(qn('w:type'), 'dxa'); e.set(qn('w:w'), str(v)); m.append(e)
    pr.append(m)
    if valign:
        v = OxmlElement('w:vAlign'); v.set(qn('w:val'), valign); pr.append(v)
    return tc

def _tbl(widths):
    t = OxmlElement('w:tbl'); pr = OxmlElement('w:tblPr'); t.append(pr)
    w = OxmlElement('w:tblW'); w.set(qn('w:type'), 'dxa'); w.set(qn('w:w'), str(sum(widths))); pr.append(w)
    lay = OxmlElement('w:tblLayout'); lay.set(qn('w:type'), 'fixed'); pr.append(lay)
    g = OxmlElement('w:tblGrid')
    for x in widths:
        c = OxmlElement('w:gridCol'); c.set(qn('w:w'), str(x)); g.append(c)
    t.append(g)
    return t


class Doc:
    def __init__(self, titre_cartouche, entete, pied, maj, principales=(), associees=()):
        self.d = docx.Document(TEMPLATE)
        body = self.d.element.body
        els = list(body.iterchildren())
        self.sect = els[-1]
        for el in els[6:-1]:
            body.remove(el)
        self.body = body
        # cartouche : titre
        cell = els[0].findall('.//{%s}tc' % W)[2]
        ps = cell.findall('{%s}p' % W)
        ts = ps[0].findall('.//{%s}t' % W)
        ts[0].text = titre_cartouche
        for t in ts[1:]: t.text = ''
        for p in ps[1:]: cell.remove(p)
        # grille C1-C8
        rows = els[2].findall('{%s}tr' % W)
        for i, row in enumerate(rows[1:], start=1):
            for j, tc in enumerate(row.findall('{%s}tc' % W)[2:], start=1):
                kind = 'P' if (i, j) in principales else 'A' if (i, j) in associees else None
                self._mark(tc, kind)
        # en-tête et pieds
        sec = self.d.sections[0]
        for part, old, new in ((sec.header, 'Le TRS  |  BTS ATI et Bachelor Maintenance', entete),):
            for t in part._element.iter('{%s}t' % W):
                if t.text and 'TRS' in t.text: t.text = new
        for part in (sec.footer, sec.first_page_footer):
            for t in part._element.iter('{%s}t' % W):
                if t.text and 'Bachelor Maintenance' in t.text: t.text = pied
                elif t.text and t.text.startswith('MAJ du'): t.text = 'MAJ du ' + maj
        self.nfig = 0

    def _mark(self, tc, kind):
        pr = tc.find('{%s}tcPr' % W)
        shd = pr.find('{%s}shd' % W)
        if shd is not None: pr.remove(shd)
        txt = ''.join(tc.itertext()).strip()
        if kind and txt:
            s = OxmlElement('w:shd'); s.set(qn('w:fill'), ORANGE if kind == 'P' else PEACH)
            s.set(qn('w:color'), 'auto'); s.set(qn('w:val'), 'clear')
            pr.insert(list(pr).index(pr.find('{%s}tcBorders' % W)) + 1, s)
        for rpr in tc.iter('{%s}rPr' % W):
            for tag in ('b', 'bCs', 'color'):
                for e in rpr.findall('{%s}%s' % (W, tag)): rpr.remove(e)
            col = OxmlElement('w:color')
            col.set(qn('w:val'), ('FFFFFF' if kind == 'P' else '000000') if kind else '595959')
            if kind:
                rpr.insert(1, OxmlElement('w:b')); rpr.insert(2, OxmlElement('w:bCs'))
            rpr.insert(len(rpr) - 2 if len(rpr) >= 2 else len(rpr), col)

    def _add(self, el):
        self.sect.addprevious(el); return el

    # ----- éléments de texte -----
    def page(self):
        p = OxmlElement('w:p'); r = OxmlElement('w:r'); b = OxmlElement('w:br'); b.set(qn('w:type'), 'page')
        r.append(b); p.append(r); self._add(p)

    def kicker(self, t):
        p = _p(after=120, line=None); _run(p, t, bold=True, color=ORANGE, size=20)
        p.find('.//' + qn('w:rPr')).find(qn('w:color')).addnext(self._spacing(40)); self._add(p)

    def _spacing(self, v):
        s = OxmlElement('w:spacing'); s.set(qn('w:val'), str(v)); return s

    def title(self, t, sub=None):
        p = _p(after=160, line=None); _run(p, typo(t), bold=True, color=DARK, size=52); self._add(p)
        if sub:
            p = _p(after=360, line=None); _run(p, typo(sub), color='3E5A6D', size=28); self._add(p)

    def h1(self, t, newpage=False):
        p = _p(after=120, before=280, line=None, keep=True, style='Heading1')
        if newpage: p.find(qn('w:pPr')).find(qn('w:keepNext')).addnext(OxmlElement('w:pageBreakBefore'))
        inline(p, t); self._add(p)

    def h2(self, t, newpage=False):
        p = _p(after=100, before=200, line=None, keep=True, style='Heading2')
        if newpage: p.find(qn('w:pPr')).find(qn('w:keepNext')).addnext(OxmlElement('w:pageBreakBefore'))
        inline(p, t); self._add(p)

    def p(self, t, after=120, keep=False, jc=None, color=None, size=None):
        p = _p(after=after, keep=keep, jc=jc); inline(p, t, color=color, size=size); self._add(p); return p

    def spacer(self, after=60):
        self._add(_p(after=after, line=None))

    def bullets(self, items, after=60):
        for it in items:
            p = _p(after=after, line=264, ind=460, hanging=280)
            _run(p, '▪\u00a0\u00a0', bold=True, color=ORANGE); inline(p, it); self._add(p)

    def steps(self, items, start=1, prefix='', after=70):
        for k, it in enumerate(items, start=start):
            p = _p(after=after, line=264, ind=460, hanging=460)
            _run(p, f'{prefix}{k}.\u00a0', bold=True, color=ORANGE); inline(p, it); self._add(p)

    def question(self, label, t, after=90):
        p = _p(after=after, line=264, ind=560, hanging=560, before=60)
        _run(p, label + '\u00a0', bold=True, color=ORANGE); inline(p, t, bold=False); self._add(p)

    def eq(self, latex, after=140):
        p = _p(after=after, before=80, line=None, jc='center'); p.append(omml(latex)); self._add(p)

    def eqs(self, latexs, after=140, sep=8):
        p = _p(after=after, before=80, line=None, jc='center')
        for i, l in enumerate(latexs):
            if i: _run(p, '\u00a0' * sep)
            p.append(omml(l))
        self._add(p)

    def fig(self, path, caption, width_cm=15.5):
        para = self.d.add_paragraph()   # ajouté en fin de corps, puis déplacé
        run = para.add_run(); run.add_picture(path, width=Cm(width_cm))
        el = para._p; self.body.remove(el)
        ppr = el.get_or_add_pPr(); ppr.append(OxmlElement('w:keepNext'))
        sp = OxmlElement('w:spacing'); sp.set(qn('w:after'), '40'); sp.set(qn('w:before'), '120'); ppr.append(sp)
        j = OxmlElement('w:jc'); j.set(qn('w:val'), 'center'); ppr.append(j)
        self._add(el)
        self.nfig += 1
        c = _p(after=200, line=None, jc='center')
        _run(c, typo(f'Figure {self.nfig}. {caption}'), italic=True, color='3E5A6D', size=18); self._add(c)

    # ----- tableaux -----
    def table(self, header, rows, widths=None, align=None, size=20, hl=(), bold_first=False, total_last=False, keep=True, raw=()):
        n = len(header) if header else len(rows[0])
        if widths is None: widths = [FULLW // n] * n
        widths = [int(round(w * FULLW / sum(widths))) for w in widths]
        widths[-1] += FULLW - sum(widths)
        align = align or ['left'] * n
        t = _tbl(widths)
        def row(cells, head=False, fill='FFFFFF', bold=False):
            tr = OxmlElement('w:tr'); trpr = OxmlElement('w:trPr')
            trpr.append(OxmlElement('w:cantSplit'))
            if head: trpr.append(OxmlElement('w:tblHeader'))
            tr.append(trpr)
            for k, (c, w) in enumerate(zip(cells, widths)):
                tc = _tc(w, fill=DARK if head else fill)
                for line in str(c).split('\n'):
                    p = _p(after=0, line=None, jc='left' if head else align[k])
                    if head: _run(p, typo(re.sub(r'\$([^$]+)\$', lambda m: m.group(1).replace('_e', 'e').replace('\\le', '≤').replace('\\,', ' '), line)), bold=True, color='FFFFFF', size=size)
                    elif k in raw: _run(p, line, size=size)
                    else: inline(p, line, size=size, bold=bold or (bold_first and k == 0))
                    tc.append(p)
                tr.append(tc)
            t.append(tr)
        if header: row(header, head=True)
        for i, r in enumerate(rows):
            last = total_last and i == len(rows) - 1
            row(r, fill=PEACH if (i in hl) else (GREY if last else 'FFFFFF'), bold=last)
        self._add(t); self.spacer(120)

    def box(self, titre, contenu, kind='grey'):
        fill, col = {'grey': (GREY, DARK), 'orange': (PEACH, ORANGE), 'blue': ('E3F1FA', BLUE),
                     'red': ('FCE4E2', RED), 'green': ('E6F2EA', '2E7D4F')}[kind]
        t = _tbl([FULLW]); tr = OxmlElement('w:tr'); trpr = OxmlElement('w:trPr'); trpr.append(OxmlElement('w:cantSplit')); tr.append(trpr)
        tc = _tc(FULLW, fill=fill, border=None, mar=(140, 220, 80, 220), valign=None)
        p = _p(after=80, line=None); _run(p, typo(titre), bold=True, color=col, size=22); tc.append(p)
        if isinstance(contenu, str): contenu = [contenu]
        for c in contenu:
            if c.startswith('$$'):
                p = _p(after=120, before=60, line=None, jc='center'); p.append(omml(c[2:]))
            elif c.startswith('- '):
                p = _p(after=60, line=264, ind=380, hanging=260); _run(p, '▪\u00a0\u00a0', bold=True, color=col); inline(p, c[2:])
            else:
                p = _p(after=120, line=276); inline(p, c)
            tc.append(p)
        tr.append(tc); t.append(tr); self._add(t); self.spacer(120)

    def save(self, path):
        self.d.save(path)


def to_pdf(path):
    out = os.path.dirname(path)
    subprocess.run(['soffice', '--headless', '--convert-to', 'pdf', '--outdir', out, path],
                   check=True, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    return path[:-5] + '.pdf'

def pages_of(pdf, needles):
    """Page (numérotation PDF) où apparaît chaque libellé."""
    n = int(re.search(r'Pages:\s+(\d+)', subprocess.run(['pdfinfo', pdf], capture_output=True, text=True).stdout).group(1))
    res = {}
    for pg in range(1, n + 1):
        txt = subprocess.run(['pdftotext', '-f', str(pg), '-l', str(pg), pdf, '-'], capture_output=True, text=True).stdout
        txt = re.sub(r'\s+', ' ', txt)
        for k in needles:
            if k not in res and re.sub(r'\s+', ' ', k) in txt: res[k] = pg
    return res, n
