# -*- coding: utf-8 -*-
import os, math
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch, Polygon, Rectangle, FancyArrowPatch, Ellipse
from scipy import stats
import calc
from calc import R, E

BLUE, LBLUE, RED, ORANGE, DARK, GREY, PEACH = '#085B79', '#169BD6', '#E9302B', '#E8871E', '#1B2A38', '#8A979F', '#FCE6CC'
plt.rcParams.update({'font.family': 'Carlito', 'font.size': 11, 'axes.spines.top': False, 'axes.spines.right': False,
                     'axes.edgecolor': '#5A6770', 'axes.labelcolor': DARK, 'xtick.color': '#3A4750', 'ytick.color': '#3A4750',
                     'axes.titleweight': 'bold', 'axes.titlecolor': DARK, 'legend.frameon': False, 'mathtext.fontset': 'dejavusans'})
OUT = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'fig'); os.makedirs(OUT, exist_ok=True)
def save(fig, name):
    fig.savefig(os.path.join(OUT, name + '.png'), dpi=200, bbox_inches='tight', facecolor='white'); plt.close(fig)
def fr(x, nd=0): return f"{x:,.{nd}f}".replace(',', ' ').replace('.', ',')
def box(ax, x, y, w, h, txt, fc, ec=None, tc='white', fs=11, bold=True):
    ax.add_patch(FancyBboxPatch((x, y), w, h, boxstyle='round,pad=0.02,rounding_size=0.08', fc=fc, ec=ec or fc, lw=1.2))
    ax.text(x + w / 2, y + h / 2, txt, ha='center', va='center', color=tc, fontsize=fs, fontweight='bold' if bold else 'normal')
def arrow(ax, p, q, col=DARK, lw=2):
    ax.add_patch(FancyArrowPatch(p, q, arrowstyle='-|>', mutation_scale=16, color=col, lw=lw))

# ---------- F1 : le stock, réservoir entre deux flux
def f01():
    fig, ax = plt.subplots(figsize=(8.6, 2.9)); ax.set_xlim(0, 10); ax.set_ylim(0, 3.4); ax.axis('off')
    ax.add_patch(Rectangle((3.6, 0.4), 2.8, 2.3, fc='white', ec=DARK, lw=2))
    ax.add_patch(Rectangle((3.6, 0.4), 2.8, 1.35, fc=LBLUE, ec='none', alpha=.55))
    ax.add_patch(Rectangle((3.6, 0.4), 2.8, 0.45, fc=ORANGE, ec='none', alpha=.75))
    ax.text(5, 1.3, 'Stock actif', ha='center', va='center', color=DARK, fontweight='bold')
    ax.text(5, 0.62, 'Stock de sécurité', ha='center', va='center', color='white', fontweight='bold')
    box(ax, 0.2, 1.9, 2.2, 0.8, 'Flux d’entrée\nlivraisons, fabrication', BLUE, fs=10)
    box(ax, 7.6, 0.6, 2.2, 0.8, 'Flux de sortie\nconsommation, ventes', BLUE, fs=10)
    arrow(ax, (2.45, 2.3), (3.55, 2.3)); arrow(ax, (6.45, 1.0), (7.55, 1.0))
    ax.text(3.0, 2.48, 'par lots', ha='center', fontsize=9, color=GREY); ax.text(7.0, 1.18, 'en continu', ha='center', fontsize=9, color=GREY)
    ax.text(5, 3.0, 'Le niveau monte quand l’entrée dépasse la sortie, il baisse dans le cas contraire', ha='center', color=DARK, fontsize=10.5)
    save(fig, 'f01_reservoir')

# ---------- F2 : la rivière et les rochers
def f02():
    fig, axs = plt.subplots(1, 2, figsize=(9.6, 3.3))
    rocks = [(1.2, 1.5, 'Pannes'), (3.0, 2.1, 'Réglages\nlongs'), (4.9, 1.3, 'Rebuts'), (6.7, 1.9, 'Retards\nfournisseurs'), (8.6, 1.6, 'Prévisions\nfausses')]
    for ax, lvl, ttl in zip(axs, (2.9, 1.55), ('Stock élevé : on ne voit rien', 'Stock réduit : les problèmes apparaissent')):
        ax.set_xlim(0, 10); ax.set_ylim(0, 3.6); ax.axis('off')
        ax.add_patch(Rectangle((0, 0), 10, lvl, fc=LBLUE, ec='none', alpha=.45))
        for x, h, t in rocks:
            ax.add_patch(Polygon([(x - 0.85, 0), (x - 0.3, h * .8), (x, h), (x + 0.35, h * .75), (x + 0.85, 0)], fc='#6B5B4D', ec='#4A3F36'))
            ax.text(x, max(h * 0.35, 0.3), t, ha='center', va='center', color='white', fontsize=7.6, fontweight='bold')
        ax.plot([0, 10], [lvl, lvl], color=BLUE, lw=2)
        bx = 5.6 if lvl > 2 else 2.0
        ax.add_patch(Polygon([(bx - 0.7, lvl + 0.08), (bx + 0.7, lvl + 0.08), (bx + 0.5, lvl - 0.14), (bx - 0.5, lvl - 0.14)], fc=RED, ec=RED))
        ax.plot([bx, bx], [lvl + 0.08, lvl + 0.6], color=DARK, lw=1.5); ax.add_patch(Polygon([(bx, lvl + 0.6), (bx, lvl + 0.25), (bx + 0.4, lvl + 0.25)], fc='white', ec=DARK))
        ax.set_title(ttl, fontsize=11)
    axs[0].text(0.15, 3.05, 'niveau de stock', color=BLUE, fontsize=9)
    save(fig, 'f02_riviere')

# ---------- F3 : décomposition du taux de possession
def f03():
    fig, ax = plt.subplots(figsize=(8.8, 2.3)); left = 0
    cols = [BLUE, LBLUE, GREY, ORANGE, RED]
    for (lab, v), c in zip(R['T_decomp'], cols):
        ax.barh(0, v, left=left, color=c, edgecolor='white', height=.55)
        ax.text(left + v / 2, 0, f'{v} %', ha='center', va='center', color='white', fontweight='bold')
        lab2 = {'Assurance': 'Assurance', 'Détérioration, casse, pertes': 'Détérioration,\ncasse, pertes'}.get(lab, lab.replace(' (', '\n('))
        up = lab == 'Assurance'
        ax.text(left + v / 2, 0.36 if up else -0.42, lab2, ha='center', va='bottom' if up else 'top', fontsize=8.6, color=DARK)
        left += v
    ax.set_xlim(0, 25); ax.set_ylim(-1.1, 1.15); ax.axis('off')
    ax.text(12.5, 0.85, 'Taux de possession retenu pour VÉRILOIRE : T = 25 % par an', ha='center', fontweight='bold', color=DARK)
    save(fig, 'f03_taux')

# ---------- Pareto ABC générique
def pareto(xs, ys, xc, trip, labels=None, name='abc', title=None, n_lab=10):
    fig, ax = plt.subplots(figsize=(5.6, 5.6))
    a, b, c = trip
    for x0, x1, col, t in ((0, a, ORANGE, 'A'), (a, a + b, PEACH, 'B'), (a + b, 100, '#EEF1F3', 'C')):
        ax.axvspan(x0, x1, color=col, alpha=.55 if t != 'A' else .35, lw=0); ax.text((x0 + x1) / 2, 6, t, ha='center', fontsize=18, fontweight='bold', color=DARK)
    ax.plot([0, 100], [100, 0], color=GREY, lw=1.2, ls='--'); ax.plot(xs, ys, color=BLUE, lw=2.4, marker='o', ms=4 if len(xs) > 15 else 6)
    ax.plot([xc], [100 - xc], 'o', color=RED, ms=9, zorder=5)
    ax.annotate(f'C : RD = {fr((100 - xc) / 100, 2)}', (xc, 100 - xc), xytext=(xc + 12, 100 - xc - 14), color=RED, fontweight='bold', arrowprops=dict(arrowstyle='-', color=RED))
    ax.text(1.5, 96, 'A', color=GREY, fontweight='bold', va='top'); ax.text(98, 3, 'B', color=GREY, fontweight='bold', ha='right')
    ax.set_xlim(0, 100); ax.set_ylim(0, 100); ax.set_aspect('equal')
    ax.set_xlabel('% cumulé du nombre d’articles'); ax.set_ylabel('% cumulé de la valeur consommée')
    if labels:
        ax.set_xticks(xs[1:]); ax.set_xticklabels(labels, rotation=60, fontsize=8); ax.set_xlabel('Articles, par valeur décroissante')
    ax.grid(alpha=.25)
    if title: ax.set_title(title, fontsize=11)
    save(fig, name)

def f04():
    vals = sorted([(q * p, r) for r, _, q, p in calc.ABC10], reverse=True)
    xs, ys, xc, yc = calc.rd_abc([v for v, _ in vals])
    pareto(xs, ys, xc, R['abc10_zone'][1], labels=[r for _, r in vals], name='f04_abc')

# ---------- F5 : courbes de coûts de Wilson
def f05():
    Q = np.linspace(150, 3000, 400); C, L, P, T = R['C'], R['L'], R['P'], R['T']
    fig, ax = plt.subplots(figsize=(8.2, 4.2))
    ax.plot(Q, C / Q * L, color=BLUE, lw=2, label='Coût de lancement CL = (C/Q)·L')
    ax.plot(Q, Q / 2 * P * T, color=ORANGE, lw=2, label='Coût de stockage CS = (Q/2)·P·T')
    ax.plot(Q, C / Q * L + Q / 2 * P * T, color=DARK, lw=2.8, label='CS + CL')
    ax.plot([1000, 1000], [0, 1000], color=RED, ls='--', lw=1.3); ax.plot([1000], [1000], 'o', color=RED, ms=8)
    ax.annotate('Minimum : 1 000 €\npour Qe = 1 000 pièces', (1000, 1000), xytext=(1250, 1750), color=RED, fontweight='bold', arrowprops=dict(arrowstyle='->', color=RED))
    ax.plot([1000], [500], 'o', color=GREY, ms=6); ax.annotate('CS = CL = 500 €', (1000, 500), xytext=(1420, 500), color=GREY, fontsize=10, va='center', arrowprops=dict(arrowstyle='-', color=GREY))
    ax.set_ylim(0, 3200); ax.set_xlim(0, 3000); ax.set_xlabel('Quantité commandée Q (pièces)'); ax.set_ylabel('Coût annuel (€)')
    ax.legend(loc='upper center', fontsize=9.5); ax.grid(alpha=.25)
    save(fig, 'f05_wilson')

def f06():
    x = np.linspace(0.3, 2.6, 300); y = 0.5 * (x + 1 / x) * 100 - 100
    fig, ax = plt.subplots(figsize=(8.2, 3.4)); ax.plot(x, y, color=DARK, lw=2.6)
    lo, hi = 1.05 - math.sqrt(1.05 ** 2 - 1), 1.05 + math.sqrt(1.05 ** 2 - 1)
    ax.axvspan(lo, hi, color=ORANGE, alpha=.22, lw=0); ax.axhline(5, color=ORANGE, ls='--', lw=1)
    ax.text(1.0, 12, f'Zone à moins de 5 % de surcoût :\nde {fr(lo * 100)} % à {fr(hi * 100)} % de Qe', ha='center', color=ORANGE, fontweight='bold', fontsize=10)
    for xv in (0.5, 2.0):
        ax.plot([xv], [25], 'o', color=RED); ax.annotate('+25 %', (xv, 25), xytext=(xv + 0.06, 30 if xv < 1 else 17), color=RED, fontweight='bold')
    ax.set_xlabel('Quantité commandée rapportée à la quantité économique, Q / Qe'); ax.set_ylabel('Surcoût sur CS + CL (%)')
    ax.set_ylim(0, 60); ax.set_xlim(0.3, 2.6); ax.grid(alpha=.25)
    save(fig, 'f06_zone')

def f07():
    C, L, T = R['C'], R['L'], R['T']; fig, ax = plt.subplots(figsize=(8.2, 4.0))
    Q = np.linspace(300, 8000, 600); bounds = [(300, 3000, 4.00, BLUE), (3000, 6000, 3.90, ORANGE), (6000, 8000, 3.85, RED)]
    for a, b, p, col in bounds:
        y = C * p + C / Q * L + Q / 2 * p * T
        ax.plot(Q, y, color=col, lw=1, ls=':'); m = (Q >= a) & (Q <= b); ax.plot(Q[m], y[m], color=col, lw=2.8, label=f'Prix {fr(p, 2)} €')
    for r, col in zip(R['remise'], (BLUE, ORANGE, RED)):
        ax.plot([r['q']], [r['cga']], 'o', color=col, ms=8)
        ax.annotate(f"{fr(r['cga'])} €", (r['q'], r['cga']), xytext=(r['q'] + 180, r['cga'] + (260 if r['q'] < 2000 else -330)), color=col, fontweight='bold')
    ax.set_xlabel('Quantité commandée Q (pièces)'); ax.set_ylabel('Coût de gestion annuel CGA (€)'); ax.set_ylim(49800, 53500)
    ax.legend(fontsize=9.5, loc='upper center', ncol=3); ax.grid(alpha=.25)
    save(fig, 'f07_remise')

# ---------- simulation en dents de scie
def sawtooth(days, s0, daily, pc, q, lead, delays=None, per=None, nr=None):
    """Retourne t, stock (début de jour) ; point de commande ou recomplètement périodique."""
    stock = s0; ts, ss = [0], [s0]; pending = []; orders = []; k = 0
    for d in range(1, days + 1):
        stock -= daily(d) if callable(daily) else daily
        for arr in [p for p in pending if p[0] == d]:
            ts.append(d); ss.append(stock); stock += arr[1]; pending.remove(arr)
        ts.append(d); ss.append(stock)
        pos = stock + sum(p[1] for p in pending)
        if per is None and pos <= pc + 1e-9:
            dl = lead + (delays or {}).get(k, 0); pending.append((d + dl, q)); orders.append((d, q, d + dl)); k += 1
        if per is not None and d % per == 0:
            qq = nr - pos; pending.append((d + lead, qq)); orders.append((d, qq, d + lead))
    return np.array(ts), np.array(ss), orders

def f08():
    rng = np.random.default_rng(7)
    def daily(d): return 50 if d < 41 else (64 if d < 61 else 50)
    t, s, orders = sawtooth(80, 1295, daily, 295, 1000, 5)
    fig, ax = plt.subplots(figsize=(8.8, 4.0)); ax.plot(t, s, color=BLUE, lw=2.2)
    ax.axhline(295, color=RED, ls='--', lw=1.3); ax.text(80.5, 295, 'PC = 295', color=RED, va='center', fontweight='bold')
    ax.axhspan(0, 45, color=ORANGE, alpha=.3, lw=0); ax.text(80.5, 22, 'SS = 45', color=ORANGE, va='center', fontweight='bold')
    for (d, q, a) in orders:
        ax.plot([d], [295], 'v', color=RED, ms=7)
    d0, a0 = orders[0][0], orders[0][2]
    ax.annotate('', (d0, 1130), (a0, 1130), arrowprops=dict(arrowstyle='<->', color=DARK)); ax.text((d0 + a0) / 2, 1175, 'délai D = 5 j', ha='center', fontsize=9.5, color=DARK)
    ax.plot([d0, d0], [295, 1130], color=DARK, lw=.8, ls=':')
    ax.axvspan(41, 61, color=ORANGE, alpha=.08, lw=0)
    ax.text(51, 1290, 'Consommation plus forte (64 par jour) :\nle stock de sécurité est entamé', ha='center', color=ORANGE, fontweight='bold', fontsize=9.5)
    ax.annotate('', (orders[0][2] + 0.6, 45), (orders[0][2] + 0.6, 1045), arrowprops=dict(arrowstyle='<->', color=GREY)); ax.text(orders[0][2] + 1.6, 560, 'Q = 1 000', color=GREY, fontsize=9.5)
    ax.set_xlim(0, 80); ax.set_ylim(0, 1400); ax.set_xlabel('Jours ouvrés'); ax.set_ylabel('Stock de ET-16 (pièces)'); ax.grid(alpha=.25)
    save(fig, 'f08_pc')

def f09():
    def daily(d): return [50, 46, 53, 50, 50][(d - 1) // 20 % 5]
    t, s, orders = sawtooth(85, 1349, daily, None, None, 5, per=20, nr=1349)
    fig, ax = plt.subplots(figsize=(8.8, 4.0)); ax.plot(t, s, color=BLUE, lw=2.2)
    ax.axhline(1349, color=RED, ls='--', lw=1.3); ax.text(85.5, 1349, 'NR = 1 349', color=RED, va='center', fontweight='bold')
    ax.axhspan(0, 99, color=ORANGE, alpha=.3, lw=0); ax.text(85.5, 50, 'SS = 99', color=ORANGE, va='center', fontweight='bold')
    for (d, q, a) in orders:
        ax.axvline(d, color=GREY, ls=':', lw=1); ax.text(d, 1440, f'Q = {fr(q)}', ha='center', fontsize=9, color=DARK, fontweight='bold')
    ax.set_xlim(0, 85); ax.set_ylim(0, 1550); ax.set_xlabel('Jours ouvrés'); ax.set_ylabel('Stock (pièces)'); ax.grid(alpha=.25)
    save(fig, 'f09_recomp')

def f10():
    m, sg, pc = 250, R['sD'], 295; x = np.linspace(150, 350, 400); y = stats.norm.pdf(x, m, sg)
    fig, ax = plt.subplots(figsize=(8.2, 3.6)); ax.plot(x, y, color=DARK, lw=2.4)
    ax.fill_between(x, y, where=x >= pc, color=RED, alpha=.55); ax.fill_between(x, y, where=x <= pc, color=LBLUE, alpha=.25)
    ax.axvline(m, color=GREY, ls='--', lw=1); ax.axvline(pc, color=RED, lw=1.6)
    ax.text(m, max(y) * 1.06, 'Demande moyenne\npendant le délai : 250', ha='center', fontsize=9.5, color=DARK)
    ax.text(pc + 3, max(y) * 0.72, 'Point de commande\nPC = 295', color=RED, fontweight='bold', fontsize=9.5)
    ax.annotate('Risque de rupture : 5 %', (305, stats.norm.pdf(305, m, sg) * .5), xytext=(312, max(y) * .35), color=RED, fontsize=9.5, arrowprops=dict(arrowstyle='->', color=RED))
    ax.annotate('', (m, max(y) * .25), (pc, max(y) * .25), arrowprops=dict(arrowstyle='<->', color=ORANGE, lw=1.8))
    ax.text((m + pc) / 2, max(y) * .29, 'SS = z·σ·√D = 45', ha='center', color=ORANGE, fontweight='bold', fontsize=9.5)
    ax.text(205, max(y) * .12, 'Service : 95 %', color=BLUE, fontweight='bold')
    ax.set_xlabel('Demande pendant le délai de 5 jours (pièces)'); ax.set_yticks([]); ax.spines['left'].set_visible(False); ax.set_ylim(0, max(y) * 1.3)
    save(fig, 'f10_normale')

def f11():
    ts = np.linspace(0.5, 0.9995, 500); ss = stats.norm.ppf(ts) * R['sD']
    fig, ax = plt.subplots(figsize=(8.2, 3.5)); ax.plot(ts * 100, ss, color=DARK, lw=2.5)
    for t in (0.90, 0.95, 0.99, 0.999):
        v = stats.norm.ppf(t) * R['sD']; ax.plot([t * 100], [v], 'o', color=ORANGE, ms=7)
        ax.annotate(f'{fr(t * 100, 1 if t > 0.99 else 0)} % : {fr(math.ceil(v))} pièces', (t * 100, v), xytext=(t * 100 - 17, v + 4), color=ORANGE, fontsize=9.5, fontweight='bold')
    ax.set_xlabel('Taux de service visé (%)'); ax.set_ylabel('Stock de sécurité (pièces)'); ax.set_xlim(50, 100.5); ax.set_ylim(0, 100); ax.grid(alpha=.25)
    save(fig, 'f11_ss_ts')

def f12():
    k = np.arange(0, 6); pmf = stats.poisson.pmf(k, 1); cdf = stats.poisson.cdf(k, 1)
    fig, ax = plt.subplots(figsize=(8.0, 3.5)); cols = [BLUE if kk <= 3 else RED for kk in k]
    ax.bar(k, pmf * 100, color=cols, width=.6)
    for kk, p, c in zip(k, pmf, cdf):
        ax.text(kk, p * 100 + 1.2, f'{fr(p * 100, 1)} %', ha='center', fontweight='bold', color=DARK, fontsize=9.5)
        ax.text(kk, -6.3, f'cumul {fr(c * 100, 1)} %', ha='center', fontsize=8.6, color=GREY)
    ax.axvline(3.5, color=RED, ls='--', lw=1.3); ax.text(3.58, 30, 'Avec PC = 3 :\nrupture si la demande\ndépasse 3 (1,9 %)', color=RED, fontsize=9.5, fontweight='bold')
    ax.set_xticks(k); ax.set_xlabel('Nombre de pièces demandées pendant le délai de 3 mois (loi de Poisson, λ = 1)', labelpad=18)
    ax.set_ylabel('Probabilité (%)'); ax.set_ylim(0, 45)
    save(fig, 'f12_poisson')

def f13():
    fig, ax = plt.subplots(figsize=(9.6, 6.6)); ax.set_xlim(0, 10); ax.set_ylim(-0.75, 7.35); ax.axis('off')
    ax.add_patch(Ellipse((5, 3.3), 2.5, 1.05, fc=DARK, ec=DARK)); ax.text(5, 3.3, 'GESTION\nDES STOCKS', ha='center', va='center', color='white', fontweight='bold', fontsize=12)
    br = [((1.6, 5.3), BLUE, 'Pourquoi ?', ['Réguler deux flux', 'Mais le stock coûte : T ≈ 15 à 35 % par an', 'Et il cache les problèmes']),
          ((5.0, 5.95), ORANGE, 'Classer : ABC', ['Critère adapté au problème', 'Ratio de discrimination', 'A serré, C simple']),
          ((8.4, 5.3), RED, 'Combien ? Wilson', ['Qe = √(2CL / PT)', 'À l’optimum : CS = CL', 'Optimum plat, remises à tester']),
          ((8.4, 1.25), BLUE, 'Quand ?', ['Point de commande : PC = Cmoy·D + SS', 'Recomplètement : NR = Cmoy·(D + d) + SS', 'Raisonner sur stock + en-cours']),
          ((5.0, 0.75), ORANGE, 'Aléas : stock de sécurité', ['Loi normale : SS = z·σ·√D', 'Délai variable : les variances s’ajoutent', 'Faible rotation : loi de Poisson']),
          ((1.6, 1.25), RED, 'Piloter', ['Taux de service, rotation, couverture', 'Réduire L (SMED) et D', 'Épurer les stocks morts'])]
    for (x, y), col, t, items in br:
        ax.plot([5, x], [3.3, y], color=col, lw=2.5, zorder=0)
        ax.add_patch(FancyBboxPatch((x - 1.45, y - 0.2), 2.9, 0.42, boxstyle='round,pad=0.02,rounding_size=0.1', fc=col, ec=col))
        ax.text(x, y + 0.01, t, ha='center', va='center', color='white', fontweight='bold', fontsize=10.5)
        up = y > 3.3
        for i, it in enumerate(items):
            yy = y + (0.45 + 0.3 * i if up else -0.45 - 0.3 * i)
            ax.text(x, yy, it, ha='center', va='center', fontsize=8.8, color=DARK, bbox=dict(fc='white', ec='none', pad=1.2))
    save(fig, 'f13_carte')

# ---------- figures des exercices et du corrigé
def c_fonsable(blank=False):
    F = E[11]; fig, ax = plt.subplots(figsize=(8.8, 4.6))
    if not blank:
        t, s, orders = sawtooth(100, 880, 13.75, F['PC'], F['Q'], 30, delays={1: 10})
        ax.plot(t, s, color=BLUE, lw=2.2)
        t2, s2, _ = sawtooth(100, 880, 13.75, F['PC'], F['Q'], 30); m = t2 >= 88
        ax.plot(t2[m], s2[m], color=GREY, lw=1.4, ls='--', label='Sans retard')
        ax.axhline(F['PC'], color=RED, ls='--', lw=1.2); ax.text(100.8, F['PC'], 'Alerte 687,5 t', color=RED, va='center', fontsize=9.5, fontweight='bold')
        ax.axhline(F['SS'], color=ORANGE, ls='--', lw=1.2); ax.text(100.8, F['SS'], 'Sécurité 275 t', color=ORANGE, va='center', fontsize=9.5, fontweight='bold')
        for (d, q, a) in orders: ax.plot([d], [F['PC']], 'v', color=RED, ms=8)
        ax.annotate('Livraison n° 2 avec 10 jours de retard :\nle stock descend à 137,5 t', (98, 137.5), xytext=(52, 60), color=DARK, fontsize=9.5, arrowprops=dict(arrowstyle='->', color=DARK))
        ax.text(14, 715, 'J14 : commande 1', color=RED, fontsize=9); ax.text(58, 715, 'J58 : commande 2', color=RED, fontsize=9); ax.legend(loc='upper right', fontsize=9)
    ax.set_xlim(0, 100); ax.set_ylim(0, 1000); ax.set_xticks(range(0, 101, 10)); ax.set_yticks(range(0, 1001, 100))
    ax.minorticks_on(); ax.grid(which='major', alpha=.45); ax.grid(which='minor', alpha=.15)
    ax.set_xlabel('Jours'); ax.set_ylabel('Stock de sable (tonnes)')
    save(fig, 'c01_fonsable_vide' if blank else 'c01_fonsable')

def c02():
    F = E[11]; n = np.linspace(2, 14, 200); fig, ax = plt.subplots(figsize=(8.2, 4.0))
    ax.plot(n, F['Lc'] * n, color=BLUE, lw=2, label='Passation CPA = 1 210 n'); ax.plot(n, F['a'] / n + F['b'], color=ORANGE, lw=2, label='Possession CPO = 43 560 / n + 5 280')
    ax.plot(n, F['CT'](n), color=DARK, lw=2.8, label='Coût total CT')
    for nn, col, lab in ((6, RED, 'Optimum sans contrainte : n = 6'), (7.5, GREY, 'Contrainte des silos : n = 7,5')):
        ax.plot([nn], [F['CT'](nn)], 'o', color=col, ms=8); ax.annotate(f"{lab}\nCT = {fr(F['CT'](nn))} €", (nn, F['CT'](nn)), xytext=(nn + (1.0 if nn > 7 else -2.4), F['CT'](nn) + (6500 if nn > 7 else 7300)), color=col, fontweight='bold', fontsize=9.5, arrowprops=dict(arrowstyle='->', color=col))
    ax.set_xlabel('Nombre de commandes par an, n'); ax.set_ylabel('Coût annuel (€)'); ax.set_ylim(0, 30000); ax.legend(fontsize=9.5, loc='lower right'); ax.grid(alpha=.25)
    save(fig, 'c02_fonsable_couts')

def c03():
    t = R['tp1']; pareto(t['xs'], t['ys'], t['xc'], t['zone'][1], name='c03_tp1_abc')
def c04():
    d = calc.TP4; t = R['tp4']; fig, axs = plt.subplots(1, 2, figsize=(9.6, 3.6))
    axs[0].hist(d, bins=range(15, 66, 5), color=LBLUE, edgecolor='white'); x = np.linspace(10, 70, 200)
    axs[0].plot(x, stats.norm.pdf(x, t['m'], t['s']) * 52 * 5, color=DARK, lw=2); axs[0].set_xlabel('Consommation hebdomadaire (pièces)'); axs[0].set_ylabel('Nombre de semaines')
    axs[0].set_title(f"m = {fr(t['m'], 1)} ; s = {fr(t['s'], 1)}", fontsize=10.5)
    ts = np.array([0.80, 0.90, 0.95, 0.975, 0.99, 0.999]); ss = [math.ceil(t['SS'][k]) for k in ts]
    axs[1].plot(range(6), ss, color=DARK, lw=2, marker='o', mfc=ORANGE, mec=ORANGE); axs[1].set_xticks(range(6)); axs[1].set_xticklabels([f'{fr(k * 100, 1)} %'.replace(',0 %', ' %') for k in ts])
    for i, v in enumerate(ss): axs[1].text(i, v + 2.5, str(v), ha='center', fontweight='bold', color=ORANGE)
    axs[1].set_xlabel('Taux de service'); axs[1].set_ylabel('Stock de sécurité (pièces)'); axs[1].set_ylim(0, 62); axs[1].grid(alpha=.25)
    fig.tight_layout(); save(fig, 'c04_tp4')
def c05():
    K = R['cas']; labs = ['Pratique actuelle\n1 000 m, SS 400 m', 'Proposition\n372 m, SS 108 m', 'Avec remise\n1 200 m, SS 108 m']
    fig, axs = plt.subplots(1, 2, figsize=(9.6, 3.7)); keys = ['act', 'prop', 'rem']
    cl = [K[k]['CL'] for k in keys]; cs = [K[k]['CS'] for k in keys]
    axs[0].bar(labs, cl, color=BLUE, label='Lancement CL'); axs[0].bar(labs, cs, bottom=cl, color=ORANGE, label='Stockage CS')
    for i, k in enumerate(keys): axs[0].text(i, K[k]['gest'] + 90, f"{fr(K[k]['gest'])} €", ha='center', fontweight='bold', color=DARK)
    axs[0].set_ylabel('CS + CL (€ par an)'); axs[0].legend(fontsize=9); axs[0].set_ylim(0, 6200); axs[0].tick_params(axis='x', labelsize=8.5)
    tot = [K[k]['tot'] for k in keys]; axs[1].bar(labs, tot, color=[GREY, BLUE, ORANGE])
    for i, v in enumerate(tot): axs[1].text(i, v + 60, f'{fr(v)} €', ha='center', fontweight='bold', color=DARK)
    axs[1].set_ylim(84000, 89800); axs[1].set_ylabel('Coût de gestion annuel CGA (€)'); axs[1].tick_params(axis='x', labelsize=8.5)
    fig.tight_layout(); save(fig, 'c05_cas')
def c06():
    e = E[3]['conso']; xs, ys, xc, yc = calc.rd_abc([r[1] for r in e['rows']])
    pareto(xs, ys, xc, e['trip'], labels=[r[0] for r in e['rows']], name='c06_e3')
def c07():
    K = R['cas']; fig, ax = plt.subplots(figsize=(8.2, 3.0)); mois = ['J', 'F', 'M', 'A', 'M', 'J', 'J', 'A', 'S', 'O', 'N', 'D']
    ax.bar(range(12), K['mois'], color=[RED if v < 200 else LBLUE for v in K['mois']]); ax.set_xticks(range(12)); ax.set_xticklabels(mois)
    ax.axhline(K['m_mois'], color=DARK, ls='--', lw=1.2); ax.text(11.6, K['m_mois'] + 8, f"moyenne {fr(K['m_mois'], 1)} m", ha='right', color=DARK, fontsize=9.5)
    ax.set_ylabel('Consommation (m)'); save(fig, 'c07_cas_mois')

if __name__ == '__main__':
    for f in (f01, f02, f03, f04, f05, f06, f07, f08, f09, f10, f11, f12, f13, c_fonsable, lambda: c_fonsable(True), c02, c03, c04, c05, c06, c07): f()
    print(sorted(os.listdir(OUT)))
