# -*- coding: utf-8 -*-
"""P2 (cahier d'exercices et de TP) et corrigé formateur, à partir de exos.py."""
import os, sys
from uimm import Doc, fr, to_pdf, pages_of, FULLW
import exos
from exos import EX, TP, CAS, SRC, SRC_NOTE

HERE = os.path.dirname(os.path.abspath(__file__))
F = lambda n: os.path.join(HERE, 'fig', n + '.png')
MAJ = '12/11/2026'
SEANCES = {1: 'Séance 1. Ce que coûte un stock, analyse ABC', 2: 'Séance 2. Combien commander',
           3: 'Séance 3. Quand commander', 4: 'Séance 4. Stock de sécurité et synthèse'}
MARKS = dict(principales={(6, 5), (4, 3)}, associees={(4, 1), (2, 1)})

def blocks(d, bl, figs=True):
    for b in bl:
        if isinstance(b, str):
            if b.startswith('- '): d.bullets([b[2:]])
            else: d.p(b)
        elif b[0] == 'eq': d.eq(b[1])
        elif b[0] == 'eqs': d.eqs(b[1], sep=5)
        elif b[0] == 't': d.table(b[1], b[2], widths=b[3], **b[4])
        elif b[0] == 'b': d.bullets(b[1])
        elif b[0] == 'f' and figs: d.fig(F(b[1]), b[2], b[3])

def meta(d, txt):
    d.p(txt, after=100, color='5A6770', size=18)

def head(d, kind, x):
    lab = f'Exercice {x["n"]}. ' if kind == 'ex' else f'TP {x["n"]} (Excel). '
    return lab + x['titre']

# ------------------------------------------------------------------ cahier
def build_cahier(path):
    d = Doc('Gestion des stocks : exercices et TP', 'Gestion des stocks  |  P2 Exercices et TP  |  BTS ATI et Bachelor Maintenance',
            'BTS ATI - OI  |  Bachelor Maintenance  |  Stocks P2', MAJ, **MARKS)
    d.kicker('ORGANISATION INDUSTRIELLE')
    d.title('Gestion des stocks', 'Cahier d’exercices et de travaux pratiques sous Excel')
    d.table(['Pièce', 'Contenu'], [['P1', 'Cours'], ['**P2**', '**Ce cahier : 20 exercices, 5 TP Excel, une étude de cas**'], ['P3', 'Classeur Excel de données (une feuille par TP)']], widths=[1.5, 8.1])
    d.box('Mode d’emploi', [
        'Les exercices se font sur feuille, avec la calculatrice. Chaque titre renvoie au paragraphe du cours P1 dont il dépend.',
        'Pour les TP, vous construisez vous-même vos feuilles de calcul. Le classeur P3 ne contient que les données : aucune formule n’y est écrite. Les formules à saisir sont en gras dans les étapes.',
        'Les exercices marqués **Bachelor** s’appuient sur les encadrés bleus du cours.',
        'Sauf indication contraire, l’année compte 250 jours ouvrés ou 50 semaines.'])
    rows = []
    for s in (1, 2, 3, 4):
        exs = [x for x in EX if x['seance'] == s]; tps = [t for t in TP if t['seance'] == s]
        rows.append([f'{s}', f'Exercices {exs[0]["n"]} à {exs[-1]["n"]}', ' ; '.join(f'TP {t["n"]} : {t["titre"]}' for t in tps) + (' ; étude de cas' if s == 4 else '')])
    d.table(['Séance', 'Exercices', 'Travaux pratiques'], rows, widths=[1, 2.4, 6.2])
    for s in (1, 2, 3, 4):
        d.h1(SEANCES[s], newpage=True)
        for x in [x for x in EX if x['seance'] == s]:
            d.h2(head(d, 'ex', x))
            meta(d, f'Durée indicative : {x["duree"]}  |  Cours : P1, § {x["src"]}' + ('  |  Bachelor' if x.get('bach') else ''))
            blocks(d, x['ctx'])
            for i, q in enumerate(x['qs'], 1): d.question(f'{i}.', q[0])
            if x['n'] == 11: d.fig(F('c01_fonsable_vide'), 'Grille à compléter pour la question 5', 15)
        for t in [t for t in TP if t['seance'] == s]:
            d.h2(head(d, 'tp', t))
            meta(d, f'Durée indicative : {t["duree"]}  |  Cours : P1, § {t["src"]}  |  Données : P3, feuille « {t["feuille"]} »')
            d.p('**Objectif.** ' + t['but']); d.p('**Données.** ' + t['donnees'])
            d.p('**Étapes.**', after=60); d.steps(t['etapes'])
            if t.get('aide'):
                d.p('**Aide.**', after=60); blocks(d, t['aide'])
            d.p('**Questions.**', after=60)
            for i, q in enumerate(t['qs'], 1): d.question(f'{i}.', q[0])
    d.h1(CAS['titre'], newpage=True)
    meta(d, f'Durée indicative : {CAS["duree"]}  |  Cours : P1, § 2 à 6  |  Données : P3, feuille « Etude_de_cas »')
    blocks(d, CAS['ctx'])
    for i, q in enumerate(CAS['qs'], 1): d.question(f'{i}.', q[0])
    d.save(path)

# ------------------------------------------------------------------ corrigé
def build_corrige(path, p1, p2):
    def src(key, enonce):
        note = 'annexe B' if key == 'B' else f'§ {key}' + (', ' + SRC_NOTE[key] if key in SRC_NOTE and False else '')
        return f'Source : P1, p. {p1[SRC[key]]} ({note})  |  Énoncé : P2, p. {enonce}'
    d = Doc('Gestion des stocks : corrigé', 'Gestion des stocks  |  Corrigé et guide du formateur',
            'BTS ATI - OI  |  Bachelor Maintenance  |  Stocks corrigé', MAJ, **MARKS)
    d.kicker('ORGANISATION INDUSTRIELLE  |  DOCUMENT FORMATEUR')
    d.title('Gestion des stocks', 'Corrigé détaillé des exercices, des TP et de l’étude de cas')
    d.table(['Pièce', 'Contenu', 'Destinataire'], [['P1', 'Cours', 'Stagiaires'], ['P2', 'Cahier d’exercices et de TP', 'Stagiaires'], ['P3', 'Classeur de données, sans formules', 'Stagiaires'],
                                                 ['Corrigé', 'Ce document', 'Formateur'], ['Classeur corrigé', 'Les cinq TP et l’étude de cas, avec formules et graphiques', 'Formateur']], widths=[2, 5.4, 2.2])
    d.box('Comment lire ce corrigé', [
        'Chaque exercice reprend l’énoncé complet, puis chaque question suivie de sa réponse.',
        'Sous chaque réponse figure sa source : la pièce et la page du dossier remis aux stagiaires. « P1, p. 9 » désigne la page 9 du cours. Les numéros de page sont ceux du pied de page.',
        'Deux rubriques ferment chaque exercice : **Ce qu’il faut comprendre** et **Erreurs fréquentes**.',
        'Tous les résultats ont été calculés par script et contrôlés par un second calcul indépendant. Ceux des TP et de l’étude de cas sont aussi recalculés par les formules du classeur corrigé.'])
    d.h2('Déroulé des quatre séances', newpage=True)
    d.table(['Séance', 'Temps', 'Activité', 'Support'], [
        ['1', '1 h 15', 'Cours § 2 et 3, avec les deux histoires vraies en ouverture', 'P1, p. %d à %d' % (p1[SRC['2.2']], p1[SRC['3.2']] + 1)],
        ['', '1 h 15', 'Exercices 1 à 3', 'P2'], ['', '1 h 15', 'TP 1 : ABC sous Excel', 'P2, P3'], ['', '15 min', 'Bilan : une chose comprise, une chose floue', ''],
        ['2', '1 h', 'Cours § 4', 'P1, p. %d à %d' % (p1[SRC['4.1']], p1[SRC['4.5']])], ['', '1 h 45', 'Exercices 4 à 7 et 9 (8 pour les Bachelor)', 'P2'], ['', '1 h', 'TP 2 : courbes de coûts', 'P2, P3'], ['', '15 min', 'Bilan', ''],
        ['3', '45 min', 'Cours § 5', 'P1, p. %d à %d' % (p1[SRC['5.1']], p1[SRC['5.5']])], ['', '1 h 45', 'Exercices 10 à 13, dont FONSABLE (questions 1 à 5)', 'P2'], ['', '1 h 15', 'TP 3 : simulateur FONSABLE, puis question 6 de l’exercice 11', 'P2, P3'], ['', '15 min', 'Bilan', ''],
        ['4', '45 min', 'Cours § 6 et 7', 'P1, p. %d à %d' % (p1[SRC['6.1']], p1[SRC['6.5']] + 1)], ['', '1 h', 'Exercices 14 à 16, 18 et 19 (17 pour les Bachelor, 20 à l’oral)', 'P2'],
        ['', '1 h', 'TP 4, puis TP 5 ou étude de cas selon l’avancement', 'P2, P3'], ['', '1 h 15', 'Étude de cas (ou à terminer en autonomie), quiz du cours', 'P2, P1']], widths=[0.9, 1.1, 5.4, 2.2], size=18)
    d.p('Les temps sont indicatifs. Le total des durées affichées dans P2 dépasse 16 h : c’est voulu, on choisit selon le groupe. Les exercices 2, 5, 12 et 20 se donnent bien en travail personnel.')

    def one(kind, x, label):
        pg = p2[label]
        d.h2(label)
        d.p(f'**Énoncé** (P2, p. {pg})', after=80, color='5A6770')
        if kind == 'tp':
            d.p('**Objectif.** ' + x['but']); d.p('**Données.** ' + x['donnees'])
            d.p('Les étapes de construction figurent dans P2. Les formules clés sont rappelées en fin de corrigé.', color='5A6770', size=19)
        else:
            blocks(d, x['ctx'])
        for i, q in enumerate(x['qs'], 1):
            d.question(f'{i}.', '**' + q[0].replace('**', '') + '**')
            blocks(d, q[1])
            d.p(src(q[2] if len(q) > 2 else x['src'], pg), after=160, color='5A6770', size=17)
        if kind == 'tp':
            d.p('**Formules clés** (classeur corrigé, feuille « %s »)' % x['feuille'], after=60)
            d.table(['Cellule', 'Formule'], [[a, b] for a, b in x['formules']], widths=[2, 7.6], size=18, raw=(1,))
        d.box('Ce qu’il faut comprendre', [x['comp']] if x.get('comp') else ['Voir les réponses.'], kind='green')
        d.box('Erreurs fréquentes', ['- ' + e for e in x['err']], kind='red')

    for s in (1, 2, 3, 4):
        d.h1(SEANCES[s], newpage=True)
        for x in [x for x in EX if x['seance'] == s]: one('ex', x, head(d, 'ex', x))
        for t in [t for t in TP if t['seance'] == s]:
            t.setdefault('comp', {1: 'Le tri précède tout. Une courbe ABC se lit dans un carré, et le ratio de discrimination fixe le découpage : on ne plaque pas 20 / 80 par habitude.',
                                  2: 'Le graphique montre ce que la formule affirme : un minimum, plat, là où les deux courbes se croisent.',
                                  3: 'Un simulateur oblige à écrire la règle de gestion sans ambiguïté. C’est en le construisant qu’on comprend pourquoi on raisonne sur le stock disponible.',
                                  4: 'Les paramètres d’un stock de sécurité viennent des données, et les données changent. On vérifie le modèle sur l’historique.',
                                  5: 'Une pièce de rechange se gère par la probabilité d’en avoir besoin pendant le délai, pas par sa rotation.'}[t['n']])
            one('tp', t, head(d, 'tp', t))
    d.h1(CAS['titre'], newpage=True)
    pg = p2[CAS['titre']]
    d.p(f'**Énoncé** (P2, p. {pg})', after=80, color='5A6770')
    blocks(d, CAS['ctx'])
    for i, q in enumerate(CAS['qs'], 1):
        d.question(f'{i}.', '**' + q[0].replace('**', '') + '**'); blocks(d, q[1])
        d.p(src(q[2] if len(q) > 2 else CAS['src'], pg), after=160, color='5A6770', size=17)
    d.box('Ce qu’il faut comprendre', [CAS['comp']], kind='green')
    d.box('Erreurs fréquentes', ['- ' + e for e in CAS['err']], kind='red')
    d.box('Barème indicatif sur 20', ['Partie A : 4 points. Partie B : 4 points. Partie C : 5 points. Partie D : 4 points. Partie E : 3 points, dont 1 pour la qualité de la rédaction.'])
    d.save(path)

if __name__ == '__main__':
    out = os.path.join(HERE, 'out')
    P1 = os.path.join(out, 'P1_Cours_Gestion_des_stocks.pdf')
    p1, n1 = pages_of(P1, list(SRC.values()))
    missing = [k for k in SRC.values() if k not in p1]
    assert not missing, missing
    c = os.path.join(out, 'P2_Exercices_TP_Gestion_des_stocks.docx'); build_cahier(c); pdf = to_pdf(c)
    labels = [head(None, 'ex', x) for x in EX] + [head(None, 'tp', t) for t in TP] + [CAS['titre']]
    p2, n2 = pages_of(pdf, labels)
    missing = [k for k in labels if k not in p2]
    assert not missing, missing
    k = os.path.join(out, 'Corrige_formateur_Gestion_des_stocks.docx'); build_corrige(k, p1, p2); pdf3 = to_pdf(k)
    import subprocess, re
    n3 = int(re.search(r'Pages:\s+(\d+)', subprocess.run(['pdfinfo', pdf3], capture_output=True, text=True).stdout).group(1))
    print('P1', n1, 'P2', n2, 'Corrigé', n3); print({k[:14]: v for k, v in p1.items()}); print({k[:12]: v for k, v in p2.items()})
