# -*- coding: utf-8 -*-
"""P3 (classeur de données, sans formules) et classeur corrigé (formules et graphiques)."""
import os
from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
from openpyxl.chart import ScatterChart, BarChart, LineChart, Reference, Series
from openpyxl.workbook.defined_name import DefinedName
from openpyxl.utils import get_column_letter as CL
import calc
from calc import R, E

HERE = os.path.dirname(os.path.abspath(__file__))
HEAD = PatternFill('solid', fgColor='1B2A38'); INPUT = PatternFill('solid', fgColor='FCE6CC'); RES = PatternFill('solid', fgColor='E3F1FA')
thin = Side(style='thin', color='D8DEE2'); BORD = Border(left=thin, right=thin, top=thin, bottom=thin)
def F(**k): return Font(name='Arial', size=k.pop('size', 10), **k)

def style(ws, widths):
    for i, w in enumerate(widths, 1): ws.column_dimensions[CL(i)].width = w
    for row in ws.iter_rows():
        for c in row:
            if c.value is not None and not c.font.b and c.font.name != 'Arial': c.font = F()
def head(ws, row, col, labels):
    for j, l in enumerate(labels):
        c = ws.cell(row, col + j, l); c.font = F(bold=True, color='FFFFFF'); c.fill = HEAD; c.alignment = Alignment(wrap_text=True, vertical='center'); c.border = BORD
def put(ws, ref, v, fmt=None, fill=None, bold=False):
    c = ws[ref]; c.value = v; c.font = F(bold=bold); c.border = BORD
    if fmt: c.number_format = fmt
    if fill: c.fill = fill
    return c
def title(ws, t, sub=None):
    ws['A1'] = t; ws['A1'].font = F(bold=True, size=13, color='085B79')
    if sub: ws['A2'] = sub; ws['A2'].font = F(italic=True, color='5A6770')

FONS = [('Stock initial (t)', 880), ('Consommation par jour (t)', 13.75), ('Stock d’alerte (t)', 687.5), ('Quantité commandée (t)', 605), ('Délai (jours)', 30),
        ('Prix du sable (€/t)', 120), ('Coût de passation (€)', 1210), ('Taux de possession', 0.16), ('Jours travaillés par an', 330), ('Stock de sécurité (t)', 275)]
K = R['cas']
CASP = [('Prix d’achat (€/m)', K['P']), ('Coût de passation (€)', K['L']), ('Taux de possession', K['T']), ('Semaines travaillées par an', 50),
        ('Consommation hebdomadaire moyenne (m)', K['cs']), ('Écart-type hebdomadaire (m)', K['sx']), ('Délai moyen (semaines)', K['D']), ('Écart-type du délai (semaines)', K['sD']),
        ('Taux de service visé', K['ts']), ('Longueur d’une barre (m)', 6), ('Prix remisé (€/m)', K['Prem']), ('Seuil de la remise (m)', K['Qrem']),
        ('Commande actuelle (m)', K['Qact']), ('Stock de sécurité actuel (m)', K['SSact'])]
MOIS = ['Janvier', 'Février', 'Mars', 'Avril', 'Mai', 'Juin', 'Juillet', 'Août', 'Septembre', 'Octobre', 'Novembre', 'Décembre']

def data_sheets(wb, corrige=False):
    """Feuilles de données communes aux deux classeurs. Retourne le dict des feuilles."""
    S = {}
    ws = wb.active; ws.title = 'Lisez-moi'; S['lm'] = ws
    ws['A1'] = 'Gestion des stocks : ' + ('classeur corrigé (formateur)' if corrige else 'P3, classeur de données'); ws['A1'].font = F(bold=True, size=14, color='085B79')
    ws['A2'] = 'BTS ATI et Bachelor Maintenance  |  CFAI Centre  |  SJ  |  MAJ du 12/11/2026'; ws['A2'].font = F(italic=True, color='5A6770')
    lines = (['Ce classeur contient les données des cinq TP et de l’étude de cas du cahier P2.', 'Il ne contient aucune formule : vous construisez vos calculs vous-même, en suivant les étapes de P2.',
              'Conseil : enregistrez une copie à votre nom avant de commencer.'] if not corrige else
             ['Ce classeur reprend les données de P3 et y ajoute les formules et les graphiques attendus.', 'Cellules orange : données. Cellules bleues : résultats clés.',
              'Les fonctions statistiques s’affichent en français dans Excel (LOI.NORMALE.STANDARD.INVERSE.N, LOI.POISSON.N, ECARTYPE.STANDARD).',
              'Toutes les données sont pédagogiques, sauf celles de FONSABLE qui viennent de l’ECI n° 17.'])
    for i, l in enumerate(lines): ws.cell(4 + i, 1, l).font = F()
    head(ws, 9, 1, ['Feuille', 'Utilisée dans', 'Contenu'])
    for i, (a, b, c) in enumerate([('TP1_ABC', 'TP 1', '40 références : consommation annuelle et prix'), ('TP2_Wilson', 'TP 2', 'Paramètres de l’embout ET-16 et tarif à trois paliers'),
                                   ('TP3_FONSABLE', 'TP 3 et exercice 11', 'Paramètres de l’approvisionnement en sable'), ('TP4_Historique', 'TP 4', '52 semaines de consommation de la tige TC-20'),
                                   ('TP5_Rechange', 'TP 5', 'Huit pièces de rechange'), ('Etude_de_cas', 'Étude de cas', 'Tube TA-63 : paramètres et consommation mensuelle')]):
        for j, v in enumerate((a, b, c)): cc = ws.cell(10 + i, 1 + j, v); cc.font = F(); cc.border = BORD
    ws.column_dimensions['A'].width = 20; ws.column_dimensions['B'].width = 22; ws.column_dimensions['C'].width = 62

    ws = wb.create_sheet('TP1_ABC'); S[1] = ws
    head(ws, 1, 1, ['Référence', 'Désignation', 'Consommation annuelle', 'Prix unitaire (€)'])
    rows = calc.TP1 if not corrige else [calc.TP1[i] for i in R['tp1']['order']]
    for i, (a, b, c, d) in enumerate(rows, 2):
        put(ws, f'A{i}', a); put(ws, f'B{i}', b); put(ws, f'C{i}', c, '#,##0', INPUT if corrige else None); put(ws, f'D{i}', d, '#,##0.00', INPUT if corrige else None)
    for col, w in zip('ABCD', (12, 22, 16, 14)): ws.column_dimensions[col].width = w

    ws = wb.create_sheet('TP2_Wilson'); S[2] = ws
    head(ws, 1, 1, ['Paramètre', 'Valeur'])
    for i, (l, v, f) in enumerate([('Consommation annuelle C (pièces)', R['C'], '#,##0'), ('Coût d’une commande L (€)', R['L'], '#,##0.00'), ('Prix unitaire P (€)', R['P'], '#,##0.00'), ('Taux de possession T', R['T'], '0%')], 2):
        put(ws, f'A{i}', l); put(ws, f'B{i}', v, f, INPUT if corrige else None)
    put(ws, 'A6', 'Quantité économique Qe (pièces)')
    head(ws, 8, 1, ['Tarif : à partir de (pièces)', 'Prix unitaire (€)'])
    for i, (q, p) in enumerate([(0, 4.00), (3000, 3.90), (6000, 3.85)], 9): put(ws, f'A{i}', q, '#,##0', INPUT if corrige else None); put(ws, f'B{i}', p, '#,##0.00', INPUT if corrige else None)
    ws.column_dimensions['A'].width = 34; ws.column_dimensions['B'].width = 16

    ws = wb.create_sheet('TP3_FONSABLE'); S[3] = ws
    head(ws, 1, 1, ['Paramètre', 'Valeur']); head(ws, 1, 4, ['N° de commande', 'Retard (jours)'])
    for i, (l, v) in enumerate(FONS, 2): put(ws, f'A{i}', l); put(ws, f'B{i}', v, '0%' if 'Taux' in l else '#,##0.00' if isinstance(v, float) else '#,##0', INPUT if corrige else None)
    for i in range(1, 6): put(ws, f'D{i + 1}', i); put(ws, f'E{i + 1}', 10 if (corrige and i == 2) else 0, None, INPUT if corrige else None)
    ws.column_dimensions['A'].width = 28; ws.column_dimensions['B'].width = 12
    for col in 'DEFGHI': ws.column_dimensions[col].width = 14

    ws = wb.create_sheet('TP4_Historique'); S[4] = ws
    head(ws, 1, 1, ['Semaine', 'Consommation (pièces)'])
    for i, v in enumerate(calc.TP4, 2): put(ws, f'A{i}', i - 1); put(ws, f'B{i}', v, None, INPUT if corrige else None)
    ws.column_dimensions['A'].width = 10; ws.column_dimensions['B'].width = 16

    ws = wb.create_sheet('TP5_Rechange'); S[5] = ws
    head(ws, 1, 1, ['Désignation', 'Sorties par an', 'Délai (mois)', 'Prix (€)', 'Pièce critique'])
    for i, (nom, an, dm, prix, crit) in enumerate(calc.TP5, 2):
        put(ws, f'A{i}', nom); put(ws, f'B{i}', an, None, INPUT if corrige else None); put(ws, f'C{i}', dm, None, INPUT if corrige else None); put(ws, f'D{i}', prix, '#,##0', INPUT if corrige else None); put(ws, f'E{i}', crit)
    for col, w in zip('ABCDE', (22, 12, 12, 10, 12)): ws.column_dimensions[col].width = w

    ws = wb.create_sheet('Etude_de_cas'); S[6] = ws
    head(ws, 1, 1, ['Donnée', 'Valeur']); head(ws, 1, 4, ['Mois', 'Consommation (m)'])
    for i, (l, v) in enumerate(CASP, 2): put(ws, f'A{i}', l); put(ws, f'B{i}', v, '0%' if 'Taux' in l else '#,##0.00' if isinstance(v, float) else '#,##0', INPUT if corrige else None)
    for i, (m, v) in enumerate(zip(MOIS, K['mois']), 2): put(ws, f'D{i}', m); put(ws, f'E{i}', v, None, INPUT if corrige else None)
    ws.column_dimensions['A'].width = 40; ws.column_dimensions['B'].width = 12; ws.column_dimensions['D'].width = 12; ws.column_dimensions['E'].width = 16
    return S

def scatter(ws, anchor, title_, xt, yt, series, w=16, h=9, ymax=None, xmax=None, ymin=None):
    ch = ScatterChart(); ch.title = title_; ch.style = 13; ch.x_axis.title = xt; ch.y_axis.title = yt; ch.width = w; ch.height = h
    ch.x_axis.delete = False; ch.y_axis.delete = False
    for (xs, ys, name) in series:
        s = Series(ys, xs, title=name); s.marker.symbol = 'none'; s.smooth = False; ch.series.append(s)
    if ymax is not None: ch.y_axis.scaling.max = ymax
    if ymin is not None: ch.y_axis.scaling.min = ymin
    if xmax is not None: ch.x_axis.scaling.max = xmax; ch.x_axis.scaling.min = 0
    ws.add_chart(ch, anchor)

def build_p3(path):
    wb = Workbook(); data_sheets(wb); wb.save(path)

def build_corrige(path):
    wb = Workbook(); S = data_sheets(wb, corrige=True)
    # ---------------- TP1
    ws = S[1]; head(ws, 1, 5, ['Valeur consommée (€)', 'Part', 'Cumul', 'Rang (%)', 'Diagonale', 'Croisement', 'Classe'])
    for i in range(2, 42):
        put(ws, f'E{i}', f'=C{i}*D{i}', '#,##0.00'); put(ws, f'F{i}', f'=E{i}/SUM($E$2:$E$41)', '0.0%')
        put(ws, f'G{i}', '=F2' if i == 2 else f'=G{i - 1}+F{i}', '0.0%'); put(ws, f'H{i}', f'=(ROW()-1)/40', '0.0%'); put(ws, f'I{i}', f'=1-H{i}', '0.0%')
        put(ws, f'J{i}', f'=IF(G{i}>=I{i},"oui","")'); put(ws, f'K{i}', f'=IF(H{i}<=0.2,"A",IF(H{i}<=0.4,"B","C"))')
    put(ws, 'M1', 'Résultats', bold=True)
    for r, (l, f, fmt) in enumerate([('Valeur consommée totale (€)', '=SUM(E2:E41)', '#,##0.00'), ('Ligne du croisement', '=MATCH("oui",J2:J41,0)+1', '0'),
                                     ('Pente a', '=(INDEX(G:G,N3)-INDEX(G:G,N3-1))/(INDEX(H:H,N3)-INDEX(H:H,N3-1))', '0.000'),
                                     ('x du point C', '=(1-INDEX(G:G,N3-1)+N4*INDEX(H:H,N3-1))/(1+N4)', '0.0%'), ('Ratio de discrimination RD', '=1-N5', '0.000')], 2):
        put(ws, f'M{r}', l); put(ws, f'N{r}', f, fmt, RES if 'RD' in l or 'totale' in l else None)
    head(ws, 9, 13, ['Classe', 'Articles', 'Valeur (€)', 'Part'])
    for r, c in enumerate('ABC', 10):
        put(ws, f'M{r}', c); put(ws, f'N{r}', f'=COUNTIF($K$2:$K$41,M{r})'); put(ws, f'O{r}', f'=SUMIF($K$2:$K$41,M{r},$E$2:$E$41)', '#,##0.00'); put(ws, f'P{r}', f'=O{r}/$N$2', '0.0%', RES)
    for col, w in zip('EFGHIJKLMNOP', (16, 8, 8, 9, 10, 11, 8, 3, 28, 12, 14, 9)): ws.column_dimensions[col].width = w
    scatter(ws, 'M15', 'Courbe ABC (zone de traçage à rendre carrée)', '% cumulé des articles', '% cumulé de la valeur',
            [(Reference(ws, min_col=8, min_row=2, max_row=41), Reference(ws, min_col=7, min_row=2, max_row=41), 'Courbe ABC'),
             (Reference(ws, min_col=8, min_row=2, max_row=41), Reference(ws, min_col=9, min_row=2, max_row=41), 'Diagonale')], w=12, h=12, ymax=1, xmax=1, ymin=0)
    # ---------------- TP2
    ws = S[2]
    for nm, ref in (('C_', 'B2'), ('L_', 'B3'), ('P_', 'B4'), ('T_', 'B5')): wb.defined_names[nm] = DefinedName(nm, attr_text=f"'TP2_Wilson'!${ref[0]}${ref[1]}")
    put(ws, 'B6', '=SQRT(2*C_*L_/(P_*T_))', '#,##0.0', RES)
    head(ws, 1, 4, ['Q', 'CL (€)', 'CS (€)', 'CS + CL (€)'])
    for i in range(2, 32):
        put(ws, f'D{i}', 100 * (i - 1), '#,##0'); put(ws, f'E{i}', f'=C_/D{i}*L_', '#,##0.00'); put(ws, f'F{i}', f'=D{i}/2*P_*T_', '#,##0.00'); put(ws, f'G{i}', f'=E{i}+F{i}', '#,##0.00')
    put(ws, 'A13', 'Minimum de CS + CL dans le tableau (€)'); put(ws, 'B13', '=MIN(G2:G31)', '#,##0.00', RES)
    put(ws, 'A14', 'Quantité correspondante'); put(ws, 'B14', '=INDEX(D2:D31,MATCH(MIN(G2:G31),G2:G31,0))', '#,##0', RES)
    head(ws, 34, 1, ['Seuil', 'Prix (€)', 'Qe', 'Quantité retenue', 'CA (€)', 'CL (€)', 'CS (€)', 'CGA (€)'])
    for k, r in enumerate((35, 36, 37)):
        put(ws, f'A{r}', f'=A{9 + k}', '#,##0'); put(ws, f'B{r}', f'=B{9 + k}', '#,##0.00'); put(ws, f'C{r}', f'=SQRT(2*C_*L_/(B{r}*T_))', '#,##0.0'); put(ws, f'D{r}', f'=MAX(A{r},C{r})', '#,##0.0')
        put(ws, f'E{r}', f'=C_*B{r}', '#,##0.00'); put(ws, f'F{r}', f'=C_/D{r}*L_', '#,##0.00'); put(ws, f'G{r}', f'=D{r}/2*B{r}*T_', '#,##0.00'); put(ws, f'H{r}', f'=E{r}+F{r}+G{r}', '#,##0.00')
    put(ws, 'A39', 'CGA minimal (€)'); put(ws, 'B39', '=MIN(H35:H37)', '#,##0.00', RES)
    put(ws, 'A40', 'Prix du palier gagnant (€)'); put(ws, 'B40', '=INDEX(B35:B37,MATCH(B39,H35:H37,0))', '#,##0.00', RES)
    put(ws, 'A42', 'Remarque : la quantité retenue par MAX(seuil ; Qe) est valable tant que Qe reste sous le seuil du palier suivant, ce qui est le cas ici.')
    for col, w in zip('CDEFGH', (10, 16, 12, 12, 12, 13)): ws.column_dimensions[col].width = w
    scatter(ws, 'J2', 'Coûts annuels de ET-16', 'Quantité commandée Q', '€ par an',
            [(Reference(ws, min_col=4, min_row=2, max_row=31), Reference(ws, min_col=c, min_row=2, max_row=31), n) for c, n in ((5, 'CL'), (6, 'CS'), (7, 'CS + CL'))], ymax=3000)
    # ---------------- TP3
    ws = S[3]; head(ws, 12, 1, ['Jour', 'Stock début', 'Consommation', 'Réception', 'Stock fin', 'Commande passée', 'N° de commande', 'Jour d’arrivée', 'En cours', 'Alerte', 'Sécurité'])
    for j, v in enumerate([0, None, None, 0, '=$B$2', 0, None, None, 0, '=$B$4', '=$B$11'], 1):
        if v is not None: ws.cell(13, j, v).font = F()
    for i in range(14, 114):
        vals = [f'=A{i - 1}+1', f'=E{i - 1}', '=$B$3', f'=SUMIF($H$13:H{i - 1},A{i},$F$13:F{i - 1})', f'=B{i}-C{i}+D{i}', f'=IF(E{i}+I{i - 1}-D{i}<=$B$4,$B$5,0)',
                f'=IF(F{i}>0,MAX($G$13:G{i - 1})+1,"")', f'=IF(F{i}>0,A{i}+$B$6+VLOOKUP(G{i},$D$2:$E$6,2,FALSE),"")', f'=I{i - 1}-D{i}+F{i}', '=$B$4', '=$B$11']
        for j, v in enumerate(vals, 1): c = ws.cell(i, j, v); c.font = F(); c.number_format = '#,##0.00' if j in (2, 3, 4, 5, 6, 9) else '0'
    head(ws, 12, 13, ['n', 'CPA (€)', 'CPO (€)', 'CT (€)'])
    for k, n in enumerate([2, 3, 4, 5, 6, 7, 7.5, 8, 9, 10, 11, 12, 13, 14], 13):
        put(ws, f'M{k}', n, '0.0'); put(ws, f'N{k}', f'=$B$8*M{k}', '#,##0'); put(ws, f'O{k}', f'=$B$7*$B$9*($B$3*$B$10/(2*M{k})+$B$11)', '#,##0'); put(ws, f'P{k}', f'=N{k}+O{k}', '#,##0')
    put(ws, 'M28', 'CT minimal (€)'); put(ws, 'P28', '=MIN(P13:P26)', '#,##0', RES); put(ws, 'M29', 'n optimal'); put(ws, 'P29', '=INDEX(M13:M26,MATCH(P28,P13:P26,0))', '0.0', RES)
    put(ws, 'M30', 'Stock fin le plus bas (t)'); put(ws, 'P30', '=MIN(E13:E113)', '#,##0.00', RES)
    put(ws, 'M31', 'Stock juste avant la livraison n° 2 (t)'); put(ws, 'P31', '=P30-B3', '#,##0.00', RES)
    for col in 'JKLMNOP': ws.column_dimensions[col].width = 11
    scatter(ws, 'R2', 'Stock de sable, jour par jour', 'Jours', 'Tonnes',
            [(Reference(ws, min_col=1, min_row=13, max_row=113), Reference(ws, min_col=c, min_row=13, max_row=113), n) for c, n in ((5, 'Stock fin'), (10, 'Alerte'), (11, 'Sécurité'))], w=18, ymax=1000, xmax=100, ymin=0)
    scatter(ws, 'R21', 'Coûts selon le nombre de commandes', 'n', '€ par an',
            [(Reference(ws, min_col=13, min_row=13, max_row=26), Reference(ws, min_col=c, min_row=13, max_row=26), n) for c, n in ((14, 'CPA'), (15, 'CPO'), (16, 'CT'))], w=18)
    # ---------------- TP4
    ws = S[4]; head(ws, 1, 3, ['Somme sur 3 semaines', 'Borne basse', 'Effectif'])
    for i in range(4, 54): put(ws, f'C{i}', f'=SUM(B{i - 2}:B{i})')
    for k, a in enumerate(range(15, 65, 5), 2): put(ws, f'D{k}', a); put(ws, f'E{k}', f'=COUNTIFS($B$2:$B$53,">="&D{k},$B$2:$B$53,"<"&D{k}+5)')
    head(ws, 1, 7, ['Statistique', 'Valeur'])
    for r, (l, f, fmt) in enumerate([('Moyenne', '=AVERAGE(B2:B53)', '0.00'), ('Écart-type', '=_xlfn.STDEV.S(B2:B53)', '0.00'), ('Minimum', '=MIN(B2:B53)', '0'), ('Maximum', '=MAX(B2:B53)', '0'),
                                     ('Total annuel', '=SUM(B2:B53)', '#,##0'), ('Délai (semaines)', 3, '0')], 2):
        put(ws, f'G{r}', l); put(ws, f'H{r}', f, fmt, INPUT if l.startswith('Délai') else RES)
    head(ws, 10, 7, ['Taux de service', 'z', 'SS calculé', 'SS retenu'])
    for r, ts in enumerate([0.80, 0.90, 0.95, 0.975, 0.99, 0.999], 11):
        put(ws, f'G{r}', ts, '0.0%', INPUT); put(ws, f'H{r}', f'=_xlfn.NORM.S.INV(G{r})', '0.000'); put(ws, f'I{r}', f'=H{r}*$H$3*SQRT($H$7)', '0.0'); put(ws, f'J{r}', f'=ROUNDUP(I{r},0)', '0', RES)
    put(ws, 'G18', 'Point de commande à 95 %'); put(ws, 'H18', '=ROUNDUP(H2*H7+J13,0)', '0', RES)
    put(ws, 'G19', 'Fenêtres au-dessus du point de commande'); put(ws, 'H19', '=COUNTIF(C4:C53,">"&H18)', '0', RES)
    put(ws, 'G20', 'Service observé'); put(ws, 'H20', '=1-H19/COUNT(C4:C53)', '0%', RES)
    for col, w in zip('CDEFGHIJ', (20, 12, 10, 3, 36, 10, 11, 10)): ws.column_dimensions[col].width = w
    bc = BarChart(); bc.title = 'Histogramme des consommations hebdomadaires'; bc.style = 10; bc.width = 16; bc.height = 8; bc.x_axis.title = 'Borne basse de la classe'; bc.y_axis.title = 'Semaines'
    bc.x_axis.delete = False; bc.y_axis.delete = False
    bc.add_data(Reference(ws, min_col=5, min_row=1, max_row=11), titles_from_data=True); bc.set_categories(Reference(ws, min_col=4, min_row=2, max_row=11)); bc.gapWidth = 20; ws.add_chart(bc, 'L2')
    lc = LineChart(); lc.title = 'Stock de sécurité selon le taux de service'; lc.width = 16; lc.height = 8; lc.x_axis.delete = False; lc.y_axis.delete = False
    lc.add_data(Reference(ws, min_col=10, min_row=10, max_row=16), titles_from_data=True); lc.set_categories(Reference(ws, min_col=7, min_row=11, max_row=16)); ws.add_chart(lc, 'L19')
    # ---------------- TP5
    ws = S[5]; head(ws, 1, 6, ['λ', 'Cible', 'Seuil s'] + list(range(7)) + ['Atteint', 'Valeur (€)'])
    for i in range(2, 10):
        put(ws, f'F{i}', f'=B{i}*C{i}/12', '0.000'); put(ws, f'G{i}', f'=IF(E{i}="oui",0.99,0.95)', '0%'); put(ws, f'H{i}', f'=COUNTIF(I{i}:O{i},"<"&G{i})', '0', RES)
        for k in range(7): put(ws, f'{CL(9 + k)}{i}', f'=_xlfn.POISSON.DIST({CL(9 + k)}$1,$F{i},TRUE)', '0.0000')
        put(ws, f'P{i}', f'=_xlfn.POISSON.DIST(H{i},F{i},TRUE)', '0.0%'); put(ws, f'Q{i}', f'=H{i}*D{i}', '#,##0')
    put(ws, 'P10', 'Total', bold=True); put(ws, 'Q10', '=SUM(Q2:Q9)', '#,##0', RES)
    for col in 'FGHIJKLMNOPQ': ws.column_dimensions[col].width = 9
    # ---------------- étude de cas
    ws = S[6]; head(ws, 17, 1, ['Calcul', 'Valeur'])
    calcs = [('Consommation annuelle (m)', '=SUM(E2:E13)', '#,##0'), ('Quantité économique (m)', '=SQRT(2*B18*B3/(B2*B4))', '0.0'), ('Nombre de barres', '=ROUND(B19/B11,0)', '0'), ('Quantité retenue (m)', '=B20*B11', '0'),
             ('Commandes par an', '=B18/B21', '0.00'), ('Période (semaines)', '=B5/B22', '0.00'), ('z', '=_xlfn.NORM.S.INV(B10)', '0.000'), ('Écart-type pendant le délai (m)', '=SQRT(B8*B7^2+B6^2*B9^2)', '0.0'),
             ('Stock de sécurité calculé (m)', '=B24*B25', '0.0'), ('Stock de sécurité retenu (m)', '=ROUNDUP(B26/B11,0)*B11', '0'), ('Point de commande (m)', '=B6*B8+B27', '0')]
    for r, (l, f, fmt) in enumerate(calcs, 18): put(ws, f'A{r}', l); put(ws, f'B{r}', f, fmt, RES if 'retenu' in l or 'Point' in l else None)
    head(ws, 17, 4, ['Politique', 'Q (m)', 'SS (m)', 'Prix (€/m)', 'CL (€)', 'CS (€)', 'CA (€)', 'CGA (€)', 'Stock moyen (m)', 'Valeur (€)', 'Rotation', 'Couverture (sem.)'])
    for r, (l, q, ss, p) in enumerate([('Actuelle', '=B14', '=B15', '=B2'), ('Proposée', '=B21', '=B27', '=B2'), ('Avec remise', '=B13', '=B27', '=B12')], 18):
        put(ws, f'D{r}', l); put(ws, f'E{r}', q, '0'); put(ws, f'F{r}', ss, '0'); put(ws, f'G{r}', p, '0.00')
        put(ws, f'H{r}', f'=$B$18/E{r}*$B$3', '#,##0.00'); put(ws, f'I{r}', f'=(E{r}/2+F{r})*G{r}*$B$4', '#,##0.00'); put(ws, f'J{r}', f'=$B$18*G{r}', '#,##0'); put(ws, f'K{r}', f'=H{r}+I{r}+J{r}', '#,##0.00', RES)
        put(ws, f'L{r}', f'=E{r}/2+F{r}', '0'); put(ws, f'M{r}', f'=L{r}*G{r}', '#,##0'); put(ws, f'N{r}', f'=$B$18/L{r}', '0.0'); put(ws, f'O{r}', f'=L{r}/$B$6', '0.00')
    put(ws, 'D22', 'Gain de la proposition (€/an)'); put(ws, 'K22', '=K18-K19', '#,##0.00', RES); put(ws, 'D23', 'Gain avec remise (€/an)'); put(ws, 'K23', '=K18-K20', '#,##0.00', RES)
    for col in 'FGHIJKLMNO': ws.column_dimensions[col].width = 13
    wb.save(path)

if __name__ == '__main__':
    out = os.path.join(HERE, 'out')
    build_p3(os.path.join(out, 'P3_Donnees_TP_Gestion_des_stocks.xlsx')); build_corrige(os.path.join(out, 'Classeur_corrige_TP_Gestion_des_stocks.xlsx')); print('ok')
