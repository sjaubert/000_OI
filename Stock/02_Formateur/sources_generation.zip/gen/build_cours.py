# -*- coding: utf-8 -*-
"""P1 : cours stagiaire « La gestion des stocks »."""
import os, math
from uimm import Doc, fr, to_pdf
import calc
from calc import R, E

FIG = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'fig')
F = lambda n: os.path.join(FIG, n + '.png')
MAJ = '12/11/2026'
def n(x, nd=0): return r'\text{' + fr(x, nd) + '}'

def build(path):
    d = Doc('La gestion des stocks : cours', 'Gestion des stocks  |  P1 Cours  |  BTS ATI et Bachelor Maintenance',
            'BTS ATI - OI  |  Bachelor Maintenance  |  Stocks P1', MAJ, principales={(6, 5), (4, 3)}, associees={(4, 1), (2, 1)})
    d.kicker('ORGANISATION INDUSTRIELLE')
    d.title('La gestion des stocks', 'Combien commander, quand commander, et ce que cela coûte')
    d.table(['Public', 'Positionnement'], [
        ['BTS ATI', 'Organisation industrielle : gestion des flux et méthodes de réapprovisionnement (C6.5, avec C4.3)'],
        ['Bachelor Maintenance avancée', 'Bloc RNCP35617BC02, compétence 6 : suivi économique de l’activité de maintenance'],
        ['Prérequis', 'Diagramme de Pareto, dérivée d’une fonction, loi normale, loi de Poisson, bases d’Excel'],
        ['Durée indicative', '4 séances de 4 h : cours, exercices et 5 TP Excel (cahier P2, données P3)']], widths=[3, 6.6])
    d.p('**Compétences Bachelor Maintenance avancée (RNCP35617)**', after=80)
    d.table(['Bloc', 'Compétence', 'Niveau dans ce cours'], [
        ['BC02', '6. Assurer le suivi économique de l’activité de maintenance des équipements d’une ligne ou d’un îlot de production', '**Principale**'],
        ['BC01', '1. Mesurer et analyser les paramètres techniques et/ou indicateurs de performance des équipements d’une ligne ou d’un îlot de production', 'Associée (taux de service, rotation)'],
        ['BC01', '4. Définir des méthodes ou solutions techniques d’amélioration de maintenance', 'Associée (stock de pièces de rechange)']],
        widths=[1, 6, 2.6], hl=(0,))
    d.box('Comment lire ce cours', [
        'Le dossier comprend trois pièces. **P1** : ce cours. **P2** : le cahier d’exercices et de TP. **P3** : le classeur Excel de données.',
        'Le tronc commun s’adresse à tous. Les encadrés bleus **Bachelor** vont plus loin ; ils restent accessibles aux BTS en fin de séquence.',
        'L’entreprise VÉRILOIRE et ses chiffres sont inventés pour ce cours. Les deux histoires du § 2.3, elles, sont réelles et sourcées.'])

    # ------------------------------------------------------------------ 1
    d.h1('1. Objectifs', newpage=True)
    d.p('À la fin des quatre séances, vous saurez :')
    d.steps(['Chiffrer ce que coûte un stock à partir du taux de possession.',
             'Classer des articles par une analyse ABC et en tirer une règle de gestion.',
             'Calculer une quantité économique, puis l’ajuster à un conditionnement ou à une remise.',
             'Fixer un point de commande ou un niveau de recomplètement.',
             'Dimensionner un stock de sécurité avec la loi normale ou la loi de Poisson.',
             'Construire ces calculs dans Excel et les défendre devant un responsable.'])

    # ------------------------------------------------------------------ 2
    d.h1('2. Pourquoi un stock, et pourquoi il coûte cher')
    d.h2('2.1 Un réservoir entre deux flux')
    d.p('Un stock existe dès que ce qui entre et ce qui sort ne vont pas au même rythme. Le fournisseur livre par lots, l’atelier consomme en continu. Entre les deux, il faut un réservoir.')
    d.fig(F('f01_reservoir'), 'Le stock régule l’écart entre un flux d’entrée et un flux de sortie', 14.5)
    d.p('Trois raisons justifient ce réservoir :')
    d.bullets(['Le client veut être livré plus vite que la durée de fabrication.',
               'Commander ou régler une machine coûte de l’argent : on regroupe donc en lots.',
               'La consommation et les délais varient : on garde une marge, le **stock de sécurité**.'])
    d.h2('2.2 Ce que coûte un euro qui dort')
    d.p('Une pièce en rayon ne rapporte rien. Elle a été payée, elle occupe de la place, il faut la compter, l’assurer, et elle peut s’abîmer ou devenir inutile. On regroupe tous ces frais dans un seul chiffre, le **taux de possession** $T$ : ce que coûte en un an un euro de marchandise stockée.')
    d.eq(r'T = \dfrac{\text{frais annuels liés au stock}}{\text{valeur du stock moyen}}')
    d.fig(F('f03_taux'), 'Composition du taux de possession de VÉRILOIRE (données pédagogiques)', 14.5)
    d.p(f'VÉRILOIRE assemble des vérins pneumatiques. Son magasin contient en moyenne {fr(R["stock_total"])} € de composants. Avec $T = {n(25)}\\ \\%$ :')
    d.eq(rf'\text{{Coût annuel}} = {n(R["stock_total"])} \times {n(0.25, 2)} = {n(R["cout_an"])}\ \text{{€}}')
    d.p(f'Soit {fr(R["cout_jour"])} € par jour ouvré, que l’atelier tourne ou non.')
    d.box('Le calcul qui réveille', [
        f'Une palette de roulements à {fr(R["palette"])} € reste un an en rayon. Elle coûte {fr(R["palette"])} × 0,25 = {fr(R["palette_an"])} €, soit {fr(R["palette_jour"])} € par jour, week-ends compris. Personne ne signe de bon de commande pour cette dépense. Elle existe quand même.',
        'Les ouvrages situent $T$ entre 15 et 35 % par an (Javel, 2010). D’autres sources donnent 12 à 30 %. Il n’y a pas de valeur universelle : chaque entreprise doit calculer la sienne (exercice 1).'], kind='orange')
    d.h2('2.3 Trop de stock, pas assez de stock : deux histoires vraies')
    d.box('Deux factures', [
        '**Trop.** Au printemps 2001, la demande de matériel réseau s’effondre. Cisco se retrouve avec des composants commandés pour des ventes qui n’auront pas lieu. L’entreprise passe 2,25 milliards de dollars de stocks excédentaires en charge sur un seul trimestre (rapport annuel 2001).',
        '**Pas assez.** En 2021, l’automobile manque de semi-conducteurs. Le cabinet AlixPartners estime en septembre 2021 que 7,7 millions de véhicules ne seront pas produits dans l’année, soit 210 milliards de dollars de chiffre d’affaires perdu. Des lignes d’assemblage s’arrêtent faute d’un composant électronique.',
        'Gérer un stock, c’est chercher le niveau qui évite ces deux factures.'])
    d.h2('2.4 Le stock cache les problèmes')
    d.p('Un stock élevé rend l’atelier confortable. Une machine tombe en panne ? On pioche dans le stock. Un fournisseur livre en retard ? Pareil. Les problèmes restent sous l’eau, et personne ne les traite.')
    d.fig(F('f02_riviere'), 'La rivière et les rochers : baisser le stock fait apparaître les causes', 15)
    d.p('La leçon du Lean : on baisse le niveau progressivement, on traite le rocher qui apparaît, puis on recommence. Baisser le stock sans traiter les causes mène à la rupture.')
    d.h2('2.5 Trois indicateurs pour suivre un stock')
    d.table(['Indicateur', 'Formule', 'Lecture'], [
        ['Stock moyen', '$Q/2 + \\text{SS}$ pour un article réapprovisionné par quantité $Q$', 'Ce qui est immobilisé en moyenne'],
        ['Taux de rotation', '$\\text{consommation annuelle} / \\text{stock moyen}$', 'Nombre de fois où le stock se renouvelle dans l’année'],
        ['Couverture', '$\\text{stock} / \\text{consommation moyenne par jour}$', 'Nombre de jours tenus sans livraison']], widths=[2, 4.6, 3])
    d.p('Un article qui tourne 20 fois par an travaille. Un article qui tourne moins d’une fois par an dort, sauf s’il s’agit d’une pièce de rechange critique gardée par précaution.')

    # ------------------------------------------------------------------ 3
    d.h1('3. Classer avant de gérer : l’analyse ABC', newpage=True)
    d.p('Un magasin compte des centaines de références. Elles ne méritent pas toutes la même attention. L’analyse ABC, que vous connaissez sous le nom de Pareto, sert à trier.')
    d.h2('3.1 La méthode')
    d.steps(['Choisir le critère selon la question posée. Pour l’argent immobilisé : la **valeur consommée par an** (quantité × prix). Pour ranger un magasin : le nombre de sorties.',
             'Trier les articles par valeur décroissante du critère.',
             'Calculer les pourcentages cumulés.',
             'Tracer la courbe dans un **carré** : articles en abscisse, pourcentage cumulé en ordonnée.',
             'Lire le ratio de discrimination, puis découper en classes A, B, C.'])
    d.h2('3.2 Exemple : dix articles de VÉRILOIRE')
    rows = sorted(calc.ABC10, key=lambda a: -a[2] * a[3]); cum = 0; tab = []
    zn, trip = R['abc10_zone']; nA = 10 * trip[0] // 100; nB = 10 * trip[1] // 100
    for i, (ref, des, q, p) in enumerate(rows):
        v = q * p; cum += v
        tab.append([ref, des, fr(q), fr(p, 3 if p < 1 else 2), fr(v), fr(100 * cum / R['abc10_total'], 1) + ' %', 'A' if i < nA else 'B' if i < nA + nB else 'C'])
    d.table(['Réf.', 'Désignation', 'Conso. par an', 'Prix (€)', 'Valeur (€)', 'Cumul', 'Classe'], tab,
            widths=[1, 3.2, 1.4, 1.1, 1.3, 1.1, 0.9], align=['left', 'left', 'right', 'right', 'right', 'right', 'center'], size=18, hl=tuple(range(nA)))
    d.fig(F('f04_abc'), 'Courbe ABC des dix articles, tracée dans un carré', 9.5)
    d.p(f'**Ratio de discrimination.** On trace la diagonale qui joint le coin supérieur gauche (point A) au coin inférieur droit (point B). Elle coupe la courbe au point C. Le ratio vaut $\\text{{RD}} = \\text{{CB}} / \\text{{AB}}$ : c’est l’ordonnée de C, lue en fraction. Ici $\\text{{RD}} = {n(R["abc10_rd"], 2)}$. Les points A, B, C du tracé ne sont pas les classes A, B, C.')
    d.table(['Ratio de discrimination', 'Classe A', 'Classe B', 'Classe C'], [
        ['RD ≥ 0,90', '10 % des articles', '10 %', '80 %'], ['0,85 ≤ RD < 0,90', '10 %', '20 %', '70 %'],
        ['0,75 ≤ RD < 0,85', '20 %', '20 %', '60 %'], ['0,65 ≤ RD < 0,75', '20 %', '30 %', '50 %'],
        ['RD < 0,65', 'Non interprétable : changer de critère', '', '']], widths=[3, 2.6, 2, 2], hl=(3,))
    d.p(f'Avec RD = {fr(R["abc10_rd"], 2)}, la répartition est 20 / 30 / 50. Deux articles (TA-63 et ET-16) pèsent {fr(R["abc10_cum"][1])} % de la valeur consommée. Les cinq derniers n’en pèsent que {fr(100 - R["abc10_cum"][4])} %.')
    d.box('Ce qu’on en fait', [
        '- **Classe A** : suivi serré, point de commande, stock de sécurité calculé, inventaire fréquent.',
        '- **Classe B** : même logique, avec des contrôles plus espacés.',
        '- **Classe C** : gestion simple (recomplètement périodique, double bac, libre-service). Passer une heure à optimiser des rondelles coûte plus cher que les rondelles.',
        'Le classement dépend du critère. Classées par quantité, les rondelles RD-M6 arrivent en tête. Classées par valeur, elles sont avant-dernières.'], kind='orange')

    # ------------------------------------------------------------------ 4
    d.h1('4. Combien commander ? La quantité économique', newpage=True)
    d.h2('4.1 Deux coûts qui tirent en sens opposé')
    d.p('On suit un article sur un an. Les notations sont celles de tout le dossier.')
    d.table(['Symbole', 'Signification', 'Fil rouge : embout ET-16'], [
        ['$C$', 'Consommation annuelle', f'{fr(R["C"])} pièces (50 par jour, 250 jours)'],
        ['$P$', 'Prix ou coût de revient unitaire', f'{fr(R["P"], 2)} €'],
        ['$T$', 'Taux de possession annuel', '25 %'],
        ['$L$', 'Coût d’une commande (ou d’un lancement en fabrication)', f'{fr(R["L"])} €'],
        ['$Q$', 'Quantité commandée à chaque fois', 'À déterminer']], widths=[1.2, 5, 3.4])
    d.p('**Commander souvent** coûte en commandes : il y en a $C/Q$ par an, à $L$ euros pièce. **Commander gros** coûte en stockage : le stock oscille entre $Q$ et 0, il vaut $Q/2$ en moyenne.')
    d.eqs([r'\text{CL} = \dfrac{C}{Q}\,L', r'\text{CS} = \dfrac{Q}{2}\,P\,T', r'\text{CA} = C\,P'])
    d.p('Le coût de gestion annuel additionne les trois. Le coût d’acquisition CA ne dépend pas de $Q$, tant que le prix est fixe.')
    d.eq(r'\text{CGA}(Q) = \dfrac{C}{Q}\,L + \dfrac{Q}{2}\,P\,T + C\,P')
    d.fig(F('f05_wilson'), 'Coûts annuels de l’embout ET-16 selon la quantité commandée', 14)
    d.h2('4.2 La formule de Wilson')
    d.p('On cherche le minimum de CGA. On dérive par rapport à $Q$ et on annule la dérivée :')
    d.eqs([r"\text{CGA}'(Q) = -\dfrac{C\,L}{Q^{2}} + \dfrac{P\,T}{2} = 0", r"\text{d'où}", r"Q_e = \sqrt{\dfrac{2\,C\,L}{P\,T}}"], sep=4)
    d.p('On en tire le nombre de commandes par an et la période entre deux commandes :')
    d.eqs([r'N_e = \dfrac{C}{Q_e}', r'P_e = \dfrac{\text{nombre de jours travaillés}}{N_e}'])
    d.h2('Exemple 1 (fil rouge). Quantité économique de l’embout ET-16')
    d.eq(rf'Q_e = \sqrt{{\dfrac{{2 \times {n(R["C"])} \times {n(R["L"])}}}{{{n(R["P"])} \times {n(0.25, 2)}}}}} = \sqrt{{{n(1000000)}}} = {n(R["Qe"])}\ \text{{pièces}}')
    d.bullets([f'$N_e = {n(R["C"])} / {n(R["Qe"])} = {n(R["Ne"], 1)}$ commandes par an, soit une commande tous les {fr(R["Pe_j"])} jours ouvrés (4 semaines).',
               f'$\\text{{CL}} = {n(R["Ne"], 1)} \\times {n(R["L"])} = {n(R["CL"])}$ € et $\\text{{CS}} = {n(500)} \\times {n(4)} \\times {n(0.25, 2)} = {n(R["CS"])}$ €.',
               f'$\\text{{CGA}} = {n(R["CA"])} + {n(R["CL"])} + {n(R["CS"])} = {n(R["CGA"])}$ €.'])
    d.box('À retenir', ['À la quantité économique, le coût de stockage est égal au coût de lancement : CS = CL. C’est le moyen le plus rapide de vérifier un calcul.',
                        '$$\\text{CS}(Q_e) + \\text{CL}(Q_e) = \\sqrt{2\\,C\\,L\\,P\\,T}$$'], kind='orange')
    d.h2('4.3 L’optimum est plat : la zone économique')
    d.p('Le fournisseur livre rarement la quantité exacte de la formule. Bonne nouvelle : autour de $Q_e$, le coût bouge très peu. En posant $x = Q/Q_e$, on montre que :')
    d.eq(r'\dfrac{\text{CS}(Q) + \text{CL}(Q)}{\text{CS}(Q_e) + \text{CL}(Q_e)} = \dfrac{1}{2}\left(x + \dfrac{1}{x}\right)')
    d.fig(F('f06_zone'), 'Surcoût de gestion quand on s’écarte de la quantité économique', 14)
    d.p(f'Commander 20 % de plus que $Q_e$ ne coûte que {fr((R["zone"][1.2] - 1) * 100, 1)} % de plus sur CS + CL. Commander le double coûte 25 % de plus. Pour ET-16, livré par cartons de 300, on peut prendre 900 ou 1 200 pièces sans état d’âme : le surcoût est de {fr((R["zone"][0.9] - 1) * 1000, 2)} € ou de {fr(R["Q1200"]["tot"] - 1000, 2)} € par an.')
    d.h2('4.4 Quand le fournisseur propose une remise')
    d.p('Avec une remise sur quantité, le prix $P$ change par paliers. La courbe de coût devient une suite de morceaux. La méthode tient en trois étapes.')
    d.steps(['Pour chaque prix, calculer la quantité économique.',
             'Si elle tombe dans la tranche de ce prix, on la garde. Sinon, on retient le seuil d’entrée de la tranche.',
             'Calculer le CGA complet (CA compris) pour chaque candidat et garder le plus bas.'])
    d.h2('Exemple 2. Remise sur l’embout ET-16')
    d.p('Le fournisseur annonce : 4,00 € jusqu’à 2 999 pièces, 3,90 € à partir de 3 000, 3,85 € à partir de 6 000.')
    rem = R['remise']; best = min(range(3), key=lambda i: rem[i]['cga'])
    d.table(['Prix', '$Q_e$ calculée', 'Dans la tranche ?', 'Quantité retenue', 'CA (€)', 'CL (€)', 'CS (€)', 'CGA (€)'],
            [[fr(r['p'], 2) + ' €', fr(r['qe']), 'Oui' if r['valide'] else 'Non', fr(r['q']), fr(r['CA']), fr(r['CL'], 2), fr(r['CS'], 2), fr(r['cga'], 2)] for r in rem],
            widths=[1, 1.3, 1.5, 1.5, 1.1, 1, 1.1, 1.3], align=['left'] + ['right'] * 7, size=18, hl=(best,))
    d.fig(F('f07_remise'), 'Coût de gestion annuel avec trois paliers de prix', 14)
    d.p(f'Commander par 3 000 fait gagner {fr(rem[0]["cga"] - rem[1]["cga"], 2)} € par an. Commander par 6 000 fait perdre {fr(rem[2]["cga"] - rem[0]["cga"], 2)} € : la remise supplémentaire ne paie pas le stock. Une remise se calcule, elle ne se devine pas. Reste à vérifier la place et la trésorerie : 3 000 pièces, c’est 12 semaines de consommation en rayon.')
    d.h2('4.5 Les limites de la formule')
    d.bullets(['Elle suppose une consommation régulière, un prix fixe et des coûts connus. Dans la réalité, $L$ et $T$ sont rarement mesurés.',
               'Elle donne un ordre de grandeur. Le résultat s’arrondit toujours à un conditionnement.',
               'Elle prend $L$ comme une donnée. Or $L$ se réduit. Si le coût de lancement est divisé par 4, la quantité économique est divisée par 2, le stock moyen aussi. C’est tout l’intérêt du SMED pour les lots de fabrication.'])
    d.box('Bachelor. Lot de fabrication quand l’atelier produit pendant que l’on consomme', [
        'Quand la pièce est fabriquée à la cadence $p$ pendant que l’aval la consomme à la cadence $c$ (avec $c < p$), le stock ne monte pas jusqu’à $Q$. Il plafonne à $Q\\,(1 - c/p)$. La formule devient :',
        '$$Q_e = \\sqrt{\\dfrac{2\\,C\\,L}{P\\,T\\,\\left(1 - \\dfrac{c}{p}\\right)}}$$',
        f'Exemple : $C = {n(10000)}$, $L = {n(180)}$ €, $P = {n(30)}$ €, $T = 25\\ \\%$, $c = 40$ et $p = 200$ pièces par jour. On trouve {fr(R["fab"]["Q"])} pièces, contre {fr(R["fab"]["Q0"])} avec la formule simple. Le stock maximal est de {fr(R["fab"]["smax"])} pièces.'], kind='blue')

    # ------------------------------------------------------------------ 5
    d.h1('5. Quand commander ? Les méthodes de réapprovisionnement', newpage=True)
    d.h2('5.1 Quatre combinaisons')
    d.table(['', 'Date fixe', 'Date variable'], [
        ['**Quantité fixe**', 'Réapprovisionnement fixe\n« 1 000 vis le 10 de chaque mois »', '**Point de commande**\n« dès qu’il reste 295 pièces, on en commande 1 000 »'],
        ['**Quantité variable**', '**Recomplètement périodique**\n« le 10 de chaque mois, on complète à 2 000 »', 'Dates et quantités variables\nachats d’opportunité, matières spéculatives']], widths=[2, 3.8, 3.8])
    d.p('Deux méthodes couvrent l’essentiel des cas : le point de commande et le recomplètement périodique.')
    d.h2('5.2 Le point de commande')
    d.p('On surveille le stock en permanence. Quand il atteint un seuil, on commande une quantité fixe, en général proche de $Q_e$. Le seuil doit couvrir la consommation pendant le délai de livraison $D$, plus le stock de sécurité.')
    d.eq(r'\text{PC} = C_{\text{moy}} \times D + \text{SS}')
    d.fig(F('f08_pc'), 'Point de commande de l’embout ET-16 : la quantité est fixe, la date varie', 15)
    d.p(f'Pour ET-16 : $C_{{\\text{{moy}}}} = 50$ pièces par jour, $D = 5$ jours, $\\text{{SS}} = {R["SS95"]}$ (calculé au § 6). Donc $\\text{{PC}} = 50 \\times 5 + {R["SS95"]} = {fr(R["PC95"])}$ pièces. Sur la figure, la consommation accélère entre les jours 41 et 60 : la commande part plus tôt et le stock de sécurité absorbe l’écart.')
    d.h2('5.3 Le recomplètement périodique')
    d.p('On regarde le stock à date fixe, toutes les $d$ périodes, et on commande ce qui manque pour revenir à un niveau $\\text{NR}$. Entre deux revues, on ne surveille rien. Le niveau doit donc couvrir le délai $D$ et l’intervalle $d$.')
    d.eqs([r'\text{NR} = C_{\text{moy}} \times (D + d) + \text{SS}', r'Q_i = \text{NR} - \text{stock} - \text{commandes en cours}'])
    d.fig(F('f09_recomp'), 'Recomplètement périodique : la date est fixe, la quantité varie', 15)
    d.p('Avantage : on regroupe plusieurs articles du même fournisseur sur une seule commande. Inconvénient : le stock de sécurité est plus gros, car on reste aveugle pendant $D + d$ au lieu de $D$ (§ 6.4).')
    d.h2('5.4 Quand le délai est long : raisonner sur le stock disponible')
    d.p('Si le délai dépasse la durée couverte par une commande, le stock en rayon ne remonte jamais jusqu’au point de commande. On compare alors au point de commande le **stock disponible** : stock physique plus commandes déjà passées et pas encore reçues. Plusieurs commandes se suivent dans le tuyau (exercice 13).')
    d.h2('5.5 Quelle méthode pour quel article ?')
    d.table(['Classe', 'Méthode conseillée', 'Pourquoi'], [
        ['A', 'Point de commande, quantité proche de $Q_e$', 'Beaucoup d’argent en jeu : le suivi permanent se justifie'],
        ['B', 'Point de commande ou recomplètement, selon le fournisseur', 'Compromis entre précision et charge de travail'],
        ['C', 'Recomplètement périodique, double bac, libre-service', 'Faible valeur : la simplicité prime'],
        ['Pièces de rechange', 'Point de commande à l’unité, calculé par la loi de Poisson', 'Sorties rares, arrêt machine coûteux']], widths=[1.8, 4, 3.8])

    # ------------------------------------------------------------------ 6
    d.h1('6. Se protéger des aléas : le stock de sécurité', newpage=True)
    d.h2('6.1 Deux aléas, une approche simple')
    d.p('Tous les calculs précédents utilisent des moyennes. Deux choses peuvent mal tourner pendant le délai de livraison : la consommation dépasse la moyenne, ou la livraison arrive en retard.')
    d.table(['Aléa', 'Stock de sécurité (approche déterministe)', 'ET-16'], [
        ['Retard de livraison de $\\Delta D$', '$\\text{SS} = C_{\\text{moy}} \\times \\Delta D$', '2 jours de retard : 100 pièces'],
        ['Consommation portée à $C\'$', '$\\text{SS} = (C\' - C_{\\text{moy}}) \\times D$', '60 par jour au lieu de 50 : 50 pièces']], widths=[2.6, 4, 3])
    d.p('On retient l’aléa le plus pénalisant. Cette approche est rapide, mais elle ne dit rien du risque accepté. Pour le chiffrer, il faut les probabilités.')
    d.h2('6.2 Taux de service et loi normale')
    d.p('Le **taux de service** est la probabilité de ne pas tomber en rupture pendant un cycle de réapprovisionnement. On le choisit : 95 % veut dire qu’on accepte une rupture sur 20 cycles.')
    d.p('Hypothèses : la consommation par période suit une loi normale de moyenne $C_{\\text{moy}}$ et d’écart-type $\\sigma_x$ ; les périodes sont indépendantes ; le délai $D$ est fixe. Les variances s’ajoutent. Sur $D$ périodes :')
    d.eqs([r'X_D \sim \mathcal{N}\left(C_{\text{moy}}\,D\ ;\ \sigma_x\sqrt{D}\right)', r'\text{SS} = z\,\sigma_x\,\sqrt{D}'])
    d.p('Le coefficient $z$ se lit dans la table de la loi normale centrée réduite, ou avec Excel : LOI.NORMALE.STANDARD.INVERSE.N(taux).')
    zt = R['ztab']
    d.table(['Taux de service'] + [fr(k * 100, 2).replace(',00', '').replace(',50', ',5') + ' %' for k in (0.80, 0.90, 0.95, 0.975, 0.99, 0.995, 0.999)],
            [['$z$'] + [fr(zt[k], 2) if k != 0.95 else '1,645' for k in (0.80, 0.90, 0.95, 0.975, 0.99, 0.995, 0.999)]], widths=[2.2] + [1.05] * 7, size=18, align=['left'] + ['center'] * 7)
    d.h2('Exemple 3 (fil rouge). Stock de sécurité de l’embout ET-16')
    d.p(f'La consommation journalière a pour moyenne 50 et pour écart-type $\\sigma_x = 12$ pièces. Le délai est de 5 jours. On vise 95 %.')
    d.eq(rf'\text{{SS}} = {n(1.645, 3)} \times 12 \times \sqrt{{5}} = {n(1.645, 3)} \times {n(R["sD"], 2)} = {n(R["SS"][0.95], 1)} \ \rightarrow\ {R["SS95"]}\ \text{{pièces}}')
    d.fig(F('f10_normale'), 'Demande pendant le délai : le point de commande laisse 5 % de risque à droite', 14)
    d.box('Le piège de la racine', [
        f'On multiplie par $\\sqrt{{D}}$, pas par $D$. Les jours forts et les jours faibles se compensent en partie. Écrire $z\\,\\sigma_x\\,D$ donnerait {fr(1.645 * 12 * 5)} pièces au lieu de {R["SS95"]} : plus du double. On trouve cette erreur jusque dans des manuels.',
        'L’unité de $D$ doit être celle de $\\sigma_x$. Écart-type par jour : délai en jours. Écart-type par semaine : délai en semaines.'], kind='red')
    d.h2('6.3 Le prix du dernier pour cent')
    d.fig(F('f11_ss_ts'), 'Stock de sécurité de ET-16 selon le taux de service visé', 14)
    d.p(f'Passer de 90 à 95 % coûte {math.ceil(R["SS"][0.95]) - math.ceil(R["SS"][0.90])} pièces de plus. Passer de 99 à 99,9 % en coûte {math.ceil(R["SS"][0.999]) - math.ceil(R["SS"][0.99])}. Le 100 % n’existe pas : la courbe part à l’infini. On réserve donc les taux élevés aux articles dont la rupture arrête une ligne.')
    d.h2('6.4 Recomplètement périodique : un horizon plus long')
    d.p('Avec le recomplètement, l’incertitude court sur $D + d$. La formule devient :')
    d.eq(r'\text{SS} = z\,\sigma_x\,\sqrt{D + d}')
    d.p(f'Pour ET-16 revu toutes les 4 semaines ($d = 20$ jours) : $\\text{{SS}} = \\text{{1,645}} \\times 12 \\times \\sqrt{{25}} = {fr(math.ceil(R["SS95_rec"]))}$ pièces, contre {R["SS95"]} au point de commande. Puis $\\text{{NR}} = 50 \\times 25 + {math.ceil(R["SS95_rec"])} = {fr(R["NR"])}$ pièces.')
    d.box('Bachelor. Quand le délai varie aussi', [
        'Si le délai a lui-même un écart-type $\\sigma_D$, et s’il est indépendant de la consommation, les deux variances s’ajoutent :',
        '$$\\sigma = \\sqrt{D\\,\\sigma_x^{2} + C_{\\text{moy}}^{2}\\,\\sigma_D^{2}}$$', '$$\\text{SS} = z\\,\\sigma$$',
        f'ET-16 avec $\\sigma_D = 1$ jour : $\\sigma = \\sqrt{{5 \\times 144 + {n(2500)} \\times 1}} = {n(R["s_tot"], 1)}$, donc $\\text{{SS}} = {fr(math.ceil(R["SS95_del"]))}$ pièces au lieu de {R["SS95"]}. Un seul jour d’incertitude sur le délai double le stock de sécurité. Fiabiliser le fournisseur rapporte plus que lisser la consommation.'], kind='blue')
    d.h2('6.5 Pièces à faible rotation : la loi de Poisson')
    d.p('Un distributeur pneumatique de rechange sort du magasin quatre fois par an. La loi normale décrit mal ces petites quantités entières. La loi de Poisson convient : des événements rares, indépendants, à rythme moyen constant.')
    d.p('La demande pendant le délai suit une loi de Poisson de paramètre $\\lambda$ = consommation moyenne pendant le délai. Le point de commande est le plus petit entier $s$ tel que $P(X \\le s)$ atteigne le taux de service visé.')
    d.h2('Exemple 4. Distributeur 5/2 de rechange')
    pz = R['pois']
    d.p('Consommation : 4 par an. Délai : 3 mois. Donc $\\lambda = 4 \\times 3 / 12 = 1$.')
    d.table(['$k$'] + [str(k) for k in range(5)], [['$P(X = k)$'] + [fr(pz['pmf'][k], 4) for k in range(5)], ['$P(X \\le k)$'] + [fr(pz['cdf'][k], 4) for k in range(5)]],
            widths=[2] + [1.5] * 5, align=['left'] + ['center'] * 5, hl=(1,))
    d.fig(F('f12_poisson'), 'Demande de distributeurs pendant le délai (loi de Poisson, λ = 1)', 13.5)
    d.p(f'Pour 95 %, il faut $s = 3$ : $P(X \\le 2)$ = {fr(pz["cdf"][2] * 100, 1)} % ne suffit pas, $P(X \\le 3)$ = {fr(pz["cdf"][3] * 100, 1)} % convient. On recommande dès que le stock tombe à 3. Dans Excel : LOI.POISSON.N(k ; λ ; VRAI).')

    # ------------------------------------------------------------------ 7
    d.h1('7. Du calcul au terrain', newpage=True)
    d.h2('7.1 Le tableau de bord du gestionnaire')
    d.table(['Indicateur', 'Ce qu’il surveille', 'Signal d’alerte'], [
        ['Taux de service réel', 'Demandes servies à temps / demandes totales', 'En dessous de la cible deux mois de suite'],
        ['Rotation et couverture', 'L’argent immobilisé', 'Couverture supérieure à 6 mois hors pièces de sécurité'],
        ['Stocks morts', 'Articles sans sortie depuis 12 mois', 'Toute ligne sans décision (garder, vendre, rebuter)'],
        ['Écarts d’inventaire', 'La fiabilité des quantités enregistrées', 'Écart au-delà de 2 % sur un article A']], widths=[2.4, 3.8, 3.4])
    d.p('Les seuils du tableau sont des repères de départ. Chaque entreprise fixe les siens.')
    d.h2('7.2 Réduire le stock pour de bon')
    d.p('Les formules disent où agir. Le stock dépend de quatre paramètres, et chacun se travaille.')
    d.table(['Levier', 'Effet dans les formules', 'Outil'], [
        ['Réduire le coût de lancement $L$', '$Q_e$ varie comme $\\sqrt{L}$', 'SMED, commandes ouvertes, EDI'],
        ['Réduire le délai $D$', 'PC et SS baissent', 'Fournisseur proche, contrat de délai'],
        ['Réduire la variabilité $\\sigma$', 'SS baisse en proportion', 'Lissage, prévisions, fiabilité fournisseur'],
        ['Épurer', 'Stock mort supprimé', 'Revue annuelle, analyse ABC croisée']], widths=[3, 3, 3.6])
    d.p('Le kanban et le double bac ne sont rien d’autre qu’un point de commande rendu visible : quand le premier bac est vide, on commande et on entame le second.')

    # ------------------------------------------------------------------ 8
    d.h1('8. Table ronde : une réunion stock chez VÉRILOIRE')
    d.p('Le contrôleur de gestion demande 20 % de stock en moins. Quatre voix se répondent.')
    d.table(['Qui', 'Ce qu’il dit', 'Ce qu’il faut lui répondre'], [
        ['Acheteur', '« En commandant par 6 000, j’obtiens 3,85 €. »', 'Le CGA monte de 96 € par an (exemple 2). La bonne tranche est 3 000.'],
        ['Magasinier', '« J’ai toujours gardé 300 embouts d’avance, et je n’ai jamais manqué. »', 'À 95 % de service, 45 suffisent. Les 255 autres coûtent 255 € par an, pour un seul article.'],
        ['Responsable maintenance', '« Mes pièces ne tournent pas, mais ne touchez à rien. »', 'D’accord pour les pièces critiques, à condition de les lister et de calculer leur seuil (loi de Poisson).'],
        ['Contrôleur de gestion', '« Baissez tout de 20 %. »', 'Une baisse uniforme crée des ruptures sur les A et laisse dormir les C. On baisse article par article.']], widths=[1.8, 3.6, 4.2], size=19)

    # ------------------------------------------------------------------ 9
    d.h1('9. Synthèse', newpage=True)
    d.fig(F('f13_carte'), 'Carte mentale de la gestion des stocks', 15.5)
    d.h2('Formulaire')
    d.table(['Grandeur', 'Formule'], [
        ['Coût de stockage, coût de lancement', '$\\text{CS} = (Q/2 + \\text{SS})\\,P\\,T$ ; $\\text{CL} = (C/Q)\\,L$'],
        ['Coût de gestion annuel', '$\\text{CGA} = \\text{CS} + \\text{CL} + C\\,P$'],
        ['Quantité économique (Wilson)', '$Q_e = \\sqrt{2\\,C\\,L / (P\\,T)}$ ; $N_e = C/Q_e$'],
        ['Écart à l’optimum', '$(\\text{CS} + \\text{CL})(Q) = (\\text{CS} + \\text{CL})(Q_e) \\times \\frac{1}{2}(x + 1/x)$ avec $x = Q/Q_e$'],
        ['Point de commande', '$\\text{PC} = C_{\\text{moy}}\\,D + \\text{SS}$'],
        ['Niveau de recomplètement', '$\\text{NR} = C_{\\text{moy}}\\,(D + d) + \\text{SS}$'],
        ['Stock de sécurité, loi normale', '$\\text{SS} = z\\,\\sigma_x\\sqrt{D}$ (ou $\\sqrt{D + d}$ en recomplètement)'],
        ['Délai variable (Bachelor)', '$\\sigma^{2} = D\\,\\sigma_x^{2} + C_{\\text{moy}}^{2}\\,\\sigma_D^{2}$'],
        ['Faible rotation, loi de Poisson', 'plus petit $s$ tel que $P(X \\le s) \\ge$ taux de service, avec $\\lambda = C_{\\text{moy}}\\,D$'],
        ['Rotation, couverture', 'consommation annuelle / stock moyen ; stock / consommation par jour']], widths=[3.4, 6.2], size=19)
    d.box('Pour retenir', [
        '- **« 2 CL sur PT, sous la racine »** : la formule de Wilson se lit dans l’ordre des lettres.',
        '- **« À l’optimum, les deux coûts se serrent la main »** : CS = CL.',
        '- **« Le double ne coûte qu’un quart »** : commander 2 fois $Q_e$ ajoute 25 % à CS + CL.',
        '- **« La sécurité prend la racine »** : $\\sqrt{D}$, jamais $D$.',
        '- **« A comme Attention, C comme Confort »** : rigueur sur les A, simplicité sur les C.'], kind='orange')

    # ------------------------------------------------------------------ 10
    d.h1('10. Quiz d’auto-évaluation')
    quiz = ['Un stock moyen de 60 000 € avec T = 20 % coûte combien par an ?',
            'Citez deux composantes du taux de possession.',
            'Pour une analyse ABC destinée à réduire l’argent immobilisé, quel critère choisir ?',
            'C = 5 000, L = 50 €, P = 10 €, T = 20 %. Que vaut la quantité économique ?',
            'À la quantité économique, quelle relation lie CS et CL ?',
            'On commande 1,5 fois la quantité économique. De combien augmente CS + CL ?',
            'Consommation de 30 pièces par jour, délai de 4 jours, SS de 40. Point de commande ?',
            'Pourquoi le stock de sécurité est-il plus élevé en recomplètement périodique ?',
            'σ = 10 pièces par jour, délai de 9 jours, service de 97,5 %. Stock de sécurité ?',
            'Quelle loi utiliser pour une pièce de rechange qui sort trois fois par an ?']
    d.steps(quiz, prefix='Q')
    d.p('Réponses en annexe A.')

    # ------------------------------------------------------------------ 11
    d.h1('11. Plan de travail')
    d.table(['Séance', 'Cours (P1)', 'Exercices et TP (P2)'], [
        ['1 (4 h)', '§ 2 et 3 : coût d’un stock, indicateurs, ABC', 'Exercices 1 à 3, TP 1 (ABC sous Excel)'],
        ['2 (4 h)', '§ 4 : Wilson, zone économique, remises', 'Exercices 4 à 9, TP 2 (courbes de coûts)'],
        ['3 (4 h)', '§ 5 : point de commande, recomplètement', 'Exercices 10 à 13, TP 3 (simulation FONSABLE)'],
        ['4 (4 h)', '§ 6 et 7 : stock de sécurité, pilotage', 'Exercices 14 à 20, TP 4 et 5, étude de cas']], widths=[1.3, 4, 4.3])
    d.box('Selon votre score au quiz', [
        '- **8 à 10** : passez directement à l’étude de cas de P2 et aux encadrés Bachelor.',
        '- **5 à 7** : refaites les exemples 1 à 4 du cours sans regarder la solution, puis les exercices 4, 10 et 15.',
        '- **Moins de 5** : reprenez le § 4.1 et le § 6.2 avec le formulaire sous les yeux, puis les exercices 1, 4 et 10.',
        'En fin de séance, notez une chose comprise, une chose encore floue, et une question pour la séance suivante.'])

    # ------------------------------------------------------------------ annexes
    d.h1('Annexe A. Réponses au quiz', newpage=True)
    d.steps(['60 000 × 0,20 = 12 000 € par an.',
             'Coût du capital immobilisé, magasinage, assurance, détérioration, obsolescence (deux au choix).',
             'La valeur consommée par an (quantité × prix), ou la valeur du stock immobilisé.',
             '$Q_e = \\sqrt{2 \\times 5\\,000 \\times 50 / (10 \\times \\text{0,20})} = \\sqrt{250\\,000} = 500$ pièces.',
             'CS = CL.',
             '$\\frac{1}{2}(\\text{1,5} + 1/\\text{1,5}) = \\text{1,083}$ : + 8,3 %.',
             'PC = 30 × 4 + 40 = 160 pièces.',
             'Parce que l’incertitude court sur D + d au lieu de D : on ne regarde le stock qu’à date fixe.',
             'SS = 1,96 × 10 × √9 = 58,8, soit 59 pièces.',
             'La loi de Poisson.'], prefix='Q')
    d.h1('Annexe B. Fonctions Excel utiles')
    d.table(['Besoin', 'Fonction (Excel en français)', 'Exemple'], [
        ['Racine carrée', 'RACINE(nombre)', '=RACINE(2*C*L/(P*T))'],
        ['Moyenne, écart-type d’un échantillon', 'MOYENNE(plage) ; ECARTYPE.STANDARD(plage)', '=ECARTYPE.STANDARD(B2:B53)'],
        ['Coefficient z pour un taux de service', 'LOI.NORMALE.STANDARD.INVERSE.N(probabilité)', '=LOI.NORMALE.STANDARD.INVERSE.N(0,95) donne 1,645'],
        ['Taux de service pour un seuil donné', 'LOI.NORMALE.N(x ; moyenne ; écart-type ; VRAI)', '=LOI.NORMALE.N(295;250;26,83;VRAI) donne 0,953'],
        ['Probabilité cumulée de Poisson', 'LOI.POISSON.N(k ; λ ; VRAI)', '=LOI.POISSON.N(3;1;VRAI) donne 0,981'],
        ['Arrondi au conditionnement', 'ARRONDI.AU.MULTIPLE(nombre ; multiple)', '=ARRONDI.AU.MULTIPLE(1000;300) donne 900'],
        ['Arrondi à l’entier supérieur', 'ARRONDI.SUP(nombre ; 0)', '=ARRONDI.SUP(44,1;0) donne 45'],
        ['Somme de produits', 'SOMMEPROD(plage1 ; plage2)', '=SOMMEPROD(C2:C41;D2:D41)']], widths=[2.8, 3.6, 3.2], size=18)
    d.h1('Sources')
    d.bullets(['G. Javel, *Organisation et gestion de la production*, 4e édition, Dunod, 2010, chapitre 2 « La fonction stock » (p. 27 à 68).',
               'Cours « Gestion des stocks » BTS ATI, CFAI Centre, mise à jour du 25/10/2024.',
               'Étude de cas FONSABLE, ECI n° 17, CFAI Centre.',
               'Cisco Systems, rapport annuel 2001 (formulaire 10-K, SEC) : charge pour stocks excédentaires de 2,25 milliards de dollars au troisième trimestre de l’exercice 2001.',
               'AlixPartners, prévision du 23 septembre 2021 reprise par Bloomberg : 7,7 millions de véhicules non produits, 210 milliards de dollars de chiffre d’affaires perdu en 2021.',
               'OpenClassrooms, cours « Pilotez la production dans l’industrie du futur », chapitre « Gérez les stocks » : coût de possession de 12 à 30 % de la valeur du stock moyen.'], after=50)
    d.save(path)
    return d

if __name__ == '__main__':
    out = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'out', 'P1_Cours_Gestion_des_stocks.docx')
    build(out); print(to_pdf(out))
