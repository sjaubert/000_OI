import sys, glob, subprocess, os
from PIL import Image
pdf, tag, dpi = sys.argv[1], sys.argv[2], int(sys.argv[3]) if len(sys.argv) > 3 else 50
for f in glob.glob(f'out/{tag}-*.png') + glob.glob(f'out/{tag}_sheet*.png'): os.remove(f)
subprocess.run(['pdftoppm', '-r', str(dpi), '-png', pdf, f'out/{tag}'], check=True)
fs = sorted(glob.glob(f'out/{tag}-*.png'))
for part in range(0, len(fs), 8):
    ims = [Image.open(f) for f in fs[part:part + 8]]; w, h = ims[0].size
    sheet = Image.new('RGB', (w * 4, h * 2), 'white')
    for i, im in enumerate(ims): sheet.paste(im, ((i % 4) * w, (i // 4) * h))
    sheet.save(f'out/{tag}_sheet{part // 8}.png')
print(len(fs))
