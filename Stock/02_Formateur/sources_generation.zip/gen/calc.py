# -*- coding: utf-8 -*-
"""Tous les calculs du module Gestion des stocks. Source unique des valeurs numériques."""
import math
import numpy as np
from scipy import stats

R = {}
sq = math.sqrt
JOURS, SEM = 250, 50          # jours ouvrés et semaines travaillées par an

def wilson(C, L, P, T): return sq(2 * C * L / (P * T))
def cga(C, L, P, T, Q, SS=0): return C * P + C / Q * L + (Q / 2 + SS) * P * T
def z(ts): return stats.norm.ppf(ts)

def rd_abc(values):
    """Tri décroissant, % cumulés, ratio de discrimination (intersection avec la diagonale AB)."""
    v = sorted(values, reverse=True); tot = sum(v); n = len(v)
    xs = [0] + [100 * (i + 1) / n for i in range(n)]
    ys = [0] + list(100 * np.cumsum(v) / tot)
    for i in range(1, n + 1):
        if ys[i] >= 100 - xs[i]:
            x0, y0, x1, y1 = xs[i - 1], ys[i - 1], xs[i], ys[i]
            a = (y1 - y0) / (x1 - x0)
            x = (100 - y0 + a * x0) / (a + 1)
            return xs, ys, x, 100 - x
def zone(rd):
    if rd >= 0.90: return 1, (10, 10, 80)
    if rd >= 0.85: return 2, (10, 20, 70)
    if rd >= 0.75: return 3, (20, 20, 60)
    if rd >= 0.65: return 4, (20, 30, 50)
    return 5, None

# ------------------------------------------------------------------ cours
# § 2 : ce que coûte un stock (VÉRILOIRE)
R['stock_total'] = 1_200_000; R['T'] = 0.25
R['cout_an'] = R['stock_total'] * R['T']
R['cout_jour'] = R['cout_an'] / JOURS
R['palette'] = 40_000; R['palette_an'] = 40_000 * 0.25; R['palette_jour'] = R['palette_an'] / 365
R['T_decomp'] = [('Coût du capital immobilisé', 8), ('Magasinage (locaux, personnel, énergie)', 9),
                 ('Assurance', 1), ('Détérioration, casse, pertes', 3), ('Obsolescence', 4)]
assert sum(v for _, v in R['T_decomp']) == 25

# § 3 : ABC, dix articles de VÉRILOIRE
ABC10 = [('TA-63', 'Tube aluminium profilé (m)', 4000, 21.0), ('ET-16', 'Embout de tige', 12500, 4.0),
         ('TC-20', 'Tige chromée', 2000, 12.0), ('FL-63', 'Flasque avant', 1400, 10.0),
         ('KJ-40', 'Kit de joints', 2500, 4.0), ('AM-08', 'Amortisseur de fin de course', 1000, 7.0),
         ('CP-01', 'Capteur magnétique', 500, 10.0), ('VS-M6', 'Vis CHC M6', 40000, 0.075),
         ('RD-M6', 'Rondelle M6', 50000, 0.04), ('ET-QT', 'Étiquette signalétique', 20000, 0.05)]
vals = [q * p for _, _, q, p in ABC10]
R['abc10_total'] = sum(vals)
xs, ys, xc, yc = rd_abc(vals)
R['abc10_cum'] = ys[1:]; R['abc10_rd'] = yc / 100; R['abc10_xc'] = xc; R['abc10_zone'] = zone(yc / 100)

# § 4 : Wilson, fil rouge ET-16
C, L, P, T = 12500, 40.0, 4.0, 0.25
Qe = wilson(C, L, P, T)
R.update(C=C, L=L, P=P, Qe=Qe, Ne=C / Qe, Pe_j=JOURS / (C / Qe), CS=Qe / 2 * P * T, CL=C / Qe * L,
         CA=C * P, CGA=cga(C, L, P, T, Qe), Cmoy_j=C / JOURS)
ratio = lambda x: 0.5 * (x + 1 / x)
R['zone'] = {x: ratio(x) for x in (0.5, 0.8, 0.9, 1.2, 1.5, 2.0)}
R['Q1200'] = dict(CL=C / 1200 * L, CS=600 * P * T, tot=C / 1200 * L + 600 * P * T)
# remises ET-16
tiers = [(0, 4.00), (3000, 3.90), (6000, 3.85)]
rem = []
for qmin, p in tiers:
    q = wilson(C, L, p, T); valide = q >= qmin and (qmin == tiers[-1][0] or q < [t[0] for t in tiers if t[0] > qmin][0])
    qr = q if valide else qmin
    rem.append(dict(qmin=qmin, p=p, qe=q, valide=valide, q=qr, CA=C * p, CL=C / qr * L, CS=qr / 2 * p * T, cga=cga(C, L, p, T, qr)))
R['remise'] = rem
# Bachelor : lot de fabrication
Cf, Lf, Pf, Tf, cmj, pmj = 10000, 180.0, 30.0, 0.25, 40, 200
R['fab'] = dict(Q0=wilson(Cf, Lf, Pf, Tf), Q=sq(2 * Cf * Lf / ((1 - cmj / pmj) * Pf * Tf)), smax=None)
R['fab']['smax'] = R['fab']['Q'] * (1 - cmj / pmj)

# § 5 et 6 : point de commande, stock de sécurité
D, sx = 5, 12.0
R['D'] = D; R['sx'] = sx; R['couv'] = R['Cmoy_j'] * D; R['sD'] = sx * sq(D)
R['SS'] = {ts: z(ts) * sx * sq(D) for ts in (0.90, 0.95, 0.975, 0.99, 0.999)}
R['ztab'] = {ts: z(ts) for ts in (0.50, 0.80, 0.8413, 0.90, 0.95, 0.975, 0.9772, 0.99, 0.995, 0.999)}
R['SS95'] = math.ceil(R['SS'][0.95]); R['PC95'] = R['couv'] + R['SS95']
sDel = 1.0
R['s_tot'] = sq(D * sx ** 2 + R['Cmoy_j'] ** 2 * sDel ** 2); R['SS95_del'] = z(0.95) * R['s_tot']
# recomplètement périodique ET-16 : revue toutes les 4 semaines (20 j)
d_rev = 20
R['SS95_rec'] = z(0.95) * sx * sq(D + d_rev); R['NR'] = R['Cmoy_j'] * (D + d_rev) + math.ceil(R['SS95_rec'])
# Poisson : distributeur 5/2, 4 par an, délai 3 mois
lam = 4 * 3 / 12
R['pois'] = dict(lam=lam, pmf=[stats.poisson.pmf(k, lam) for k in range(6)], cdf=[stats.poisson.cdf(k, lam) for k in range(6)])

# ------------------------------------------------------------------ exercices
E = {}
# E1 taux de possession
frais = [('Coût du capital immobilisé (5 % de la valeur du stock)', 40000), ('Salaires et charges du magasin', 72000),
         ('Loyer, énergie et entretien de la surface', 28000), ('Assurance du stock', 6000),
         ('Casse, pertes, péremption', 14000), ('Dépréciation des articles obsolètes', 24000)]
st = 800000
E[1] = dict(stock=st, frais=frais, total=sum(f for _, f in frais), T=sum(f for _, f in frais) / st)
E[1]['jour'] = E[1]['total'] / 365; E[1]['palette'] = 15000 * E[1]['T'] * 8 / 12
E[1]['var'] = 40000 + 6000 + 14000 + 24000; E[1]['eco_naive'] = 0.2 * E[1]['total']; E[1]['eco_reelle'] = 0.2 * E[1]['var']
# E2 rotation et couverture
art2 = [('ET-16', 50000, 2180), ('TA-63', 84000, 21000), ('FL-63', 14000, 3500), ('CP-01', 5000, 7500)]
E[2] = [dict(ref=r, conso=c, stock=s, rot=c / s, couv=s / c * JOURS) for r, c, s in art2]
tc, ts_ = sum(a[1] for a in art2), sum(a[2] for a in art2)
E[2].append(dict(ref='Ensemble', conso=tc, stock=ts_, rot=tc / ts_, couv=ts_ / tc * JOURS))
# E3 ABC à la main : magasin de maintenance, deux critères
E3 = [('R01', 'Roulement 6205', 120, 9.0, 40), ('R02', 'Courroie trapézoïdale', 60, 22.0, 25),
      ('R03', 'Vérin ISO Ø50', 40, 180.0, 6), ('R04', 'Distributeur 5/2', 8, 145.0, 10),
      ('R05', 'Filtre hydraulique', 240, 38.0, 30), ('R06', 'Variateur 4 kW', 2, 950.0, 3),
      ('R07', 'Capteur inductif', 45, 32.0, 30), ('R08', 'Fusible 10 A', 300, 1.2, 400),
      ('R09', 'Moteur 2,2 kW', 3, 420.0, 4), ('R10', 'Graisse (cartouche)', 150, 6.0, 60)]
v1 = {r: q * p for r, _, q, p, _ in E3}; v2 = {r: s * p for r, _, _, p, s in E3}
def classe(vd):
    items = sorted(vd.items(), key=lambda kv: -kv[1]); tot = sum(vd.values())
    xs, ys, xc, yc = rd_abc(list(vd.values())); zn, trip = zone(yc / 100)
    cum = 0; out = []
    n = len(items)
    for i, (r, v) in enumerate(items):
        cum += v; pos = (i + 1) / n * 100
        cl = '?' if trip is None else ('A' if pos <= trip[0] + 1e-9 else 'B' if pos <= trip[0] + trip[1] + 1e-9 else 'C')
        out.append((r, v, 100 * v / tot, 100 * cum / tot, cl))
    return dict(rows=out, total=tot, rd=yc / 100, xc=xc, zone=zn, trip=trip)
E[3] = dict(data=E3, conso=classe(v1), stock=classe(v2), couv={r: s_ / q * 12 for r, _, q, p, s_ in E3})
# E4 Wilson : filtres
E[4] = dict(C=2400, L=60.0, P=12.0, T=0.25); e = E[4]
e['Qe'] = wilson(e['C'], e['L'], e['P'], e['T']); e['Q'] = 300; e['N'] = e['C'] / e['Q']; e['Pe'] = SEM / e['N']
e['CL'] = e['N'] * e['L']; e['CS'] = e['Q'] / 2 * e['P'] * e['T']; e['CA'] = e['C'] * e['P']; e['CGA'] = e['CA'] + e['CL'] + e['CS']
e['opt'] = sq(2 * e['C'] * e['L'] * e['P'] * e['T'])
# E5 retrouver L
E[5] = dict(C=3600, P=5.0, T=0.24, Q=900, Lreel=50.0); e = E[5]
e['Limp'] = e['Q'] ** 2 * e['P'] * e['T'] / (2 * e['C']); e['Qe'] = wilson(e['C'], e['Lreel'], e['P'], e['T'])
e['cout900'] = e['C'] / 900 * e['Lreel'] + 450 * e['P'] * e['T']; e['coutQe'] = sq(2 * e['C'] * e['Lreel'] * e['P'] * e['T'])
e['surcout'] = e['cout900'] - e['coutQe']
# E6 zone économique (suite de E4)
e4 = E[4]
E[6] = {q: dict(x=q / e4['Qe'], r=ratio(q / e4['Qe']), cout=e4['C'] / q * e4['L'] + q / 2 * e4['P'] * e4['T']) for q in (150, 250, 300, 350, 600, 1000)}
E[6]['borne'] = (e4['Qe'] * (1.05 - sq(1.05 ** 2 - 1)), e4['Qe'] * (1.05 + sq(1.05 ** 2 - 1)))
# E7 remise
E[7] = dict(C=6000, L=80.0, T=0.20, tiers=[(0, 10.0), (1000, 9.70), (3000, 9.50)]); e = E[7]; out = []
for i, (qmin, p) in enumerate(e['tiers']):
    q = wilson(e['C'], e['L'], p, e['T']); qmax = e['tiers'][i + 1][0] if i + 1 < len(e['tiers']) else float('inf')
    ok = qmin <= q < qmax; qr = q if ok else qmin
    out.append(dict(p=p, qmin=qmin, qe=q, ok=ok, q=qr, CA=e['C'] * p, CL=e['C'] / qr * e['L'], CS=qr / 2 * p * e['T'], cga=cga(e['C'], e['L'], p, e['T'], qr)))
e['res'] = out
# E8 lot de fabrication (Bachelor) : valeurs de R['fab'] ; E9 SMED
E[8] = dict(C=Cf, L=Lf, P=Pf, T=Tf, cmj=cmj, pmj=pmj, **R['fab'])
E[8]['duree_prod'] = E[8]['Q'] / pmj; E[8]['cycle'] = E[8]['Q'] / cmj; E[8]['N'] = Cf / E[8]['Q']
E[9] = dict(C=10000, P=30.0, T=0.25, L1=180.0, L2=45.0); e = E[9]
for k in (1, 2):
    q = wilson(e['C'], e[f'L{k}'], e['P'], e['T']); e[f'Q{k}'] = q; e[f'cout{k}'] = sq(2 * e['C'] * e[f'L{k}'] * e['P'] * e['T'])
    e[f'val{k}'] = q / 2 * e['P']; e[f'N{k}'] = e['C'] / q
# E10 point de commande simple
E[10] = dict(conso=780, sem=26, D=3); e = E[10]
e['cs'] = e['conso'] / e['sem']; e['cj'] = e['cs'] / 5; e['PC'] = e['cs'] * e['D']; e['PC2'] = e['PC'] + 2 * e['cj']
e['immo'] = 2 * e['cj']; e['SS'] = 4 * e['cj']; e['PC3'] = e['PC2'] + e['SS']
# E11 FONSABLE (ECI n° 17)
F = dict(wagon=55, silos=8, cap=110, D=30, cj=13.75, jours=330, ssj=20, prix=120.0, Lc=1210.0, T=0.16)
F['smax'] = F['silos'] * F['cap']; F['SS'] = F['ssj'] * F['cj']; F['PC'] = F['D'] * F['cj'] + F['SS']
F['Q'] = F['smax'] - F['SS']; F['wag'] = F['Q'] / F['wagon']; F['per'] = F['Q'] / F['cj']; F['n'] = F['jours'] / F['per']
F['Can'] = F['cj'] * F['jours']; F['a'] = F['Can'] / 2 * F['prix'] * F['T']; F['b'] = F['SS'] * F['prix'] * F['T']
F['nopt'] = sq(F['a'] / F['Lc']); F['Qopt'] = F['Can'] / F['nopt']; F['wopt'] = F['Qopt'] / F['wagon']
F['CT'] = lambda n: F['Lc'] * n + F['a'] / n + F['b']
F['t1'] = (F['smax'] - F['PC']) / F['cj']; F['arr2_prev'] = F['t1'] + F['per'] + F['D']; F['arr2'] = F['arr2_prev'] + 10
F['smin_retard'] = F['SS'] - 10 * F['cj']
E[11] = F
# E12 recomplètement périodique
E[12] = dict(cs=400, D=2, d=4, SS=300); e = E[12]; e['NR'] = e['cs'] * (e['D'] + e['d']) + e['SS']
e['Q1'] = e['NR'] - 1150; e['Q2'] = e['NR'] - 900; e['Q3'] = e['NR'] - 1400 - 600
# E13 position de stock
E[13] = dict(cj=50, D=30, Q=1000); e = E[13]; e['couv'] = e['Q'] / e['cj']; e['PC'] = e['cj'] * e['D']
e['k'] = math.floor(e['D'] / e['couv']); e['res'] = e['D'] - e['k'] * e['couv']; e['PCphys'] = e['cj'] * e['res']
# E14 SS déterministe
E[14] = dict(cj=50, D=5, retard=2, hausse=0.20); e = E[14]
e['ss_ret'] = e['cj'] * e['retard']; e['ss_conso'] = e['cj'] * e['hausse'] * e['D']
e['ss_les2'] = e['cj'] * (1 + e['hausse']) * (e['D'] + e['retard']) - e['cj'] * e['D']
e['SS'] = max(e['ss_ret'], e['ss_conso']); e['PC'] = e['cj'] * e['D'] + e['SS']
# E15 SS loi normale
E[15] = dict(m=250, s=40, D=2, ts=0.975); e = E[15]; e['z'] = z(e['ts']); e['sD'] = e['s'] * sq(e['D'])
e['SS'] = e['z'] * e['sD']; e['SSa'] = math.ceil(e['SS']); e['PC'] = e['m'] * e['D'] + e['SSa']
e['faux'] = e['z'] * e['s'] * e['D']
# E16 taux de service obtenu
E[16] = dict(PC=560); e = E[16]; e['z'] = (e['PC'] - 500) / E[15]['sD']; e['ts'] = stats.norm.cdf(e['z'])
e['Ncycles'] = 12.5; e['rupt_an'] = (1 - e['ts']) * e['Ncycles']; e['ts0'] = 0.5; e['rupt0'] = 0.5 * 12.5
# E17 délai variable
E[17] = dict(m=50, s=12, D=5, sD=1.0); e = E[17]
e['v1'] = e['D'] * e['s'] ** 2; e['v2'] = e['m'] ** 2 * e['sD'] ** 2; e['sig'] = sq(e['v1'] + e['v2'])
e['SS'] = z(0.95) * e['sig']; e['SSfix'] = z(0.95) * e['s'] * sq(e['D']); e['part'] = e['v2'] / (e['v1'] + e['v2'])
e['sig_half'] = sq(e['v1'] + e['m'] ** 2 * 0.25); e['SS_half'] = z(0.95) * e['sig_half']
# E18 Poisson
E[18] = dict(an=6, Dmois=1, prix=1800.0, T=0.25); e = E[18]; e['lam'] = e['an'] * e['Dmois'] / 12
e['pmf'] = [stats.poisson.pmf(k, e['lam']) for k in range(5)]; e['cdf'] = [stats.poisson.cdf(k, e['lam']) for k in range(5)]
e['s95'] = int(stats.poisson.ppf(0.95, e['lam'])); e['s99'] = int(stats.poisson.ppf(0.99, e['lam']))
e['cout_unite'] = e['prix'] * e['T']; e['arret'] = 2500 * 16
e['cycles'] = e['an'] / 2
e['rupt'] = [e['cycles'] * (1 - c) for c in e['cdf']]; e['cout_rupt'] = [r * e['arret'] for r in e['rupt']]
e['marg'] = [e['cout_rupt'][k] - e['cout_rupt'][k + 1] for k in range(4)]
# E19 recomplètement + SS
E[19] = dict(m=250, s=40, D=2, d=4); e = E[19]
e['SSrec'] = z(0.95) * e['s'] * sq(e['D'] + e['d']); e['SSpc'] = z(0.95) * e['s'] * sq(e['D'])
e['NR'] = e['m'] * (e['D'] + e['d']) + math.ceil(e['SSrec']); e['ecart'] = math.ceil(e['SSrec']) - math.ceil(e['SSpc'])

# ------------------------------------------------------------------ jeux de données des TP
rng = np.random.default_rng(2026)
SEED1 = 5
# TP1 : 40 références
fam = ['Roulement', 'Joint', 'Vanne', 'Courroie', 'Capteur', 'Filtre', 'Raccord', 'Tube', 'Bague', 'Ressort']
TP1 = []
rng1 = np.random.default_rng(SEED1)
for i in range(40):
    u = rng1.normal(0, 1)
    pu = float(np.round(np.exp(1.9 + 1.55 * u), 2)); pu = max(pu, 0.05)
    q = int(np.round(np.exp(5.6 - 0.45 * u + 0.95 * rng1.normal(0, 1)) / 10) * 10); q = max(q, 10)
    TP1.append((f'A{i + 1:03d}', f'{fam[i % 10]} type {i // 10 + 1}', q, pu))
v = [q * p for _, _, q, p in TP1]
xs, ys, xc, yc = rd_abc(v)
R['tp1'] = dict(total=sum(v), rd=yc / 100, xc=xc, zone=zone(yc / 100), xs=xs, ys=ys)
order = sorted(range(40), key=lambda i: -v[i]); zn, trip = R['tp1']['zone']
nA, nB = round(40 * trip[0] / 100), round(40 * trip[1] / 100)
R['tp1'].update(nA=nA, nB=nB, pA=sum(v[i] for i in order[:nA]) / sum(v), pB=sum(v[i] for i in order[nA:nA + nB]) / sum(v),
                top=[TP1[i][0] for i in order[:nA]], order=order)
# TP4 : 52 semaines de consommation de TC-20
TP4 = [int(x) for x in np.round(rng.normal(40, 9, 52))]
m4, s4 = float(np.mean(TP4)), float(np.std(TP4, ddof=1))
R['tp4'] = dict(m=m4, s=s4, n=52, D=3, mn=min(TP4), mx=max(TP4), total=sum(TP4),
                SS={ts: z(ts) * s4 * sq(3) for ts in (0.80, 0.90, 0.95, 0.975, 0.99, 0.999)})
R['tp4']['PC95'] = m4 * 3 + math.ceil(R['tp4']['SS'][0.95])
R['tp4']['sw'] = stats.shapiro(TP4).pvalue
# TP5 : pièces de rechange
TP5 = [('Distributeur 5/2', 4, 3, 145.0, 'non'), ('Variateur 4 kW', 2, 2, 950.0, 'oui'), ('Moteur 2,2 kW', 3, 1.5, 420.0, 'oui'),
       ('Vérin ISO Ø50', 12, 1, 180.0, 'non'), ('Carte automate', 1, 4, 1300.0, 'oui'), ('Codeur incrémental', 2, 3, 380.0, 'non'),
       ('Pompe à vide', 1, 2, 2100.0, 'oui'), ('Électrovanne', 9, 0.5, 95.0, 'non')]
rows = []
for nom, an, dm, prix, crit in TP5:
    lam = an * dm / 12; ts = 0.99 if crit == 'oui' else 0.95; s = int(stats.poisson.ppf(ts, lam))
    rows.append(dict(nom=nom, an=an, dm=dm, prix=prix, crit=crit, lam=lam, ts=ts, s=s, atteint=float(stats.poisson.cdf(s, lam)), val=s * prix))
R['tp5'] = dict(rows=rows, total=sum(r['val'] for r in rows))

# ------------------------------------------------------------------ étude de cas : tube TA-63
K = dict(C=4000, P=21.0, L=90.0, T=0.25, cs=80, sx=18.0, D=3, sD=0.5, ts=0.98, barre=6, Prem=20.40, Qrem=1200, Qact=1000, SSact=400)
K['mois'] = [310, 345, 290, 360, 385, 340, 330, 150, 395, 370, 365, 360]
assert sum(K['mois']) == K['C']
K['Qe'] = wilson(K['C'], K['L'], K['P'], K['T']); K['barres'] = round(K['Qe'] / 6); K['Q'] = K['barres'] * 6
K['N'] = K['C'] / K['Q']; K['per'] = SEM / K['N']
K['z'] = z(K['ts']); K['v1'] = K['D'] * K['sx'] ** 2; K['v2'] = K['cs'] ** 2 * K['sD'] ** 2; K['sig'] = sq(K['v1'] + K['v2'])
K['SS'] = K['z'] * K['sig']; K['SSb'] = math.ceil(K['SS'] / 6) * 6; K['PC'] = K['cs'] * K['D'] + K['SSb']
def pol(Q, SS, P): return dict(CL=K['C'] / Q * K['L'], CS=(Q / 2 + SS) * P * K['T'], CA=K['C'] * P, smoy=Q / 2 + SS, val=(Q / 2 + SS) * P)
for name, (Q, SS, P_) in dict(act=(K['Qact'], K['SSact'], K['P']), prop=(K['Q'], K['SSb'], K['P']), rem=(K['Qrem'], K['SSb'], K['Prem'])).items():
    d = pol(Q, SS, P_); d['tot'] = d['CL'] + d['CS'] + d['CA']; d['gest'] = d['CL'] + d['CS']
    d['rot'] = K['C'] / d['smoy']; d['couv'] = d['smoy'] / K['cs']; K[name] = d
K['gain_prop'] = K['act']['tot'] - K['prop']['tot']; K['gain_rem'] = K['act']['tot'] - K['rem']['tot']
K['m_mois'] = np.mean(K['mois']); K['s_mois'] = float(np.std(K['mois'], ddof=1))
R['cas'] = K

if __name__ == '__main__':
    import pprint
    def show(d, pre=''):
        for k, v in d.items():
            if callable(v) or k in ('xs', 'ys', 'order', 'data'): continue
            if isinstance(v, dict): print(pre + str(k) + ':'); show(v, pre + '   ')
            else: print(pre + f'{k}: {v}')
    show(R)
    for k in sorted(E):
        print('--- E', k)
        if isinstance(E[k], dict): show(E[k], '   ')
        else:
            for row in E[k]: print('   ', row)
    print(TP4)

# --- compléments calculés après coup (TP4 : vérification empirique ; E7 : prix seuil ; E9 : temps de réglage)
_roll = [sum(TP4[i:i + 3]) for i in range(len(TP4) - 2)]
_pc = math.ceil(R['tp4']['m'] * 3 + math.ceil(R['tp4']['SS'][0.95]))
R['tp4'].update(roll_n=len(_roll), PC95e=_pc, depass=sum(1 for x in _roll if x > _pc), roll_max=max(_roll),
                hist=[sum(1 for x in TP4 if a <= x < a + 5) for a in range(15, 65, 5)])
R['tp4']['obs'] = 1 - R['tp4']['depass'] / len(_roll)
e = E[7]; e['p_seuil'] = (e['res'][1]['cga'] - e['C'] / 3000 * e['L']) / (e['C'] + 1500 * e['T']); e['rem_seuil'] = 1 - e['p_seuil'] / 10
e['gain'] = e['res'][0]['cga'] - e['res'][1]['cga']
e = E[9]; e['h1'] = e['N1'] * 4; e['h2'] = e['N2'] * 1
